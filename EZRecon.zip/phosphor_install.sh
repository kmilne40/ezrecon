#!/usr/bin/env bash
#
# phosphor_install.sh — installs eZrecon and, if you want, stands up a
# self-hosted SearXNG so keyless search/dork results work out of the box.
#
# Safe to re-run. Nothing is installed without asking first.
#
set -u

# ---- phosphor palette (green #33ff66 / amber #ffb000) --------------------
if [ -t 1 ] && command -v tput >/dev/null 2>&1 && [ "$(tput colors 2>/dev/null || echo 0)" -ge 8 ]; then
  G=$'\033[38;5;42m'; A=$'\033[38;5;214m'; D=$'\033[2m'; B=$'\033[1m'; R=$'\033[0m'
else
  G=""; A=""; D=""; B=""; R=""
fi
say()  { printf '%s\n' "${G}$*${R}"; }
warn() { printf '%s\n' "${A}$*${R}"; }
dim()  { printf '%s\n' "${D}$*${R}"; }
rule() { printf '%s\n' "${G}────────────────────────────────────────────────────────────${R}"; }

# run the whole thing from the directory this script lives in (repo root)
cd "$(dirname "$0")" || exit 1

# ---- ask helper (defaults to Yes) ----------------------------------------
ask() {  # ask "Question?"  -> returns 0 for yes
  local q="$1" ans
  printf '%s' "${A}${q} [Y/n] ${R}"
  read -r ans || ans=""
  case "${ans,,}" in ""|y|yes) return 0 ;; *) return 1 ;; esac
}

clear 2>/dev/null || true
rule
say "${B}eZrecon installer${R}"
dim  "Passive and active recon for the mainframe hunter — a fast, low-memory TUI."
rule
echo

# ---- 1. Python check ------------------------------------------------------
if ! command -v python3 >/dev/null 2>&1; then
  warn "python3 was not found. Install Python 3.9+ and re-run this script."
  exit 1
fi
say "· found $(python3 --version 2>&1)"

# ---- 2. install eZrecon ---------------------------------------------------
say "· installing the ezrecon command"
# Kali/Debian mark the system Python 'externally managed' (PEP 668). Prefer
# pipx, then a normal pip install, then pip with --break-system-packages.
installed=""
if command -v pipx >/dev/null 2>&1; then
  if pipx install . >/dev/null 2>&1 || pipx install --force . >/dev/null 2>&1; then
    installed="pipx"
  fi
fi
if [ -z "$installed" ]; then
  if python3 -m pip install . >/dev/null 2>&1; then
    installed="pip"
  elif python3 -m pip install --break-system-packages . >/dev/null 2>&1; then
    installed="pip (--break-system-packages)"
  fi
fi
if [ -z "$installed" ]; then
  warn "  ! automatic install failed. Try one of these by hand:"
  dim  "      pipx install ."
  dim  "      python3 -m pip install --break-system-packages ."
  exit 1
fi
say "  ✓ installed via ${installed}"

# make sure the command is reachable for the SearXNG step below
EZ="ezrecon"
command -v ezrecon >/dev/null 2>&1 || EZ="python3 -m ezrecon.cli"
echo

# ---- 3. optional: SearXNG -------------------------------------------------
rule
say "${B}Optional: SearXNG (keyless search results)${R}"
rule
cat <<EOF
${D}eZrecon can pull Google-style dork and search results without any API key by
talking to a private ${R}${G}SearXNG${R}${D} instance — an open-source metasearch engine that
aggregates results from many engines and exposes a clean JSON API.

We run it for you in a local Docker container, enable its JSON API (off by
default), and point eZrecon at it. Nothing leaves your machine, there is no
account and no key, and it starts automatically on boot.

This step will, only if you agree:
  • install Docker if it is missing — via Docker's official script, falling
    back to your distro's native ${R}${G}docker.io${R}${D} package (e.g. on Kali)
  • enable and start the Docker service (systemctl enable --now docker)
  • run SearXNG on ${R}${A}host port 10080${R}${D} and point eZrecon at it${R}
EOF
echo

if ask "Continue and set up SearXNG now?"; then
  echo
  say "· setting up SearXNG (this can take a minute the first time)"
  # --yes: you've already consented here, so let it install Docker unattended
  # via the belt-and-braces path; --port 10080 avoids the common 8080 clash.
  $EZ searx setup --yes --port 10080
  rc=$?
  echo
  if [ "$rc" -eq 0 ]; then
    say "  ✓ SearXNG is up. Keyless dork results now work."
  else
    warn "  ! SearXNG setup didn't finish. You can retry any time with:"
    dim  "      ezrecon searx setup --port 10080"
    dim  "    or check it with:  ezrecon searx status"
  fi
else
  echo
  dim "Skipped. You can set it up later with:  ezrecon searx setup --port 10080"
  dim "eZrecon still works without it (it falls back to DuckDuckGo / your own keys)."
fi

echo
rule
say "${B}Done.${R} Launch eZrecon with:  ${A}ezrecon${R}"
rule
