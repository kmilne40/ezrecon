# Changelog

All notable changes to EZRecon are recorded here, newest first.

## [2.1.0] — 2026-08-06

A round of enrichment and speed work on top of the 2.0 rebuild.

Added
- ASN / netblock enrichment. New module that takes every IP we've resolved and
  looks up its ASN, owner and BGP prefix through Team Cymru's DNS service —
  pure DNS, no API key, no external tool. It groups hosts by netblock, which
  often exposes the organisation's own address space where mainframes cluster.
  Available as `ezrecon asn` and folded into auto-recon by default.
- crt.sh verification. Certificate-transparency names are now resolved
  concurrently and merged with the brute-force results, so a passive hit
  becomes a confirmed live host with IPs instead of just a name. Duplicates
  across the two sources are collapsed.
- Shodan query builder in the TUI. The Shodan module now opens a tick-box panel
  where every mainframe query has its own checkbox and an editable field — tick
  the ones you want, tweak the syntax, or type your own in the blank rows.

Changed
- Auto-recon runs its independent stages (whois, DNS, crt.sh, subdomains,
  email, Shodan) concurrently now instead of one after another, then does the
  dependent stages (banner grab, ASN) afterwards. Roughly halves wall time.
- DNS now defaults to fast public resolvers (1.1.1.1 / 8.8.8.8 / 9.9.9.9) with
  a shared cache, and the subdomain brute force uses a shorter per-query
  timeout (2s) — both configurable. A non-existent name no longer costs 5s.
- crt.sh and the email spider share a pooled HTTP session so connection and TLS
  setup is paid once.

New settings (`ezrecon config`): `brute_timeout` (default 2.0) and
`dns_nameservers` (default: public resolvers; set to `[]` for the system
resolver).

## [2.0.0] — 2026-08-06

Complete ground-up rebuild. The original tool was a single curses menu that
imported modules that were never shipped, so it wouldn't start; every scan it
did run went one host at a time. We threw that out and built EZRecon around a
proper async engine with two front-ends on top.

Added
- Async recon engine. DNS, subdomain brute force, banner grabs, and the email
  spider all run concurrently now, so a sweep that used to take minutes takes
  seconds.
- Textual TUI with a phosphor-green theme. Sidebar modules, a live findings
  table, keyboard and mouse, and it works fine over SSH.
- Scriptable CLI. Every module is a subcommand (`ezrecon dns`, `ezrecon auto`,
  and so on), and running `ezrecon` with no arguments opens the TUI.
- Google Dork multi-select. The mainframe dork catalogue from Chapter 6 is
  built in; tick the ones you want and fire them at a target.
- DNS module. A/AAAA/MX/NS/SOA/TXT/CNAME plus SPF and DMARC parsing, reverse
  lookups, and a zone-transfer (AXFR) attempt against every name server.
- Subdomain discovery. Concurrent brute force with wildcard-DNS detection so a
  wildcard zone doesn't report the whole wordlist as live.
- crt.sh enrichment. Pulls subdomains straight out of certificate-transparency
  logs to catch the shadow endpoints a wordlist never will.
- Shodan module. Ships the z/OS banner query library (TSO, IBM FTP, CICS,
  Db2/DRDA, NJE) so you can sweep for mainframes without memorising syntax.
- Native banner grab (non-nmap). An opt-in async connect-and-read across the
  mainframe port profile, with a fingerprint scorer that flags "likely
  mainframe" and names the service.
- AI-OSINT prompt generator. Emits the deep-research prompt from Chapter 6,
  pre-filled with the target and anything the tool already found.
- Auto-recon. One command runs the whole passive chain into a single session.
- Report export. Markdown, HTML (phosphor-themed), JSON, and a `queries.txt`
  for the lab deliverable.
- API-key vault. Keys live in `~/.config/ezrecon/config.json` (with env-var and
  legacy `api_key.json` fallbacks) instead of being scattered around.

Changed
- Dropped the Nmap component entirely. Active Nmap scanning is its own section
  of the book; EZRecon is the passive-recon workhorse.
- Reworked the engine so it never touches the UI, which means it's unit-tested
  and reusable from the CLI, the TUI, or your own scripts.

Fixed
- Tool no longer crashes on launch from missing imports.
- Run button no longer overflowed off the right edge of the terminal.
