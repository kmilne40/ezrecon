# Changelog

All notable changes to EZRecon are recorded here, newest first.

## [2.4.1] — 2026-08-06

Fixed
- Tick boxes now render a clear tick. The checkbox glyph was being clipped to an
  ellipsis by a too-narrow column and drawn in a near-invisible colour; ticked
  boxes now show a dark tick on a bright-green box and unticked boxes read as an
  empty box, in the dork, Shodan and options panels.

## [2.4.0] — 2026-08-06

Added
- Entity graph with live pivots (a Maltego-style view). Every finding becomes a
  node — domain, subdomain, IP, ASN/netblock, email, port/service, dork — with
  typed edges (resolves-to, announced-by, has-email, runs, found-via), and it
  deduplicates naturally so ten subdomains sharing one netblock show as one ASN
  node. In the TUI, press `g`: navigate nodes, see each node's connections, and
  press Enter to pivot — run a recon action scoped to that node (resolve, port
  scan, spider, reverse DNS, ASN, Shodan host/net, dork links) whose results
  fold back into the graph, which redraws. Active pivots go through the same
  active-recon confirmation as the preview pane.
- Interactive HTML graph export. A self-contained, force-directed, draggable/
  zoomable graph (Cytoscape, phosphor-themed, with an offline fallback) — from
  the graph screen's `x` key, the CLI `ezrecon graph <session.json>`, or as a
  `*_graph.html` file in every report bundle. Clicking a node shows its details
  and the pivots available for it.

The graph and pivots are pure re-renderings of the session you already have, so
they slot in next to chaining without collecting anything new on their own.

## [2.3.0] — 2026-08-06

Added
- Options screen. Press `o` (or the sidebar button) for a popup that exposes the
  search settings that were previously CLI-only: subdomain wordlist path, DNS
  concurrency and brute timeout; email-spider seed URL, crawl depth, max pages
  and concurrency, plus a field to record known email addresses in the dossier;
  the banner-grab port set and concurrency; the preview engine and result limit;
  and the chaining toggle and cap. The TUI now drives the engine with these
  values instead of hardcoded defaults.
- Discovery chaining. When a run turns up new subdomains, EZRecon can feed the
  top ones straight back into the workflow: each becomes a `site:<host>` dork
  link and an email-spider seed, so shadow endpoints get dorked and crawled too.
  It shows a confirmation first — the exact hosts, how many dork links, how many
  spider seeds — before doing anything, is capped (default 10), and never spends
  API quota (link dorks only). Available in the TUI automatically after a
  subdomains/crt.sh/auto run, and on the CLI as `ezrecon auto --chain
  [--chain-cap N]`.

## [2.2.0] — 2026-08-06

Added
- Preview pane. Press `p` on a dork result in the TUI to open a preview window:
  it resolves the dork to real result links (DuckDuckGo when no key, the Google
  API when one is configured), fetches a chosen page, and shows the page title,
  status, and — the useful part — every place a dork term (JCL, LPAR, RACF,
  EBCDIC, an email, etc.) appears, highlighted in surrounding context. `o` opens
  the full page in a browser, `s` adds a natural-language summary (optional,
  needs an Anthropic key), `Esc` closes it. Also available from the CLI as
  `ezrecon preview "<query>" --pages [--summary]`.
- Optional LLM summaries. With an Anthropic API key set, the preview pane can
  summarise a page and point out where the notable material is. Extractive
  (in-context) analysis is always on and needs no key.
- Editable dorks. Each dork in the panel is now an editable field next to its
  tick box, so you can tweak any query — or type your own — before running or
  turning it into links. The Shodan panel already worked this way.

Changed
- Checkboxes show a tick (✓) when on instead of an X, in the dork and Shodan
  panels.
- The preview pane reaches out to third-party search engines and pages, so it
  is active, not passive. It is gated behind a one-time confirmation (with a
  "don't ask again" option stored as `allow_active_fetch`).

New keys/settings: `anthropic_api_key` (optional, for summaries),
`anthropic_model`, and `allow_active_fetch`.

## [2.1.1] — 2026-08-06

Added
- No-key dork mode. The Google Dork panel now has an **Open as links** button
  (and the CLI a `--links` flag) that builds clickable search URLs for every
  selected dork instead of calling the API — no key, no quota, no terms-of-
  service issue. Pick the engine with `--engine google|bing|duckduckgo|
  startpage`. Links are clickable in the TUI and in the exported md/html
  reports; the raw dork strings still go to `queries.txt`.

Fixed
- Google dork errors now show Google's actual reason. Previously a failed
  Custom Search request surfaced only a bare "400 Bad Request"; the module now
  reads the API's JSON error body and reports the real message (e.g. "API key
  not valid" or "project does not have access to Custom Search JSON API"),
  reports it once instead of repeating it for all twenty dorks, and points at
  the no-key link mode as the fix.

## [2.1.0] — 2026-08-06

A round of enrichment and speed work on top of the 2.0 rebuild.

Added
- ASN / netblock enrichment. New module that takes every IP we've resolved and
  looks up its ASN, owner and BGP prefix through Team Cymru's DNS service —
  pure DNS, no API key, no external tool. It groups hosts by netblock, which
  often exposes the organisation's own address space where mainframes cluster.
  Available as `ezrecon asn` and folded into auto-recon by default.
- crt.sh verification. Certificate-transparency names are now resolved
  concurrently and merged with the brute-force results, so a passive hit
  becomes a confirmed live host with IPs instead of just a name. Duplicates
  across the two sources are collapsed.
- Shodan query builder in the TUI. The Shodan module now opens a tick-box panel
  where every mainframe query has its own checkbox and an editable field — tick
  the ones you want, tweak the syntax, or type your own in the blank rows.

Changed
- Auto-recon runs its independent stages (whois, DNS, crt.sh, subdomains,
  email, Shodan) concurrently now instead of one after another, then does the
  dependent stages (banner grab, ASN) afterwards. Roughly halves wall time.
- DNS now defaults to fast public resolvers (1.1.1.1 / 8.8.8.8 / 9.9.9.9) with
  a shared cache, and the subdomain brute force uses a shorter per-query
  timeout (2s) — both configurable. A non-existent name no longer costs 5s.
- crt.sh and the email spider share a pooled HTTP session so connection and TLS
  setup is paid once.

New settings (`ezrecon config`): `brute_timeout` (default 2.0) and
`dns_nameservers` (default: public resolvers; set to `[]` for the system
resolver).

## [2.0.0] — 2026-08-06

Complete ground-up rebuild. The original tool was a single curses menu that
imported modules that were never shipped, so it wouldn't start; every scan it
did run went one host at a time. We threw that out and built EZRecon around a
proper async engine with two front-ends on top.

Added
- Async recon engine. DNS, subdomain brute force, banner grabs, and the email
  spider all run concurrently now, so a sweep that used to take minutes takes
  seconds.
- Textual TUI with a phosphor-green theme. Sidebar modules, a live findings
  table, keyboard and mouse, and it works fine over SSH.
- Scriptable CLI. Every module is a subcommand (`ezrecon dns`, `ezrecon auto`,
  and so on), and running `ezrecon` with no arguments opens the TUI.
- Google Dork multi-select. The mainframe dork catalogue from Chapter 6 is
  built in; tick the ones you want and fire them at a target.
- DNS module. A/AAAA/MX/NS/SOA/TXT/CNAME plus SPF and DMARC parsing, reverse
  lookups, and a zone-transfer (AXFR) attempt against every name server.
- Subdomain discovery. Concurrent brute force with wildcard-DNS detection so a
  wildcard zone doesn't report the whole wordlist as live.
- crt.sh enrichment. Pulls subdomains straight out of certificate-transparency
  logs to catch the shadow endpoints a wordlist never will.
- Shodan module. Ships the z/OS banner query library (TSO, IBM FTP, CICS,
  Db2/DRDA, NJE) so you can sweep for mainframes without memorising syntax.
- Native banner grab (non-nmap). An opt-in async connect-and-read across the
  mainframe port profile, with a fingerprint scorer that flags "likely
  mainframe" and names the service.
- AI-OSINT prompt generator. Emits the deep-research prompt from Chapter 6,
  pre-filled with the target and anything the tool already found.
- Auto-recon. One command runs the whole passive chain into a single session.
- Report export. Markdown, HTML (phosphor-themed), JSON, and a `queries.txt`
  for the lab deliverable.
- API-key vault. Keys live in `~/.config/ezrecon/config.json` (with env-var and
  legacy `api_key.json` fallbacks) instead of being scattered around.

Changed
- Dropped the Nmap component entirely. Active Nmap scanning is its own section
  of the book; EZRecon is the passive-recon workhorse.
- Reworked the engine so it never touches the UI, which means it's unit-tested
  and reusable from the CLI, the TUI, or your own scripts.

Fixed
- Tool no longer crashes on launch from missing imports.
- Run button no longer overflowed off the right edge of the terminal.
