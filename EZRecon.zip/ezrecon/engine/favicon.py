"""Favicon-hash pivot.

Shodan indexes a MurmurHash3 of every favicon it sees, so hashing a target's
favicon and searching `http.favicon.hash:<hash>` finds every other host serving
the same icon - origin servers behind a CDN, staging/dev clones, and (for brand
protection) phishing copies. Widely used to pivot from one asset to a whole
estate.

Shodan's exact recipe (matters - a mismatch silently finds nothing):
    mmh3.hash(base64.encodebytes(favicon_bytes))
`encodebytes` follows RFC 2045 (newlines every 76 chars), which is what Shodan
matches. We use the mmh3 package if present, else a vendored pure-Python
MurmurHash3 that returns the identical signed 32-bit value - so there's no hard
C-extension dependency.
"""

from __future__ import annotations

import base64
from typing import Callable, Optional

from ..models import Finding, Session, Severity
from .base import make_http_session


def _murmur3_32(data: bytes, seed: int = 0) -> int:
    """MurmurHash3 x86_32, returning the signed 32-bit value mmh3.hash gives."""
    c1 = 0xCC9E2D51
    c2 = 0x1B873593
    length = len(data)
    h1 = seed & 0xFFFFFFFF
    rounded_end = length & ~0x3
    for i in range(0, rounded_end, 4):
        k1 = (data[i] | (data[i + 1] << 8) |
              (data[i + 2] << 16) | (data[i + 3] << 24)) & 0xFFFFFFFF
        k1 = (k1 * c1) & 0xFFFFFFFF
        k1 = ((k1 << 15) | (k1 >> 17)) & 0xFFFFFFFF
        k1 = (k1 * c2) & 0xFFFFFFFF
        h1 ^= k1
        h1 = ((h1 << 13) | (h1 >> 19)) & 0xFFFFFFFF
        h1 = (h1 * 5 + 0xE6546B64) & 0xFFFFFFFF
    k1 = 0
    tail = length & 0x3
    ti = rounded_end
    if tail == 3:
        k1 ^= data[ti + 2] << 16
    if tail >= 2:
        k1 ^= data[ti + 1] << 8
    if tail >= 1:
        k1 ^= data[ti]
        k1 = (k1 * c1) & 0xFFFFFFFF
        k1 = ((k1 << 15) | (k1 >> 17)) & 0xFFFFFFFF
        k1 = (k1 * c2) & 0xFFFFFFFF
        h1 ^= k1
    h1 ^= length
    h1 ^= h1 >> 16
    h1 = (h1 * 0x85EBCA6B) & 0xFFFFFFFF
    h1 ^= h1 >> 13
    h1 = (h1 * 0xC2B2AE35) & 0xFFFFFFFF
    h1 ^= h1 >> 16
    # to signed 32-bit
    return h1 - 0x100000000 if h1 & 0x80000000 else h1


def _hash(b64: bytes) -> int:
    try:
        import mmh3  # fast path if available
        return mmh3.hash(b64)
    except Exception:  # noqa: BLE001
        return _murmur3_32(b64)


def favicon_hash(content: bytes) -> int:
    """Shodan-compatible favicon hash of raw favicon bytes."""
    return _hash(base64.encodebytes(content))


def shodan_query(fav_hash: int) -> str:
    return f"http.favicon.hash:{fav_hash}"


async def fetch_favicon(url: str, timeout: float = 12.0,
                        http_session=None) -> tuple[bytes, str]:
    """Fetch a favicon; if url is a bare host, try /favicon.ico over https/http."""
    import aiohttp
    candidates = []
    if url.startswith("http"):
        candidates.append(url)
    else:
        host = url.rstrip("/")
        candidates += [f"https://{host}/favicon.ico", f"http://{host}/favicon.ico"]
    owns = False
    try:
        if http_session is None:
            http_session = make_http_session(timeout)
            owns = True
        for u in candidates:
            try:
                async with http_session.get(
                    u, ssl=False, timeout=aiohttp.ClientTimeout(total=timeout),
                    allow_redirects=True,
                ) as r:
                    if r.status == 200:
                        data = await r.read()
                        if data:
                            return data, ""
            except Exception:  # noqa: BLE001
                continue
    finally:
        if owns and http_session is not None:
            await http_session.close()
    return b"", f"couldn't fetch a favicon from {url}"


async def pivot(host_or_url: str, do_shodan: bool = False,
                session: Optional[Session] = None,
                on_stage: Optional[Callable[[str], None]] = None,
                http_session=None) -> list[Finding]:
    """Hash a favicon and (optionally) pivot on Shodan to co-located hosts."""
    if on_stage:
        on_stage(f"favicon {host_or_url}")
    content, err = await fetch_favicon(host_or_url, http_session=http_session)
    findings: list[Finding] = []
    if err:
        f = Finding("favicon", "error", err, "favicon", Severity.INFO)
        findings.append(f)
        if session is not None:
            session.add(f)
        return findings

    fh = favicon_hash(content)
    query = shodan_query(fh)
    findings.append(Finding(
        "favicon", host_or_url,
        f"favicon hash {fh}  ({query})", "favicon", Severity.INFO,
        meta={"hash": fh, "query": query, "shodan_query": query,
              "bytes": len(content)}))

    if do_shodan:
        from ..config import has_shodan
        if not has_shodan():
            findings.append(Finding(
                "favicon", "shodan",
                "add a Shodan key to pivot: ezrecon config set shodan_api_key …",
                "favicon", Severity.INFO))
        else:
            from . import shodan_recon
            if on_stage:
                on_stage(f"shodan {query}")
            hits = await shodan_recon.search(query, session=session)
            findings.extend(hits)

    if session is not None:
        session.add_many([f for f in findings if f.category == "favicon"])
        session.record_query(f"favicon:{host_or_url}")
    return findings
