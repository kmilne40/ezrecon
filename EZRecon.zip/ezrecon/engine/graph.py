"""Entity graph built from a recon Session.

A second rendering of the findings you already have: nodes are entities
(domain, subdomain, IP, ASN/netblock, email, port/service, dork hit) and edges
are the relationships between them. Both the TUI graph and the HTML export
consume this model, so there is one source of truth.

Nothing here does I/O - it just reshapes a Session. Pivots (which do run recon)
live in ``pivots.py``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from ..models import Session

# node kinds and their display colours (phosphor palette)
KIND_COLOUR = {
    "domain": "#b6ffce",
    "subdomain": "#33ff66",
    "ip": "#ffb000",
    "asn": "#7dffb0",
    "email": "#ff8fbf",
    "port": "#66d9ff",
    "dork": "#1f8a3a",
    "host": "#33ff66",
}


@dataclass
class Node:
    id: str                 # stable unique id, e.g. "ip:1.2.3.4"
    kind: str               # domain|subdomain|ip|asn|email|port|dork
    label: str              # display text
    meta: dict = field(default_factory=dict)

    @property
    def colour(self) -> str:
        return KIND_COLOUR.get(self.kind, "#33ff66")


@dataclass
class Edge:
    source: str             # node id
    target: str             # node id
    rel: str                # resolves-to | announced-by | has-email | runs | found-via


@dataclass
class Graph:
    nodes: dict[str, Node] = field(default_factory=dict)
    edges: list[Edge] = field(default_factory=list)
    _edge_keys: set = field(default_factory=set)

    def add_node(self, node_id: str, kind: str, label: str, **meta) -> str:
        if node_id not in self.nodes:
            self.nodes[node_id] = Node(node_id, kind, label, dict(meta))
        else:
            # enrich existing node's meta without losing anything
            self.nodes[node_id].meta.update({k: v for k, v in meta.items() if v})
        return node_id

    def add_edge(self, source: str, target: str, rel: str) -> None:
        key = (source, target, rel)
        if source in self.nodes and target in self.nodes and key not in self._edge_keys:
            self.edges.append(Edge(source, target, rel))
            self._edge_keys.add(key)

    def neighbours(self, node_id: str) -> list[tuple["Node", str, str]]:
        """Return [(neighbour_node, rel, direction), ...] for a node."""
        out = []
        for e in self.edges:
            if e.source == node_id and e.target in self.nodes:
                out.append((self.nodes[e.target], e.rel, "->"))
            elif e.target == node_id and e.source in self.nodes:
                out.append((self.nodes[e.source], e.rel, "<-"))
        return out

    def by_kind(self, kind: str) -> list[Node]:
        return [n for n in self.nodes.values() if n.kind == kind]

    def to_dict(self) -> dict:
        return {
            "nodes": [
                {"id": n.id, "kind": n.kind, "label": n.label,
                 "colour": n.colour, "meta": n.meta}
                for n in self.nodes.values()
            ],
            "edges": [
                {"source": e.source, "target": e.target, "rel": e.rel}
                for e in self.edges
            ],
        }


def build_graph(session: Session, existing: Optional[Graph] = None) -> Graph:
    """Walk a Session into an entity graph (idempotent / re-runnable)."""
    g = existing or Graph()
    target = session.target.strip().lower()
    if target:
        g.add_node(f"domain:{target}", "domain", target)

    for f in session.findings:
        cat, key, val = f.category, f.key, f.value

        if cat == "subdomain":
            if key in ("wildcard", "crt.sh", "error"):
                continue
            host = key.strip().lower()
            sid = g.add_node(f"subdomain:{host}", "subdomain", host,
                             source=f.source)
            if target:
                g.add_edge(f"domain:{target}", sid, "has-subdomain")
            for ip in (f.meta.get("ips") or []):
                iid = g.add_node(f"ip:{ip}", "ip", ip)
                g.add_edge(sid, iid, "resolves-to")

        elif cat == "dns":
            if key == "A" and val:
                iid = g.add_node(f"ip:{val}", "ip", val)
                if target:
                    g.add_edge(f"domain:{target}", iid, "resolves-to")
            elif key == "MX" and val:
                host = val.split()[-1].lower()
                mid = g.add_node(f"subdomain:{host}", "subdomain", host, role="mx")
                if target:
                    g.add_edge(f"domain:{target}", mid, "mail-exchange")

        elif cat == "asn":
            asn = f.meta.get("asn", "")
            prefix = f.meta.get("prefix", key)
            aid = g.add_node(f"asn:{prefix}", "asn",
                             f"AS{asn} {prefix}".strip(),
                             asn=asn, prefix=prefix,
                             as_name=f.meta.get("as_name", ""))
            for ip in (f.meta.get("ips") or []):
                iid = g.add_node(f"ip:{ip}", "ip", ip)
                g.add_edge(iid, aid, "announced-by")

        elif cat == "email":
            addr = key.strip().lower()
            eid = g.add_node(f"email:{addr}", "email", addr)
            origin = f.meta.get("via_chain") or f.meta.get("url", "")
            host = ""
            if origin:
                from ..engine.base import normalise_target
                host = normalise_target(origin).lower()
            anchor = f"subdomain:{host}" if host and f"subdomain:{host}" in g.nodes \
                else (f"domain:{target}" if target else "")
            if anchor:
                g.add_edge(anchor, eid, "has-email")

        elif cat == "port":
            if key in ("fingerprint", "error"):
                if key == "fingerprint" and target:
                    g.nodes.get(f"domain:{target}", Node("", "", "")).meta[
                        "fingerprint"] = val
                continue
            pid = g.add_node(f"port:{target}:{key}", "port", f"{key}/{f.meta.get('service','')}".rstrip('/'),
                             banner=f.meta.get("banner", ""),
                             hint=f.meta.get("hint", ""))
            if target:
                g.add_edge(f"domain:{target}", pid, "runs")

        elif cat == "dork":
            url = f.meta.get("url", "")
            if f.source.startswith("dork-link"):
                did = g.add_node(f"dork:{key}", "dork", key, url=url)
                if target:
                    g.add_edge(f"domain:{target}", did, "dork")
            elif url:  # API dork hit -> a real result URL
                did = g.add_node(f"dork:{url}", "dork", (val[:40] or url), url=url)
                if target:
                    g.add_edge(f"domain:{target}", did, "found-via-dork")

    return g
