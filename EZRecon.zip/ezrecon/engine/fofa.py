"""FOFA infrastructure search (keyed).

FOFA (fofa.info) indexes internet-facing assets much like Shodan, and is
particularly strong on infrastructure and certificate/title pivots. This wraps
its JSON API: base64-encode the query, request a fixed set of fields, and turn
each result row into a Finding.

Needs two keys: `fofa_email` and `fofa_key` (set with `ezrecon config
set-key`). Keyless callers get a clear, non-fatal message.

Query syntax examples:
  domain="example.com"        ip="1.2.3.4"        port="23"
  host="mainframe.example"    protocol="tn3270"   title="CICS"
"""

from __future__ import annotations

import base64
import json
from typing import Optional
from urllib.parse import urlencode

from ..config import get_key
from ..models import Finding, Session, Severity
from .base import make_http_session

API = "https://fofa.info/api/v1/search/all"
FIELDS = ["host", "ip", "port", "protocol", "domain", "title", "server",
          "country_name"]

# A compact mainframe-flavoured query set, mirroring the Shodan library.
MAINFRAME_QUERIES = [
    ("TN3270 terminals", 'protocol="tn3270"'),
    ("TSO logon banner", 'banner="IKJ56700A"'),
    ("IBM HTTP/host", 'server="IBM"'),
    ("Db2 / DRDA", 'port="50000"'),
    ("NJE nodes", 'port="175"'),
]


def have_fofa() -> bool:
    return bool(get_key("fofa_email") and get_key("fofa_key"))


def _row_to_dict(row) -> dict:
    d = {f: "" for f in FIELDS}
    if isinstance(row, list):
        for i, f in enumerate(FIELDS):
            if i < len(row):
                d[f] = str(row[i] or "")
    elif isinstance(row, dict):
        for f in FIELDS:
            d[f] = str(row.get(f, "") or "")
    return d


def parse_response(raw: str) -> tuple[list[dict], str]:
    """Parse a FOFA API response body into (rows, error_message)."""
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return [], "unparseable FOFA response"
    if not isinstance(data, dict):
        return [], "unexpected FOFA response"
    if data.get("error"):
        return [], str(data.get("errmsg", "FOFA error"))
    rows = [_row_to_dict(r) for r in data.get("results", [])]
    return rows, ""


def _build_url(query: str, size: int) -> str:
    email, key = get_key("fofa_email"), get_key("fofa_key")
    qb = base64.b64encode(query.encode("utf-8")).decode("ascii")
    params = urlencode({
        "email": email, "key": key, "qbase64": qb,
        "fields": ",".join(FIELDS), "size": max(1, min(size, 100)),
    })
    return f"{API}?{params}"


async def search(query: str, size: int = 20,
                 session: Optional[Session] = None,
                 http_session=None) -> list[Finding]:
    if not have_fofa():
        return [Finding("fofa", "error",
                        "no FOFA credentials (set fofa_email and fofa_key)",
                        "fofa", Severity.INFO)]
    import aiohttp
    owns = False
    raw = ""
    try:
        if http_session is None:
            http_session = make_http_session(20.0)
            owns = True
        async with http_session.get(
                _build_url(query, size),
                timeout=aiohttp.ClientTimeout(total=25.0)) as r:
            raw = await r.text(errors="replace")
    except Exception as e:  # noqa: BLE001
        return [Finding("fofa", "error", f"FOFA request failed: {e}", "fofa")]
    finally:
        if owns and http_session is not None:
            await http_session.close()

    rows, err = parse_response(raw)
    if err:
        return [Finding("fofa", "error", f"FOFA: {err}", "fofa", Severity.INFO)]

    findings: list[Finding] = []
    for m in rows:
        ip, port = m.get("ip", ""), m.get("port", "")
        val = f"{ip}:{port}" if ip else m.get("host", "")
        extra = " | ".join(x for x in (m.get("protocol", ""),
                                       m.get("title", ""),
                                       m.get("server", "")) if x)
        if extra:
            val += f" [{extra}]"
        findings.append(Finding("fofa", m.get("host") or ip, val,
                                f"fofa:{query}", Severity.MEDIUM, meta=m))
    if not findings:
        findings.append(Finding("fofa", "fofa", f"no results for: {query}",
                                "fofa", Severity.INFO))
    if session is not None:
        session.add_many(findings)
        session.record_query(f"fofa:{query}")
    return findings


async def domain_search(domain: str, size: int = 30,
                        session: Optional[Session] = None) -> list[Finding]:
    """All assets FOFA associates with a domain."""
    return await search(f'domain="{domain}"', size=size, session=session)


async def mainframe_sweep(scope: str = "", size: int = 10,
                          session: Optional[Session] = None) -> list[Finding]:
    """Run the mainframe query set, optionally scoped to a domain."""
    if not have_fofa():
        return [Finding("fofa", "error",
                        "no FOFA credentials (set fofa_email and fofa_key)",
                        "fofa", Severity.INFO)]
    findings: list[Finding] = []
    for label, q in MAINFRAME_QUERIES:
        query = f'({q}) && domain="{scope}"' if scope else q
        sub = await search(query, size=size)
        for f in sub:
            if f.key not in ("error", "fofa"):
                f.meta["query_label"] = label
                findings.append(f)
    if session is not None:
        session.add_many(findings)
    return findings
