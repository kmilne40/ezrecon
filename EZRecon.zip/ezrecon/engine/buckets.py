"""Cloud storage bucket discovery.

Organisations name buckets the way they name everything else - descriptively,
with environment suffixes (company-prod-backups, company-db-dumps, company-
terraform-state). That predictability makes brute-forcing from the target's name
plus a suffix wordlist effective, and the names advertise the contents.

Checks candidate names against AWS S3, Google Cloud Storage and Azure Blob using
the documented existence semantics:
  - S3 / GCS: 200 = public listing (data exposed), 403 = exists but private,
    404 = no such bucket.
  - Azure: an account resolves and the container lists only when its access
    level is 'Container'.

Active recon (HTTP to the providers), so gate it behind the active-recon opt-in.
"""

from __future__ import annotations

import asyncio
from typing import Callable, Optional

from ..models import Finding, Session, Severity
from .base import make_http_session

_S3 = "https://s3.amazonaws.com/{}/"
_GCS = "https://storage.googleapis.com/{}/"
_AZURE = "https://{}.blob.core.windows.net/?restype=account&comp=properties"

# environment / content suffixes that dominate real bucket names
_SUFFIXES = [
    "backup", "backups", "bak", "db", "dbdump", "dumps", "data", "logs", "log",
    "assets", "static", "media", "files", "uploads", "images", "img", "public",
    "private", "internal", "prod", "production", "dev", "development", "staging",
    "stage", "test", "qa", "uat", "config", "configs", "secret", "secrets",
    "archive", "archives", "tf", "terraform", "tfstate", "cdn", "www", "web",
    "app", "api", "storage", "share", "docs", "reports", "mainframe", "batch",
]
_SEPS = ["-", ".", "_", ""]


def _bases(domain: str, org: str = "") -> list[str]:
    bases = set()
    if domain:
        parts = domain.split(".")
        bases.add(parts[0])                    # second-level name
        bases.add(domain.replace(".", "-"))    # full domain, dotted->dashed
        bases.add("".join(parts[:-1]))         # concatenated
    if org:
        o = org.strip().lower()
        bases.add(o)
        bases.add(o.replace(" ", ""))
        bases.add(o.replace(" ", "-"))
    return sorted(b for b in bases if b)


def candidates(domain: str, org: str = "", extra: Optional[list[str]] = None,
               cap: int = 300) -> list[str]:
    """Generate bucket-name candidates from the target name + suffixes."""
    out: list[str] = []
    seen: set[str] = set()

    def _add(name: str):
        name = name.lower().strip("-._")
        # S3 bucket naming: 3-63 chars, lowercase, digits, hyphens, dots
        if 3 <= len(name) <= 63 and name not in seen:
            seen.add(name)
            out.append(name)

    for base in _bases(domain, org):
        _add(base)
        for suf in _SUFFIXES:
            for sep in _SEPS:
                _add(f"{base}{sep}{suf}")
                _add(f"{suf}{sep}{base}")
    for e in (extra or []):
        _add(e)
    return out[:cap]


def _verdict(status: int, body: str) -> str:
    low = body.lower()
    if status == 200 and ("<listbucketresult" in low
                          or "<enumerationresults" in low or "<blobs" in low):
        return "public"
    if status == 200:
        return "public"
    if status in (401, 403):
        return "private"
    if status == 400:
        return "exists"      # e.g. Azure account exists but bad query
    return "none"            # 404 / NoSuchBucket / connection error


async def _probe(url: str, http_session, timeout: float) -> tuple[int, str]:
    import aiohttp
    try:
        async with http_session.get(
            url, timeout=aiohttp.ClientTimeout(total=timeout),
            allow_redirects=True,
        ) as r:
            body = await r.content.read(2048)
            return r.status, body.decode("latin-1", "replace")
    except Exception:  # noqa: BLE001
        return 0, ""


async def check_name(name: str, http_session, do_azure: bool = False,
                     timeout: float = 8.0) -> list[dict]:
    """Check one candidate across providers; return hits (exists/public)."""
    hits = []
    providers = [("s3", _S3.format(name)), ("gcs", _GCS.format(name))]
    if do_azure:
        providers.append(("azure", _AZURE.format(name)))
    for prov, url in providers:
        status, body = await _probe(url, http_session, timeout)
        verdict = _verdict(status, body)
        if verdict in ("public", "private", "exists"):
            hits.append({"provider": prov, "name": name,
                         "verdict": verdict, "url": url, "status": status})
    return hits


async def check_all(domain: str, org: str = "", session: Optional[Session] = None,
                    do_azure: bool = False, cap: int = 300, concurrency: int = 20,
                    extra: Optional[list[str]] = None,
                    on_stage: Optional[Callable[[str], None]] = None,
                    http_session=None) -> list[Finding]:
    """Enumerate bucket candidates and report those that exist / are public."""
    names = candidates(domain, org, extra, cap)
    sem = asyncio.Semaphore(concurrency)
    findings: list[Finding] = []
    owns = http_session is None
    if owns:
        http_session = make_http_session(8.0)

    async def _one(name: str):
        async with sem:
            if on_stage:
                on_stage(f"bucket {name}")
            for hit in await check_name(name, http_session, do_azure=do_azure):
                sev = (Severity.HIGH if hit["verdict"] == "public"
                       else Severity.MEDIUM)
                label = {"public": "PUBLIC (listable)",
                         "private": "exists (private)",
                         "exists": "exists"}[hit["verdict"]]
                findings.append(Finding(
                    "bucket", f"{hit['provider']}:{name}",
                    f"[{hit['provider'].upper()}] {name} — {label}: {hit['url']}",
                    "buckets", sev,
                    meta={"provider": hit["provider"], "name": name,
                          "verdict": hit["verdict"], "url": hit["url"]}))

    try:
        await asyncio.gather(*[_one(n) for n in names])
    finally:
        if owns and http_session is not None:
            await http_session.close()

    public = sum(1 for f in findings if f.meta.get("verdict") == "public")
    summary = Finding(
        "bucket", "summary",
        f"checked {len(names)} candidates across "
        f"{'S3/GCS/Azure' if do_azure else 'S3/GCS'}; "
        f"{len(findings)} exist, {public} publicly listable",
        "buckets", Severity.INFO,
        meta={"checked": len(names), "found": len(findings), "public": public})
    findings.insert(0, summary)
    if session is not None and findings:
        session.add_many(findings)
        session.record_query(f"buckets:{domain}")
    return findings
