"""Discovery chaining.

When a run turns up new subdomains, those hosts are worth feeding back into
the email spider (as extra crawl seeds) and into the dork set (as `site:<host>`
searches). This module builds that plan from a session and, on request,
executes the chosen parts. It never runs the API dork path - chaining only ever
produces no-cost link dorks and spider crawls.
"""

from __future__ import annotations

from typing import Callable, Optional

from ..models import Finding, Session, Severity
from . import email_scraper, google_dork


def discovered_subdomains(session: Session) -> list[str]:
    """Unique, resolvable-looking subdomain hosts found so far."""
    hosts: list[str] = []
    for f in session.by_category("subdomain"):
        if f.key in ("wildcard", "crt.sh", "error"):
            continue
        host = f.key.strip().lower()
        if host and "." in host and host not in hosts:
            hosts.append(host)
    return hosts


def build_plan(session: Session, cap: int = 10,
               already_seeded: Optional[set[str]] = None) -> dict:
    """What chaining *would* do: the hosts, the dork links, the spider seeds."""
    already_seeded = already_seeded or set()
    hosts = [h for h in discovered_subdomains(session) if h not in already_seeded]
    hosts = hosts[:cap]
    dork_queries = [f"site:{h}" for h in hosts]
    return {
        "hosts": hosts,
        "dork_queries": dork_queries,
        "spider_seeds": list(hosts),
        "total_hosts": len(discovered_subdomains(session)),
        "capped": len(discovered_subdomains(session)) > cap,
        "cap": cap,
    }


async def run_chain(
    session: Session,
    plan: dict,
    engine: str = "google",
    do_links: bool = True,
    do_spider: bool = True,
    spider_depth: int = 1,
    spider_concurrency: int = 20,
    on_stage: Optional[Callable[[str], None]] = None,
) -> list[Finding]:
    """Execute a chaining plan: link dorks for each host, spider each seed."""
    findings: list[Finding] = []

    def stage(msg: str):
        if on_stage:
            on_stage(msg)

    if do_links and plan["dork_queries"]:
        stage(f"chaining: {len(plan['dork_queries'])} site: dork links")
        findings += google_dork.links_for_queries(
            plan["dork_queries"], engine=engine, session=session)

    if do_spider and plan["spider_seeds"]:
        for host in plan["spider_seeds"]:
            stage(f"chaining: spider {host}")
            sub = await email_scraper.scrape(
                host, max_depth=spider_depth, concurrency=spider_concurrency,
                session=session)
            # tag the origin so the report shows where these came from
            for f in sub:
                if f.category == "email":
                    f.meta["via_chain"] = host
            findings += sub

    session.notes.append(
        f"chained {len(plan['hosts'])} subdomain(s) into "
        f"{'links ' if do_links else ''}{'+ spider' if do_spider else ''}".strip())
    return findings
