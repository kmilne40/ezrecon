"""Graph pivots.

A pivot takes a selected graph node, runs a recon action scoped to it, and
writes the results back into the Session so the graph re-renders with new,
connected nodes. This is the Maltego loop, reusing the existing engine.

Every pivot here reaches out over the network (resolve, scan, spider, dork
links are the exception), so callers gate the active ones behind the
active-recon opt-in.
"""

from __future__ import annotations

from typing import Callable, Optional

from ..models import Finding, Session, Severity
from . import asn as asn_mod
from . import crtsh, dns_recon, email_scraper, google_dork, ports, shodan_recon
from .base import is_valid_ip, normalise_target

# what pivots are offered for each node kind: (id, label, active?)
PIVOTS: dict[str, list[tuple[str, str, bool]]] = {
    "domain": [
        ("dns", "DNS records", True),
        ("crtsh", "crt.sh subdomains", True),
        ("dork_links", "Dork links (no key)", False),
        ("subdomains", "Subdomain brute", True),
    ],
    "subdomain": [
        ("resolve", "Resolve to IP", True),
        ("ports", "Port / banner scan", True),
        ("spider", "Email spider", True),
        ("dork_links", "Dork links (no key)", False),
    ],
    "ip": [
        ("reverse", "Reverse DNS", True),
        ("asn", "ASN / netblock", True),
        ("shodan_host", "Shodan host lookup", True),
        ("ports", "Port / banner scan", True),
    ],
    "asn": [
        ("shodan_net", "Shodan sweep netblock", True),
    ],
    "email": [
        ("dork_email", "Dork this address (links)", False),
    ],
    "dork": [
        ("open", "Open URL in browser", False),
    ],
}


def pivots_for(kind: str) -> list[tuple[str, str, bool]]:
    return PIVOTS.get(kind, [])


async def run_pivot(
    pivot_id: str,
    node,               # graph.Node
    session: Session,
    on_stage: Optional[Callable[[str], None]] = None,
) -> list[Finding]:
    """Execute a pivot for a node; results are added to the session."""
    def stage(msg: str):
        if on_stage:
            on_stage(msg)

    label = node.label
    kind = node.kind

    if pivot_id == "dns":
        stage(f"dns {label}")
        return await dns_recon.dns_lookup(label, session=session)

    if pivot_id == "crtsh":
        stage(f"crt.sh {label}")
        return await crtsh.crtsh_lookup(label, session=session)

    if pivot_id == "subdomains":
        from . import subdomains
        stage(f"subdomain brute {label}")
        return await subdomains.brute_force(label, session=session)

    if pivot_id == "resolve":
        stage(f"resolve {label}")
        return await dns_recon.dns_lookup(label, session=session)

    if pivot_id == "ports":
        stage(f"port scan {label}")
        f, _ = await ports.scan(label, session=session)
        return f

    if pivot_id == "spider":
        stage(f"spider {label}")
        return await email_scraper.scrape(label, max_depth=1, session=session)

    if pivot_id == "reverse":
        stage(f"reverse dns {label}")
        return await dns_recon.reverse_dns(label, session=session)

    if pivot_id == "asn":
        stage(f"asn {label}")
        ip = label if is_valid_ip(label) else ""
        return await asn_mod.enrich_ips([ip] if ip else [], session=session)

    if pivot_id == "shodan_host":
        stage(f"shodan host {label}")
        return await shodan_recon.host_info(label, session=session)

    if pivot_id == "shodan_net":
        prefix = node.meta.get("prefix", "")
        stage(f"shodan net {prefix}")
        query = f"net:{prefix}" if prefix else ""
        if not query:
            return [Finding("shodan", "error", "no netblock on node", "shodan")]
        return await shodan_recon.search(query, session=session)

    if pivot_id == "dork_links":
        stage(f"dork links {label}")
        return google_dork.links_for_queries([f"site:{label}"], session=session)

    if pivot_id == "dork_email":
        stage(f"dork email {label}")
        return google_dork.links_for_queries([f'"{label}"'], session=session)

    return [Finding("info", "pivot", f"no such pivot: {pivot_id}", "graph")]
