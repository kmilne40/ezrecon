"""SearXNG results engine (keyless, self-hosted).

Queries a local (or configured) SearXNG instance's JSON API. Because the
instance is yours, it doesn't rate-limit or bot-block you the way DuckDuckGo or
the (now closed-to-new-customers) Google API do. Set it up in one command with
`ezrecon searx setup`.

SearXNG disables the JSON output format by default; `ezrecon searx setup`
enables it. If it isn't enabled the API returns 403, which we translate into a
clear fix rather than a bare error.
"""

from __future__ import annotations

from urllib.parse import quote_plus

from ..config import get_setting
from .base import make_http_session


def searx_url() -> str:
    """Configured SearXNG base URL (empty if not set)."""
    return str(get_setting("searx_url", "") or "").rstrip("/")


def has_searx() -> bool:
    return bool(searx_url())


def _friendly(status: int, base: str) -> str:
    if status == 403:
        return ("SearXNG refused the request (403). Its JSON output format is "
                "not enabled — run `ezrecon searx setup` (which enables it), or "
                "add `json` under `search.formats` in the instance's "
                "settings.yml and restart it.")
    if status in (0, -1):
        return (f"Couldn't reach SearXNG at {base}. Is it running? Start it with "
                "`ezrecon searx setup` (or `ezrecon searx status` to check).")
    return f"SearXNG returned HTTP {status}."


async def searx_search(query: str, limit: int = 10, base: str = "",
                       timeout: float = 15.0, http_session=None):
    """Query the SearXNG JSON API. Returns (results, error)."""
    import aiohttp

    from .webintel import Result  # local import avoids a cycle

    base = (base or searx_url()).rstrip("/")
    if not base:
        return [], ("No SearXNG instance configured. Run `ezrecon searx setup` "
                    "to stand one up, or set it with "
                    "`ezrecon config set-setting searx_url http://host:8080`.")
    url = f"{base}/search?q={quote_plus(query)}&format=json"
    owns = False
    try:
        if http_session is None:
            http_session = make_http_session(timeout)
            owns = True
        async with http_session.get(
            url, timeout=aiohttp.ClientTimeout(total=timeout),
        ) as resp:
            if resp.status != 200:
                return [], _friendly(resp.status, base)
            data = await resp.json(content_type=None)
    except Exception as e:  # noqa: BLE001
        return [], (f"Couldn't reach SearXNG at {base} ({e}). Start it with "
                    "`ezrecon searx setup`.")
    finally:
        if owns and http_session is not None:
            await http_session.close()

    results = []
    for item in (data.get("results") or [])[:limit]:
        u = item.get("url", "")
        if not u:
            continue
        results.append(Result(
            title=item.get("title", "") or u,
            url=u,
            snippet=item.get("content", "") or "",
            source="searx",
        ))
    if not results:
        return [], "SearXNG returned no results for that query."
    return results, ""
