"""Native (non-nmap) async connect scan + banner grab.

Connect-only: opens a TCP socket, reads whatever banner the service offers,
and hands it to the fingerprinter. Scans the mainframe port profile by
default. This is deliberately not nmap - no SYN scanning, no NSE - just a fast
asyncio connect sweep so EZRecon can flag a live mainframe on its own.
"""

from __future__ import annotations

import asyncio
from typing import Callable, Optional

from .. import fingerprint
from ..models import Finding, PortResult, Session, Severity
from .base import is_valid_domain, is_valid_ip, normalise_target


async def _probe(host: str, port: int, timeout: float) -> PortResult:
    service = fingerprint.service_for_port(port)
    try:
        fut = asyncio.open_connection(host, port)
        reader, writer = await asyncio.wait_for(fut, timeout=timeout)
    except (asyncio.TimeoutError, OSError):
        return PortResult(port=port, state="closed", service=service)

    banner = ""
    try:
        # give talkative services a moment to send a banner first
        try:
            data = await asyncio.wait_for(reader.read(512), timeout=1.5)
            banner = data.decode(errors="replace").strip()
        except asyncio.TimeoutError:
            data = b""
        if not banner:
            # nudge HTTP-ish / quiet services
            try:
                writer.write(b"\r\n")
                await writer.drain()
                data = await asyncio.wait_for(reader.read(512), timeout=1.5)
                banner = data.decode(errors="replace").strip()
            except (asyncio.TimeoutError, OSError):
                pass
    finally:
        try:
            writer.close()
            await asyncio.wait_for(writer.wait_closed(), timeout=1.0)
        except (asyncio.TimeoutError, OSError):
            pass

    hits = fingerprint.match_banner(banner)
    hint = "; ".join(h for h, _ in hits)
    return PortResult(port=port, state="open", service=service,
                      banner=banner[:400], mainframe_hint=hint)


async def scan(
    target: str,
    ports: Optional[list[int]] = None,
    concurrency: int = 200,
    timeout: float = 4.0,
    session: Optional[Session] = None,
    on_progress: Optional[Callable[[int, int], None]] = None,
) -> tuple[list[Finding], list[PortResult]]:
    host = normalise_target(target)
    if not (is_valid_domain(host) or is_valid_ip(host)):
        return [Finding("port", "error", f"invalid target: {target}", "portscan")], []

    ports = ports or fingerprint.default_ports()
    sem = asyncio.Semaphore(concurrency)
    done = 0
    total = len(ports)
    lock = asyncio.Lock()

    async def run(port: int) -> PortResult:
        nonlocal done
        async with sem:
            res = await _probe(host, port, timeout)
        async with lock:
            done += 1
            if on_progress:
                on_progress(done, total)
        return res

    results = await asyncio.gather(*[run(p) for p in ports])
    open_results = [r for r in results if r.state == "open"]

    findings: list[Finding] = []
    for r in open_results:
        sev = Severity.MEDIUM if r.mainframe_hint else Severity.INFO
        value = f"{r.service or 'open'}"
        if r.banner:
            value += f" | {r.banner[:120]}"
        findings.append(
            Finding("port", str(r.port), value, "portscan", sev,
                    meta={"service": r.service, "banner": r.banner,
                          "hint": r.mainframe_hint})
        )

    conf, reasons = fingerprint.score(
        [r.port for r in open_results], [r.banner for r in open_results]
    )
    if conf > 0:
        findings.append(
            Finding("port", "fingerprint",
                    f"{fingerprint.verdict(conf)} ({conf}% confidence)",
                    "fingerprint",
                    Severity.HIGH if conf >= 70 else Severity.MEDIUM,
                    meta={"confidence": conf, "reasons": reasons})
        )
    if session is not None:
        session.add_many(findings)
        session.record_query(f"portscan:{host}:{','.join(map(str, ports))}")
    return findings, open_results
