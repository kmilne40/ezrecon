"""ASN / netblock enrichment via Team Cymru's DNS service.

Pure DNS, no API key, no external binary. For each IP we query
``<reversed-ip>.origin.asn.cymru.com`` (TXT) to get the ASN and BGP prefix,
then ``AS<n>.asn.cymru.com`` (TXT) for the AS name. Grouping hosts by ASN and
netblock often reveals the organisation's own address space - which is exactly
where mainframes live.
"""

from __future__ import annotations

import asyncio
from typing import Iterable, Optional

import dns.exception
import dns.resolver

from ..models import Finding, Session, Severity
from .base import async_resolver, is_valid_ip


def _reverse_v4(ip: str) -> str:
    return ".".join(reversed(ip.split(".")))


async def _origin(resolver, ip: str) -> Optional[dict]:
    """Return {asn, prefix, cc, registry} for an IPv4 address, or None."""
    try:
        ans = await resolver.resolve(f"{_reverse_v4(ip)}.origin.asn.cymru.com", "TXT")
    except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN,
            dns.resolver.NoNameservers, dns.exception.DNSException):
        return None
    txt = ans[0].to_text().strip('"')
    # "36459 | 140.82.112.0/20 | US | arin | 2018-04-25"
    parts = [p.strip() for p in txt.split("|")]
    if len(parts) < 4:
        return None
    asn = parts[0].split()[0]  # sometimes multiple ASNs share the prefix
    return {"asn": asn, "prefix": parts[1], "cc": parts[2], "registry": parts[3]}


async def _as_name(resolver, asn: str) -> str:
    try:
        ans = await resolver.resolve(f"AS{asn}.asn.cymru.com", "TXT")
    except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN,
            dns.resolver.NoNameservers, dns.exception.DNSException):
        return ""
    txt = ans[0].to_text().strip('"')
    # "36459 | US | arin | 2012-11-13 | GITHUB - GitHub, Inc., US"
    parts = [p.strip() for p in txt.split("|")]
    return parts[-1] if parts else ""


async def enrich_ips(
    ips: Iterable[str],
    timeout: float = 4.0,
    concurrency: int = 20,
    session: Optional[Session] = None,
) -> list[Finding]:
    """Enrich a set of IPv4 addresses with ASN + netblock, deduped by prefix."""
    unique = sorted({ip.strip() for ip in ips if is_valid_ip(ip) and ":" not in ip})
    if not unique:
        return []
    resolver = async_resolver(timeout)
    sem = asyncio.Semaphore(concurrency)
    as_name_cache: dict[str, str] = {}
    seen_prefix: dict[str, list[str]] = {}  # prefix -> [ips]
    origins: dict[str, dict] = {}

    async def one(ip: str):
        async with sem:
            info = await _origin(resolver, ip)
            if not info:
                return
            origins[ip] = info
            seen_prefix.setdefault(info["prefix"], []).append(ip)
            if info["asn"] not in as_name_cache:
                as_name_cache[info["asn"]] = await _as_name(resolver, info["asn"])

    await asyncio.gather(*[one(ip) for ip in unique])

    findings: list[Finding] = []
    for prefix, prefix_ips in sorted(seen_prefix.items()):
        sample = origins[prefix_ips[0]]
        name = as_name_cache.get(sample["asn"], "")
        value = (f"AS{sample['asn']}"
                 f"{(' ' + name) if name else ''} | {prefix} | {sample['cc']} | "
                 f"{len(prefix_ips)} host(s): {', '.join(sorted(prefix_ips)[:8])}")
        findings.append(
            Finding("asn", prefix, value, "cymru", Severity.LOW,
                    meta={"asn": sample["asn"], "prefix": prefix,
                          "cc": sample["cc"], "as_name": name,
                          "ips": sorted(prefix_ips)})
        )
    if session is not None:
        session.add_many(findings)
        session.record_query(f"asn-enrich:{len(unique)} ips")
    return findings


def ips_from_session(session: Session) -> set[str]:
    """Collect every IPv4 address the session has discovered so far."""
    ips: set[str] = set()
    for f in session.findings:
        for ip in f.meta.get("ips", []) or []:
            if is_valid_ip(ip) and ":" not in ip:
                ips.add(ip)
        # DNS A-record findings carry the address as the value
        if f.category == "dns" and f.key == "A" and is_valid_ip(f.value):
            ips.add(f.value)
    return ips
