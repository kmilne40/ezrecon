"""Have I Been Pwned breach lookup.

Checks the email addresses EZRecon has discovered against HIBP's breach
database. A breached account that exposed passwords is a direct lead for
credential-stuffing against the target's TSO/web/VPN logins; even a
PII-only breach informs phishing.

Needs an HIBP API key (`ezrecon config set hibp_api_key <KEY>`). The API is
rate-limited per subscription tier, so requests are paced and Retry-After is
honoured.
"""

from __future__ import annotations

import asyncio
import json
from typing import Callable, Optional
from urllib.parse import quote

from ..config import get_key
from ..models import Finding, Session, Severity
from .base import make_http_session

_API = "https://haveibeenpwned.com/api/v3/breachedaccount/"
# data classes that make a breach high-severity for an attacker
_CREDENTIAL_CLASSES = {"passwords", "password hints", "security questions and answers",
                       "auth tokens", "encrypted keys", "private keys"}


def has_key() -> bool:
    return bool(get_key("hibp_api_key"))


async def check_account(email: str, timeout: float = 15.0,
                        http_session=None) -> tuple[list[dict], str, float]:
    """Return (breaches, error, retry_after_seconds) for one email."""
    import aiohttp
    key = get_key("hibp_api_key")
    if not key:
        return [], "no HIBP key (config set hibp_api_key <KEY>)", 0.0
    url = f"{_API}{quote(email)}?truncateResponse=false"
    headers = {"hibp-api-key": key, "User-Agent": "EZRecon"}
    owns = False
    try:
        if http_session is None:
            http_session = make_http_session(timeout)
            owns = True
        async with http_session.get(
            url, headers=headers, timeout=aiohttp.ClientTimeout(total=timeout),
        ) as r:
            if r.status == 404:
                return [], "", 0.0                 # not breached (clean)
            if r.status == 401:
                return [], "HIBP key invalid (401)", 0.0
            if r.status == 429:
                ra = float(r.headers.get("Retry-After", "2") or 2)
                return [], "rate-limited", ra
            if r.status != 200:
                return [], f"HIBP HTTP {r.status}", 0.0
            data = json.loads(await r.text())
            return data, "", 0.0
    except Exception as e:  # noqa: BLE001
        return [], f"HIBP error: {e}", 0.0
    finally:
        if owns and http_session is not None:
            await http_session.close()


def _severity(breaches: list[dict]) -> Severity:
    classes = set()
    for b in breaches:
        for c in b.get("DataClasses", []):
            classes.add(c.lower())
    if classes & _CREDENTIAL_CLASSES:
        return Severity.HIGH
    return Severity.MEDIUM if breaches else Severity.INFO


def emails_from_session(session: Session) -> list[str]:
    import re
    rx = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
    out: list[str] = []
    for f in session.by_category("email"):
        for e in rx.findall(f"{f.key} {f.value}"):
            e = e.lower()
            if e not in out:
                out.append(e)
    return out


async def check_emails(emails: list[str], session: Optional[Session] = None,
                       pace: float = 1.6, cap: int = 200,
                       on_stage: Optional[Callable[[str], None]] = None,
                       http_session=None) -> list[Finding]:
    """Check each email against HIBP, pacing to respect rate limits."""
    if not has_key():
        f = Finding("breach", "error",
                    "no HIBP key. Add one: ezrecon config set hibp_api_key <KEY>",
                    "hibp", Severity.INFO)
        if session is not None:
            session.add(f)
        return [f]

    findings: list[Finding] = []
    breached = 0
    checked = 0
    owns = http_session is None
    if owns:
        http_session = make_http_session(15.0)
    try:
        for email in emails[:cap]:
            if on_stage:
                on_stage(f"hibp {email}")
            breaches, err, retry = await check_account(email,
                                                       http_session=http_session)
            if retry:  # rate-limited: wait and retry once
                await asyncio.sleep(retry + 0.2)
                breaches, err, retry = await check_account(
                    email, http_session=http_session)
            checked += 1
            if err:
                findings.append(Finding("breach", "error", err, "hibp",
                                        Severity.INFO))
                if "invalid" in err or "no HIBP" in err:
                    break
            elif breaches:
                breached += 1
                names = ", ".join(b.get("Name", "?") for b in breaches)
                classes = sorted({c for b in breaches
                                  for c in b.get("DataClasses", [])})
                findings.append(Finding(
                    "breach", email,
                    f"{email} in {len(breaches)} breach(es): {names}",
                    "hibp", _severity(breaches),
                    meta={"email": email, "breaches":
                          [b.get("Name") for b in breaches],
                          "data_classes": classes}))
            await asyncio.sleep(pace)
    finally:
        if owns and http_session is not None:
            await http_session.close()

    summary = Finding(
        "breach", "summary",
        f"checked {checked} emails; {breached} appear in known breaches",
        "hibp", Severity.INFO, meta={"checked": checked, "breached": breached})
    findings.insert(0, summary)
    if session is not None and findings:
        session.add_many(findings)
        session.record_query(f"hibp:{checked} emails")
    return findings
