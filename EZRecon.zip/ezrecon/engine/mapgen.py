"""Standalone Leaflet + OpenStreetMap map files.

A terminal cannot render a slippy map, so eZrecon writes a self-contained HTML
file you open in a browser: Leaflet from a CDN, OpenStreetMap tiles (no key), a
marker per located IP with a popup. `map_<ip>.html` for one host, or an estate
map with every geolocated host.

Viewing needs internet (for the Leaflet script and the map tiles); generating
the file does not.
"""

from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Optional

from ..config import output_dir

_LEAFLET_CSS = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
_LEAFLET_JS = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
_TILES = "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"


def _page(title: str, markers: list[dict], center: tuple, zoom: int) -> str:
    esc = lambda s: html.escape(str(s), quote=True)
    pts = json.dumps(markers)
    return f"""<!doctype html><html><head><meta charset="utf-8">
<title>{esc(title)}</title>
<link rel="stylesheet" href="{_LEAFLET_CSS}"/>
<style>html,body,#map{{height:100%;margin:0;background:#060a06;}}
 .leaflet-popup-content{{font:13px/1.4 monospace;}}</style>
</head><body><div id="map"></div>
<script src="{_LEAFLET_JS}"></script>
<script>
 var pts = {pts};
 var map = L.map('map').setView([{center[0]}, {center[1]}], {zoom});
 L.tileLayer('{_TILES}', {{maxZoom: 19,
   attribution: '&copy; OpenStreetMap contributors'}}).addTo(map);
 var group = [];
 pts.forEach(function(p){{
   if (p.lat == null || p.lon == null) return;
   var m = L.marker([p.lat, p.lon]).addTo(map);
   m.bindPopup('<b>'+p.title+'</b><br>'+p.detail);
   group.push([p.lat, p.lon]);
 }});
 if (group.length > 1) map.fitBounds(group, {{padding:[40,40]}});
</script></body></html>"""


def _marker(rec: dict) -> dict:
    esc = lambda s: html.escape(str(s), quote=False)
    detail = "<br>".join(x for x in (
        esc(", ".join(y for y in (rec.get("city", ""), rec.get("country", "")) if y)),
        esc(rec.get("isp", "")), esc(rec.get("asn", ""))) if x)
    return {"lat": rec.get("lat"), "lon": rec.get("lon"),
            "title": esc(rec.get("ip", "")), "detail": detail}


def write_ip_map(rec: dict, out: Optional[Path] = None) -> Path:
    """rec is a geo record dict (ip, lat, lon, city, country, isp, asn)."""
    out = Path(out) if out else output_dir()
    out.mkdir(parents=True, exist_ok=True)
    path = out / f"map_{rec.get('ip', 'ip').replace(':', '_')}.html"
    lat, lon = rec.get("lat"), rec.get("lon")
    center = (lat if lat is not None else 20, lon if lon is not None else 0)
    zoom = 10 if lat is not None else 2
    path.write_text(_page(f"eZrecon — {rec.get('ip','')}",
                          [_marker(rec)], center, zoom), encoding="utf-8")
    return path


def write_estate_map(records: list[dict], out: Optional[Path] = None,
                     target: str = "") -> Path:
    """records: list of geo record dicts for every located host."""
    out = Path(out) if out else output_dir()
    out.mkdir(parents=True, exist_ok=True)
    path = out / f"map_estate_{(target or 'hosts').replace('.', '_')}.html"
    markers = [_marker(r) for r in records if r.get("lat") is not None]
    center = (markers[0]["lat"], markers[0]["lon"]) if markers else (20, 0)
    path.write_text(_page(f"eZrecon estate — {target}", markers, center, 3),
                    encoding="utf-8")
    return path


def geo_records_from_session(session) -> list[dict]:
    """Pull the geo findings' meta back out as records for the estate map."""
    out = []
    for f in session.by_category("geo"):
        if f.meta.get("lat") is not None:
            out.append(f.meta)
    return out
