"""CTI RSS feed reader.

An integrated security-news reader: fetch the configured feeds concurrently,
show the latest items, open them, optionally email a selection, and - the useful
twist for a recon tool - highlight items that mention the current target or
mainframe keywords.

Self-contained: uses the existing aiohttp (no httpx) and a stdlib XML parser for
RSS 2.0 and Atom (no feedparser). If feedparser happens to be installed it's used
as a more tolerant fast path. Email uses stdlib smtplib with SMTP settings from
EZRecon's config vault (never hard-coded).

Adapted from Kev's cti-rss.py.
"""

from __future__ import annotations

import asyncio
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional
from xml.etree import ElementTree as ET

from ..config import get_key, get_setting, load_config
from .base import make_http_session

_FEEDS_FILE = Path(__file__).parent.parent / "data" / "rss_feeds.json"
MAX_ITEMS = 15
_TAG = re.compile(r"<[^>]+>")


@dataclass
class Item:
    title: str
    link: str
    published: str = ""
    summary: str = ""
    feed: str = ""
    relevant: bool = False


@dataclass
class Feed:
    name: str
    url: str
    items: list = field(default_factory=list)
    error: str = ""


def load_feeds(path: Optional[str] = None) -> list[dict]:
    p = Path(path) if path else _FEEDS_FILE
    try:
        return json.loads(p.read_text()).get("feeds", [])
    except Exception:  # noqa: BLE001
        return []


def _clean(text: str, limit: int = 300) -> str:
    text = _TAG.sub("", text or "").strip()
    text = re.sub(r"\s+", " ", text)
    return text[:limit]


def _localname(tag: str) -> str:
    return tag.rsplit("}", 1)[-1] if "}" in tag else tag


def parse_feed(content: bytes, feed_name: str = "") -> list[Item]:
    """Parse RSS 2.0 / RDF / Atom. feedparser if available, else stdlib."""
    try:
        import feedparser  # optional, more tolerant
        parsed = feedparser.parse(content)
        out = []
        for e in parsed.entries[:MAX_ITEMS]:
            out.append(Item(
                title=getattr(e, "title", "(no title)") or "(no title)",
                link=getattr(e, "link", ""),
                published=getattr(e, "published", "") or getattr(e, "updated", ""),
                summary=_clean(getattr(e, "summary", "")),
                feed=feed_name))
        if out:
            return out
    except Exception:  # noqa: BLE001
        pass

    # stdlib fallback
    try:
        root = ET.fromstring(content)
    except Exception:  # noqa: BLE001
        return []
    items: list[Item] = []

    # RSS 2.0 / RDF: <item> under channel (or root)
    rss_items = [el for el in root.iter() if _localname(el.tag) == "item"]
    if rss_items:
        for el in rss_items[:MAX_ITEMS]:
            d = {_localname(c.tag): (c.text or "") for c in el}
            link = d.get("link", "")
            items.append(Item(
                title=d.get("title", "(no title)") or "(no title)",
                link=link.strip(),
                published=d.get("pubDate", "") or d.get("date", ""),
                summary=_clean(d.get("description", "") or d.get("encoded", "")),
                feed=feed_name))
        return items

    # Atom: <entry>
    for el in [e for e in root.iter() if _localname(e.tag) == "entry"][:MAX_ITEMS]:
        title = ""
        link = ""
        published = ""
        summary = ""
        for c in el:
            ln = _localname(c.tag)
            if ln == "title":
                title = (c.text or "").strip()
            elif ln == "link":
                # prefer rel=alternate / no rel; take href
                rel = c.attrib.get("rel", "alternate")
                if rel in ("alternate", "") and c.attrib.get("href"):
                    link = c.attrib["href"]
                elif not link and c.attrib.get("href"):
                    link = c.attrib["href"]
            elif ln in ("published", "updated") and not published:
                published = (c.text or "").strip()
            elif ln in ("summary", "content") and not summary:
                summary = _clean(c.text or "")
        items.append(Item(title=title or "(no title)", link=link,
                          published=published, summary=summary, feed=feed_name))
    return items


async def fetch_feed(url: str, name: str = "", timeout: float = 12.0,
                     http_session=None) -> Feed:
    import aiohttp
    owns = False
    try:
        if http_session is None:
            http_session = make_http_session(timeout)
            owns = True
        async with http_session.get(
            url, timeout=aiohttp.ClientTimeout(total=timeout),
            headers={"User-Agent": "EZRecon-RSS/1.0"},
        ) as r:
            if r.status != 200:
                return Feed(name or url, url, [], f"HTTP {r.status}")
            content = await r.read()
    except Exception as e:  # noqa: BLE001
        return Feed(name or url, url, [], str(e))
    finally:
        if owns and http_session is not None:
            await http_session.close()
    return Feed(name or url, url, parse_feed(content, name or url))


def _mark_relevant(items: list[Item], terms: list[str]) -> int:
    n = 0
    low_terms = [t.lower() for t in terms if t]
    for it in items:
        blob = f"{it.title} {it.summary}".lower()
        if any(t in blob for t in low_terms):
            it.relevant = True
            n += 1
    return n


async def fetch_all(feeds_cfg: Optional[list[dict]] = None,
                    concurrency: int = 8, timeout: float = 12.0,
                    highlight_terms: Optional[list[str]] = None,
                    on_stage: Optional[Callable[[str], None]] = None,
                    http_session=None) -> list[Feed]:
    feeds_cfg = feeds_cfg if feeds_cfg is not None else load_feeds()
    sem = asyncio.Semaphore(concurrency)
    results: list[Feed] = [None] * len(feeds_cfg)  # type: ignore

    async def _one(i: int, cfg: dict):
        async with sem:
            name = cfg.get("name") or cfg.get("url", "")
            if on_stage:
                on_stage(f"fetch {name}")
            results[i] = await fetch_feed(cfg.get("url", ""), name,
                                          timeout=timeout,
                                          http_session=http_session)

    await asyncio.gather(*[_one(i, c) for i, c in enumerate(feeds_cfg)])
    if highlight_terms:
        for f in results:
            if f and f.items:
                _mark_relevant(f.items, highlight_terms)
    return [f for f in results if f is not None]


# --------------------------------------------------------------------------
# email (stdlib smtplib; settings from the config vault, never hard-coded)
# --------------------------------------------------------------------------
def smtp_settings() -> dict:
    cfg = load_config()
    s = cfg.get("settings", {})
    return {
        "host": s.get("smtp_host", ""),
        "port": int(s.get("smtp_port", 587) or 587),
        "security": (s.get("smtp_security", "starttls") or "starttls").lower(),
        "username": get_key("smtp_username") or s.get("smtp_username", ""),
        "password": get_key("smtp_password"),
        "from": s.get("smtp_from", ""),
        "to": s.get("smtp_to", ""),
    }


def smtp_configured() -> bool:
    s = smtp_settings()
    return bool(s["host"] and s["from"])


def send_email(subject: str, links: list[str], body: str = "",
               to_override: str = "") -> tuple[bool, str]:
    import smtplib
    import ssl
    from email.message import EmailMessage

    s = smtp_settings()
    if not s["host"]:
        return False, ("SMTP not configured. Set it with `ezrecon config "
                       "set-setting smtp_host …`, smtp_from, smtp_to, and "
                       "`ezrecon config set smtp_username/smtp_password`.")
    to_list = [x.strip() for x in (to_override or s["to"]).split(",") if x.strip()]
    if not to_list:
        return False, "no recipient (set smtp_to or pass a recipient)."

    msg = EmailMessage()
    msg["From"] = s["from"]
    msg["To"] = ", ".join(to_list)
    msg["Subject"] = subject.strip()
    lines = [body.strip()] if body else []
    if links:
        lines += ["", "Links:"]
        lines += [f"{i:>2}. {u}" for i, u in enumerate(links, 1)]
    msg.set_content("\n".join(lines))

    try:
        ctx = ssl.create_default_context()
        if s["security"] == "ssl":
            with smtplib.SMTP_SSL(s["host"], s["port"], timeout=20,
                                  context=ctx) as srv:
                if s["username"]:
                    srv.login(s["username"], s["password"])
                srv.send_message(msg)
        else:
            with smtplib.SMTP(s["host"], s["port"], timeout=20) as srv:
                if s["security"] == "starttls":
                    srv.starttls(context=ctx)
                if s["username"]:
                    srv.login(s["username"], s["password"])
                srv.send_message(msg)
    except Exception as e:  # noqa: BLE001
        return False, f"send failed: {e}"
    return True, f"sent to {', '.join(to_list)}"
