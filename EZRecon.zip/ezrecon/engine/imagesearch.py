"""Reverse image provenance — where does this image already appear online?

This is about the IMAGE, not the person in it. It finds other public pages that
host the same (or a visually similar) picture, which is what you want for
verifying a profile photo, spotting reused stock or AI-generated fakes, catching
brand impersonation, or tracing a leaked document scan. It never attempts facial
recognition or identity matching of a person.

Two paths, both keyless:
  * links  — build the reverse-search URLs for Google Lens, Bing, Yandex,
             TinEye and Karma Decay, plus the image's perceptual hash, so you
             can open them yourself (no upload from eZrecon).
  * hash   — compute a perceptual hash (average-hash, pure-Python) so you can
             recognise the same image again across a set.

Automated querying of the reverse-search engines needs a browser session and
breaks their terms, so eZrecon builds the links rather than scraping them; open
them in your browser to see the matches.
"""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Callable, Optional
from urllib.parse import quote

from ..models import Finding, Session, Severity


def average_hash(path: str, hash_size: int = 8) -> str:
    """A pure-Pillow perceptual average-hash: same image -> same hash, small
    edits -> close hash. Hex string of hash_size*hash_size bits."""
    from PIL import Image
    img = Image.open(path).convert("L").resize(
        (hash_size, hash_size), Image.LANCZOS)
    px = list(img.getdata())
    avg = sum(px) / len(px)
    bits = "".join("1" if p >= avg else "0" for p in px)
    return f"{int(bits, 2):0{hash_size * hash_size // 4}x}"


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def reverse_search_links(path: str) -> list[tuple[str, str]]:
    """The reverse-image-search engine URLs to open by hand. These take an
    image URL; for a local file, upload it on the engine's own page (we link to
    the upload entry points where the engine offers one)."""
    return [
        ("Google Lens", "https://lens.google.com/uploadbyurl?url="),
        ("Bing Visual", "https://www.bing.com/visualsearch"),
        ("Yandex", "https://yandex.com/images/search?rpt=imageview"),
        ("TinEye", "https://tineye.com/"),
        ("KarmaDecay", "https://karmadecay.com/"),
    ]


def reverse_search_links_for_url(image_url: str) -> list[tuple[str, str]]:
    """When you already have a public URL for the image, these run directly."""
    u = quote(image_url, safe="")
    return [
        ("Google Lens", f"https://lens.google.com/uploadbyurl?url={u}"),
        ("Bing", f"https://www.bing.com/images/search?q=imgurl:{u}&view=detailv2&iss=sbi"),
        ("Yandex", f"https://yandex.com/images/search?rpt=imageview&url={u}"),
        ("TinEye", f"https://tineye.com/search?url={u}"),
    ]


async def provenance(path: str, session: Optional[Session] = None,
                     on_stage: Optional[Callable[[str], None]] = None
                     ) -> list[Finding]:
    p = Path(path)
    if not p.exists():
        return [Finding("image", "error", f"file not found: {path}", "image")]
    findings: list[Finding] = []
    try:
        if on_stage:
            on_stage("hashing image")
        ah = average_hash(str(p))
        sh = sha256_file(str(p))
        findings.append(Finding(
            "image", "phash", ah, "image", Severity.INFO,
            meta={"sha256": sh,
                  "why": "perceptual hash of the image — matches the same "
                         "picture again even after minor edits",
                  "impact": "recognise re-uploads/duplicates across a set",
                  "remediation": "informational"}))
    except Exception as e:  # noqa: BLE001
        findings.append(Finding("image", "note",
                                f"could not hash image: {e}", "image"))

    for name, url in reverse_search_links(str(p)):
        findings.append(Finding(
            "image", name, f"open and upload the image here: {url}",
            "image-reverse", Severity.INFO,
            meta={"url": url,
                  "why": "reverse-image-search engine — finds other public "
                         "pages hosting the same image",
                  "impact": "provenance, duplicate/fake detection, brand abuse",
                  "remediation": "informational"}))
    findings.append(Finding(
        "image", "note",
        "This checks where the IMAGE appears online. It does not identify the "
        "person in a photo — eZrecon does not do facial recognition.",
        "image", Severity.INFO))

    if session is not None:
        session.add_many(findings)
        session.record_query(f"image-provenance:{p.name}")
    return findings
