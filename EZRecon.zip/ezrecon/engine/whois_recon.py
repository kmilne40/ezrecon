"""WHOIS lookups.

Prefers the python-whois library (no external binary needed), and falls back
to the system ``whois`` command if the library is unavailable. Runs the
blocking call in a thread so it plays nicely inside the async engine.
"""

from __future__ import annotations

import asyncio
import shutil
import subprocess
from typing import Optional

from ..models import Finding, Session, Severity
from .base import is_valid_domain

INTERESTING = [
    ("registrar", "Registrar"),
    ("creation_date", "Created"),
    ("expiration_date", "Expires"),
    ("updated_date", "Updated"),
    ("name_servers", "Name servers"),
    ("emails", "Emails"),
    ("org", "Org"),
    ("country", "Country"),
    ("dnssec", "DNSSEC"),
]


def _fmt(value) -> str:
    if isinstance(value, (list, tuple, set)):
        vals = [str(v) for v in value if v]
        return ", ".join(sorted(set(vals)))
    return str(value) if value else ""


def _parse_python_whois(domain: str) -> list[Finding]:
    import whois  # python-whois

    w = whois.whois(domain)
    findings: list[Finding] = []
    for attr, label in INTERESTING:
        val = _fmt(getattr(w, attr, None) or (w.get(attr) if hasattr(w, "get") else None))
        if val:
            findings.append(Finding("whois", label, val, "whois"))
    if not findings and getattr(w, "text", ""):
        findings.append(Finding("whois", "raw", w.text[:2000], "whois"))
    return findings


def _parse_system_whois(domain: str, timeout: float) -> list[Finding]:
    out = subprocess.check_output(
        ["whois", domain], stderr=subprocess.STDOUT, text=True, timeout=timeout
    )
    return [Finding("whois", "raw", out[:4000], "whois")]


async def whois_lookup(
    domain: str, timeout: float = 15.0, session: Optional[Session] = None
) -> list[Finding]:
    domain = domain.strip().rstrip(".")
    if not is_valid_domain(domain):
        return [Finding("whois", "error", f"invalid domain: {domain}", "whois")]

    loop = asyncio.get_event_loop()
    findings: list[Finding] = []
    try:
        findings = await loop.run_in_executor(None, _parse_python_whois, domain)
    except Exception:  # noqa: BLE001 - fall back to system binary
        if shutil.which("whois"):
            try:
                findings = await loop.run_in_executor(
                    None, _parse_system_whois, domain, timeout
                )
            except Exception:  # noqa: BLE001
                findings = []
    if not findings:
        findings = [Finding("whois", "error",
                            "whois unavailable (install python-whois or the whois binary)",
                            "whois", Severity.INFO)]
    if session is not None:
        session.add_many(findings)
        session.record_query(f"whois:{domain}")
    return findings
