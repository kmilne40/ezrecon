"""WHOIS lookups with pen-tester-oriented interpretation.

Prefers the python-whois library (no external binary needed), falls back to the
system ``whois`` command, and — new — interprets the EPP domain-status codes
(is the domain locked against transfer/hijack?), extracts the registrar abuse
contact, and computes domain age and days-to-expiry. Runs the blocking call in
a thread so it plays nicely inside the async engine.
"""

from __future__ import annotations

import asyncio
import re
import shutil
import subprocess
from datetime import datetime, timezone
from typing import Optional

from ..models import Finding, Session, Severity
from .base import is_valid_domain

# Fields worth surfacing, in report order.
INTERESTING = [
    ("registrar", "Registrar"),
    ("registrar_url", "Registrar URL"),
    ("whois_server", "WHOIS server"),
    ("creation_date", "Created"),
    ("updated_date", "Updated"),
    ("expiration_date", "Expires"),
    ("name_servers", "Name servers"),
    ("org", "Registrant org"),
    ("registrant_name", "Registrant"),
    ("country", "Country"),
    ("emails", "Emails"),
]

# EPP status codes -> (plain-English meaning, severity when PRESENT).
# The pen-test angle: the *absence* of the transfer/update/delete locks is the
# risk (domain hijack / unauthorised change), so we report on that separately.
STATUS_MEANING = {
    "clienttransferprohibited": ("registrar lock: transfers blocked", Severity.INFO),
    "servertransferprohibited": ("registry lock: transfers blocked", Severity.INFO),
    "clientupdateprohibited": ("registrar lock: updates blocked", Severity.INFO),
    "serverupdateprohibited": ("registry lock: updates blocked", Severity.INFO),
    "clientdeleteprohibited": ("registrar lock: deletion blocked", Severity.INFO),
    "serverdeleteprohibited": ("registry lock: deletion blocked", Severity.INFO),
    "clientrenewprohibited": ("renewal blocked by registrar", Severity.INFO),
    "clienthold": ("clientHold — domain is NOT in the zone (suspended)", Severity.MEDIUM),
    "serverhold": ("serverHold — domain is NOT in the zone (suspended)", Severity.MEDIUM),
    "pendingdelete": ("pendingDelete — domain is being removed", Severity.MEDIUM),
    "pendingtransfer": ("pendingTransfer — a transfer is in progress", Severity.MEDIUM),
    "pendingupdate": ("pendingUpdate — a change is in progress", Severity.LOW),
    "redemptionperiod": ("redemptionPeriod — expired, recoverable by owner", Severity.MEDIUM),
    "autorenewperiod": ("autoRenewPeriod — recently auto-renewed", Severity.INFO),
    "inactive": ("inactive — no name servers delegated", Severity.LOW),
    "ok": ("ok/active — no registrar locks set", Severity.LOW),
    "active": ("ok/active — no registrar locks set", Severity.LOW),
}

_ABUSE_EMAIL_RE = re.compile(
    r"(?im)^(?:registrar abuse contact email|abuse contact email)\s*:\s*(\S+)")
_ABUSE_PHONE_RE = re.compile(
    r"(?im)^(?:registrar abuse contact phone|abuse contact phone)\s*:\s*(\S+)")
_STATUS_RE = re.compile(r"(?im)^\s*(?:domain status|status)\s*:\s*([a-zA-Z]+)")
_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")


def _fmt(value) -> str:
    if isinstance(value, (list, tuple, set)):
        vals = [str(v) for v in value if v]
        return ", ".join(sorted(set(vals)))
    return str(value) if value else ""


def _first_date(value):
    if isinstance(value, (list, tuple)):
        for v in value:
            if v:
                return v
        return None
    return value


def _as_dt(value):
    d = _first_date(value)
    if isinstance(d, datetime):
        return d
    if isinstance(d, str):
        for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d",
                    "%d-%b-%Y", "%Y.%m.%d"):
            try:
                return datetime.strptime(d[:19], fmt)
            except ValueError:
                continue
    return None


def _status_codes(w) -> list[str]:
    """Normalised, de-duplicated EPP status codes from a whois result."""
    raw = getattr(w, "status", None)
    if raw is None and hasattr(w, "get"):
        raw = w.get("status")
    codes: list[str] = []
    items = raw if isinstance(raw, (list, tuple, set)) else ([raw] if raw else [])
    for item in items:
        # values look like "clientTransferProhibited https://icann.org/epp#..."
        token = str(item).strip().split()[0] if str(item).strip() else ""
        token = token.lower().rstrip(",")
        if token:
            codes.append(token)
    return sorted(set(codes))


def _interpret_status(codes: list[str]) -> list[Finding]:
    findings: list[Finding] = []
    for code in codes:
        meaning, sev = STATUS_MEANING.get(
            code, (f"status: {code}", Severity.INFO))
        findings.append(Finding("whois", "status", f"{code} — {meaning}",
                                "whois", sev, meta={"code": code}))
    # the headline pen-test read: is transfer locked?
    transfer_locked = any(c in ("clienttransferprohibited",
                                 "servertransferprohibited") for c in codes)
    if codes:
        if transfer_locked:
            findings.append(Finding(
                "whois", "transfer-lock",
                "domain is locked against transfer (clientTransferProhibited)",
                "whois", Severity.INFO, meta={"locked": True}))
        else:
            findings.append(Finding(
                "whois", "transfer-lock",
                "NO transfer lock set — domain transfers are not prohibited "
                "(registrar-hijack exposure; confirm registrar-lock is enabled)",
                "whois", Severity.MEDIUM, meta={"locked": False}))
    return findings


def _date_findings(w) -> list[Finding]:
    out: list[Finding] = []
    created = _as_dt(getattr(w, "creation_date", None)
                     or (w.get("creation_date") if hasattr(w, "get") else None))
    expires = _as_dt(getattr(w, "expiration_date", None)
                     or (w.get("expiration_date") if hasattr(w, "get") else None))
    now = datetime.utcnow()
    if created:
        age_days = (now - created).days
        yrs = age_days / 365.25
        out.append(Finding("whois", "domain-age",
                            f"registered {created.date()} (~{yrs:.1f} years old)",
                            "whois", Severity.INFO, meta={"age_days": age_days}))
    if expires:
        days_left = (expires - now).days
        sev = (Severity.MEDIUM if days_left < 60 else
               Severity.LOW if days_left < 180 else Severity.INFO)
        note = "" if days_left >= 60 else "  (expiring soon)"
        out.append(Finding("whois", "expiry",
                           f"expires {expires.date()} ({days_left} days){note}",
                           "whois", sev, meta={"days_left": days_left}))
    return out


def _dnssec_finding(w) -> Optional[Finding]:
    val = getattr(w, "dnssec", None) or (w.get("dnssec") if hasattr(w, "get") else None)
    s = _fmt(val).lower()
    if not s:
        return None
    if s in ("unsigned", "no", "false", "0"):
        return Finding("whois", "DNSSEC", "unsigned (DNSSEC not enabled)",
                       "whois", Severity.LOW)
    return Finding("whois", "DNSSEC", _fmt(val), "whois", Severity.INFO)


def _abuse_findings(text: str) -> list[Finding]:
    out: list[Finding] = []
    if not text:
        return out
    m = _ABUSE_EMAIL_RE.search(text)
    if m:
        out.append(Finding("whois", "abuse-email", m.group(1), "whois",
                           Severity.INFO, meta={"email": m.group(1)}))
    m = _ABUSE_PHONE_RE.search(text)
    if m:
        out.append(Finding("whois", "abuse-phone", m.group(1), "whois",
                           Severity.INFO))
    return out


def _parse_python_whois(domain: str) -> list[Finding]:
    import whois  # python-whois

    w = whois.whois(domain)
    findings: list[Finding] = []
    for attr, label in INTERESTING:
        val = _fmt(getattr(w, attr, None)
                   or (w.get(attr) if hasattr(w, "get") else None))
        if val:
            findings.append(Finding("whois", label, val, "whois"))

    findings += _interpret_status(_status_codes(w))
    findings += _date_findings(w)
    ds = _dnssec_finding(w)
    if ds:
        findings.append(ds)
    findings += _abuse_findings(getattr(w, "text", "") or "")

    # privacy/redaction hint (useful to know before you trust registrant data)
    text_l = (getattr(w, "text", "") or "").lower()
    if any(k in text_l for k in ("redacted for privacy", "privacy protect",
                                 "whoisguard", "data protected", "gdpr")):
        findings.append(Finding("whois", "privacy",
                                "registrant data is privacy-protected / redacted",
                                "whois", Severity.INFO))
    if not findings and getattr(w, "text", ""):
        findings.append(Finding("whois", "raw", w.text[:2000], "whois"))
    return findings


def _parse_system_whois(domain: str, timeout: float) -> list[Finding]:
    out = subprocess.check_output(
        ["whois", domain], stderr=subprocess.STDOUT, text=True, timeout=timeout)
    findings: list[Finding] = []
    codes = sorted({m.lower() for m in _STATUS_RE.findall(out)})
    findings += _interpret_status(codes)
    findings += _abuse_findings(out)
    for label, rx in (("Registrar", r"(?im)^registrar:\s*(.+)$"),
                      ("Created", r"(?im)^creation date:\s*(.+)$"),
                      ("Expires", r"(?im)^registry expiry date:\s*(.+)$"),
                      ("DNSSEC", r"(?im)^dnssec:\s*(.+)$")):
        m = re.search(rx, out)
        if m:
            findings.append(Finding("whois", label, m.group(1).strip(), "whois"))
    ns = sorted({m.strip().lower() for m in
                 re.findall(r"(?im)^name server:\s*(.+)$", out)})
    if ns:
        findings.append(Finding("whois", "Name servers", ", ".join(ns), "whois"))
    if not findings:
        findings.append(Finding("whois", "raw", out[:4000], "whois"))
    return findings


async def whois_lookup(
    domain: str, timeout: float = 15.0, session: Optional[Session] = None
) -> list[Finding]:
    domain = domain.strip().rstrip(".")
    if not is_valid_domain(domain):
        return [Finding("whois", "error", f"invalid domain: {domain}", "whois")]

    loop = asyncio.get_event_loop()
    findings: list[Finding] = []
    try:
        findings = await loop.run_in_executor(None, _parse_python_whois, domain)
    except Exception:  # noqa: BLE001 - fall back to system binary
        if shutil.which("whois"):
            try:
                findings = await loop.run_in_executor(
                    None, _parse_system_whois, domain, timeout)
            except Exception:  # noqa: BLE001
                findings = []
    if not findings:
        findings = [Finding("whois", "error",
                            "whois unavailable (install python-whois or the whois binary)",
                            "whois", Severity.INFO)]
    if session is not None:
        session.add_many(findings)
        session.record_query(f"whois:{domain}")
    return findings
