"""Keyless IP geolocation (ip-api.com).

Turns an IP into an approximate location plus the network it belongs to (ISP,
org, ASN). This is routing/registration data, not a physical address or a
person — the map it feeds is for infrastructure context only.
"""

from __future__ import annotations

import json
from typing import Optional

from ..models import Finding, Session, Severity
from .base import is_valid_ip, make_http_session

API = "http://ip-api.com/json/{ip}?fields=status,message,country,regionName,city,lat,lon,isp,org,as,query"


def parse(raw: str) -> tuple[dict, str]:
    """Parse an ip-api.com response into (record, error)."""
    try:
        d = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return {}, "unparseable geo response"
    if not isinstance(d, dict):
        return {}, "unexpected geo response"
    if d.get("status") != "success":
        return {}, str(d.get("message", "geolocation failed"))
    return {
        "ip": d.get("query", ""),
        "lat": d.get("lat"), "lon": d.get("lon"),
        "city": d.get("city", ""), "region": d.get("regionName", ""),
        "country": d.get("country", ""),
        "isp": d.get("isp", ""), "org": d.get("org", ""), "asn": d.get("as", ""),
    }, ""


async def geolocate(ip: str, session: Optional[Session] = None,
                    http_session=None) -> list[Finding]:
    ip = ip.strip()
    if not is_valid_ip(ip):
        return [Finding("geo", "error", f"invalid IP: {ip}", "geo")]
    import aiohttp
    owns = False
    raw = ""
    try:
        if http_session is None:
            http_session = make_http_session(15.0)
            owns = True
        async with http_session.get(
                API.format(ip=ip),
                timeout=aiohttp.ClientTimeout(total=15.0)) as r:
            raw = await r.text(errors="replace")
    except Exception as e:  # noqa: BLE001
        return [Finding("geo", "error", f"geo lookup failed: {e}", "geo")]
    finally:
        if owns and http_session is not None:
            await http_session.close()

    rec, err = parse(raw)
    if err:
        return [Finding("geo", "error", f"geo: {err}", "geo", Severity.INFO)]

    loc = ", ".join(x for x in (rec["city"], rec["region"], rec["country"]) if x)
    net = " / ".join(x for x in (rec["isp"], rec["org"], rec["asn"]) if x)
    findings = [
        Finding("geo", ip, f"{loc}  [{net}]", "geo", Severity.INFO,
                meta={"lat": rec["lat"], "lon": rec["lon"], "ip": ip,
                      "city": rec["city"], "country": rec["country"],
                      "isp": rec["isp"], "org": rec["org"], "asn": rec["asn"],
                      "why": "approximate routing/registration location of the "
                             "IP (the ISP's point of presence, not a physical "
                             "address or person)",
                      "impact": "context for where infrastructure is hosted and "
                                "who operates the network",
                      "remediation": "informational"}),
    ]
    if session is not None:
        session.add_many(findings)
        session.record_query(f"geo:{ip}")
    return findings
