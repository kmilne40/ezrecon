"""Wayback Machine / CDX historical URL harvesting.

The Internet Archive's CDX API returns every URL ever archived under a domain -
including admin panels, API endpoints, config files, backups, and forgotten apps
that active scanning misses because they're no longer linked (or no longer live
but still archived). Pure passive OSINT, no key.

Endpoint:
  https://web.archive.org/cdx/search/cdx?url=*.<domain>/*&output=json
      &fl=original,statuscode,timestamp,mimetype&collapse=urlkey&limit=N

Results are classified for the things worth a second look - with extra weight on
mainframe artefacts (JCL/COBOL/copybooks/REXX/HLASM) for this tool's audience.
"""

from __future__ import annotations

import json
from typing import Callable, Optional
from urllib.parse import quote

from ..models import Finding, Session, Severity
from .base import make_http_session

_CDX = "https://web.archive.org/cdx/search/cdx"

# interesting path/extension buckets -> (label, severity)
_MAINFRAME_EXT = (".jcl", ".cbl", ".cob", ".cpy", ".pli", ".pl1", ".rexx",
                  ".rex", ".asm", ".hlasm", ".bms", ".map", ".proc", ".mac")
_SECRET_EXT = (".env", ".pem", ".key", ".ppk", ".pfx", ".p12", "id_rsa",
               ".ini", ".cfg", ".conf", ".config", "web.config", ".yml",
               ".yaml", ".properties", ".htpasswd", ".netrc")
_BACKUP_EXT = (".bak", ".old", ".backup", ".swp", ".save", ".sql", ".dump",
               ".zip", ".tar", ".gz", ".tgz", ".7z", ".rar")
_DATA_EXT = (".json", ".xml", ".csv", ".xls", ".xlsx", ".log")
_VCS = ("/.git/", "/.svn/", "/.hg/", "/.bzr/")
_ADMIN = ("/admin", "/login", "/wp-admin", "/phpmyadmin", "/manager/",
          "/console", "/.git", "/backup", "/config", "/setup", "/install",
          "/api/", "/actuator", "/jenkins", "/jmx-console")


def _classify(url: str) -> Optional[tuple[str, Severity]]:
    low = url.lower()
    if any(low.endswith(e) or e in low for e in _MAINFRAME_EXT):
        return "mainframe artefact", Severity.HIGH
    if any(e in low for e in _SECRET_EXT):
        return "secret/config", Severity.HIGH
    if any(low.endswith(e) or (e + "?") in low for e in _BACKUP_EXT):
        return "backup/archive", Severity.MEDIUM
    if any(v in low for v in _VCS):
        return "exposed VCS", Severity.HIGH
    if any(a in low for a in _ADMIN):
        return "admin/interesting path", Severity.LOW
    if any(low.endswith(e) or (e + "?") in low for e in _DATA_EXT):
        return "data/endpoint", Severity.LOW
    return None


def build_cdx_url(domain: str, limit: int = 5000, subdomains: bool = True,
                  status_ok_only: bool = False) -> str:
    target = f"*.{domain}/*" if subdomains else f"{domain}/*"
    url = (f"{_CDX}?url={quote(target)}&output=json"
           "&fl=original,statuscode,timestamp,mimetype"
           f"&collapse=urlkey&limit={limit}")
    if status_ok_only:
        url += "&filter=statuscode:200"
    return url


def parse_cdx(text: str) -> list[dict]:
    """Parse CDX JSON: first row is the header, the rest are records."""
    try:
        rows = json.loads(text)
    except Exception:  # noqa: BLE001
        return []
    if not rows or len(rows) < 2:
        return []
    header = rows[0]
    out = []
    for r in rows[1:]:
        rec = dict(zip(header, r))
        if rec.get("original"):
            out.append(rec)
    return out


async def fetch(domain: str, limit: int = 5000, subdomains: bool = True,
                status_ok_only: bool = False, timeout: float = 30.0,
                http_session=None) -> tuple[list[dict], str]:
    import aiohttp
    url = build_cdx_url(domain, limit, subdomains, status_ok_only)
    owns = False
    try:
        if http_session is None:
            http_session = make_http_session(timeout)
            owns = True
        async with http_session.get(
            url, timeout=aiohttp.ClientTimeout(total=timeout),
        ) as r:
            if r.status != 200:
                return [], f"CDX API returned HTTP {r.status}"
            text = await r.text()
    except Exception as e:  # noqa: BLE001
        return [], (f"couldn't reach the Wayback CDX API ({e}). It occasionally "
                    "rate-limits; retry, or lower --limit.")
    finally:
        if owns and http_session is not None:
            await http_session.close()
    return parse_cdx(text), ""


async def harvest(domain: str, limit: int = 5000, subdomains: bool = True,
                  status_ok_only: bool = False,
                  session: Optional[Session] = None,
                  on_stage: Optional[Callable[[str], None]] = None,
                  http_session=None) -> list[Finding]:
    """Fetch archived URLs, classify the interesting ones, record findings."""
    if on_stage:
        on_stage(f"wayback CDX {domain}")
    records, err = await fetch(domain, limit, subdomains, status_ok_only,
                               http_session=http_session)
    findings: list[Finding] = []
    if err:
        f = Finding("wayback", "error", err, "wayback", Severity.INFO)
        findings.append(f)
        if session is not None:
            session.add(f)
        return findings

    seen: set[str] = set()
    interesting = 0
    for rec in records:
        url = rec.get("original", "")
        if not url or url in seen:
            continue
        seen.add(url)
        cls = _classify(url)
        if not cls:
            continue
        label, sev = cls
        interesting += 1
        findings.append(Finding(
            "wayback", url, f"[{label}] {url}", "wayback", sev,
            meta={"label": label, "status": rec.get("statuscode", ""),
                  "timestamp": rec.get("timestamp", ""),
                  "mimetype": rec.get("mimetype", ""),
                  "url": url}))

    # a summary finding so the run always reports something useful
    summary = Finding(
        "wayback", "summary",
        f"{len(seen)} archived URLs; {interesting} flagged as interesting",
        "wayback", Severity.INFO,
        meta={"total": len(seen), "interesting": interesting})
    findings.insert(0, summary)
    if session is not None:
        session.add_many(findings)
        session.record_query(f"wayback:{domain}")
    return findings
