"""Nmap / NSE command builder.

Reads the *installed* nmap: the script list comes from `scripts/script.db`
(always current - new scripts appear after `nmap --script-updatedb`), and each
script's arguments are parsed from the `.nse` source's NSEDoc `@args
<script>.<arg> <desc>` lines. So the args offered for a chosen script are exactly
that script's args, and custom/book scripts (TN3270/CICS/DB2/DRDA) show up the
moment their .nse files are present - nothing is hardcoded.

This module builds commands (and can locate nmap); it does not run privileged
scans itself.
"""

from __future__ import annotations

import re
import shutil
import subprocess
from pathlib import Path
from typing import Optional

# common locations for the nmap scripts dir across distros / macOS
_SCRIPT_DIR_CANDIDATES = [
    "/usr/share/nmap/scripts",
    "/usr/local/share/nmap/scripts",
    "/opt/homebrew/share/nmap/scripts",
    "/opt/local/share/nmap/scripts",
    "/snap/nmap/current/usr/share/nmap/scripts",
]

# name globs that identify mainframe-relevant scripts (book chapter set + stock)
MAINFRAME_GLOBS = [
    "db2-", "drda-", "tn3270", "tso-", "cics", "vtam", "ims-", "racf",
    "mainframe", "as400", "ibm-",
]


_PRESETS = Path(__file__).parent.parent / "data" / "nse_presets.json"


def load_presets() -> list[dict]:
    import json
    try:
        return json.loads(_PRESETS.read_text()).get("presets", [])
    except Exception:  # noqa: BLE001
        return []


def preset(pid: str) -> Optional[dict]:
    for p in load_presets():
        if p["id"] == pid:
            return p
    return None


def command_from_preset(pid: str, target: str,
                        installed_only: bool = True) -> str:
    """Build a command from a book preset, keeping only installed scripts."""
    p = preset(pid)
    if not p:
        return ""
    scripts = p.get("scripts", [])
    if installed_only:
        have = set(parse_script_db().keys())
        scripts = [s for s in scripts if s in have] or scripts
    return build_command(
        target, scripts=scripts, script_args=p.get("script_args"),
        ports=p.get("ports", ""), timing=p.get("timing", ""),
        scan_type=p.get("scan_type", ""),
        service_version=p.get("service_version", False),
        no_ping=p.get("no_ping", False))


def find_nmap() -> str:
    return shutil.which("nmap") or ""


def have_nmap() -> bool:
    return bool(find_nmap())


def nmap_version() -> str:
    exe = find_nmap()
    if not exe:
        return ""
    try:
        out = subprocess.run([exe, "--version"], capture_output=True, text=True,
                             timeout=10).stdout
        m = re.search(r"Nmap version ([\d.]+)", out)
        return m.group(1) if m else ""
    except Exception:  # noqa: BLE001
        return ""


def scripts_dir() -> Optional[Path]:
    """Locate the installed nmap scripts directory (holds script.db + .nse)."""
    for c in _SCRIPT_DIR_CANDIDATES:
        p = Path(c)
        if (p / "script.db").exists():
            return p
    # ask nmap where its datadir is, as a fallback
    exe = find_nmap()
    if exe:
        try:
            out = subprocess.run([exe, "--datadir-help"], capture_output=True,
                                 text=True, timeout=10).stderr
        except Exception:  # noqa: BLE001
            out = ""
        for line in out.splitlines():
            line = line.strip()
            if line.endswith("scripts") and Path(line, "script.db").exists():
                return Path(line)
    return None


def parse_script_db(db_path: Optional[Path] = None) -> dict[str, list[str]]:
    """Parse script.db -> {script_name: [categories]}.

    Format: Entry { filename = "x.nse", categories = { "safe", "discovery", } }
    """
    if db_path is None:
        d = scripts_dir()
        db_path = (d / "script.db") if d else None
    if not db_path or not Path(db_path).exists():
        return {}
    text = Path(db_path).read_text(errors="replace")
    out: dict[str, list[str]] = {}
    entry_re = re.compile(
        r'Entry\s*\{\s*filename\s*=\s*"([^"]+)"\s*,\s*'
        r'categories\s*=\s*\{([^}]*)\}', re.DOTALL)
    for m in entry_re.finditer(text):
        fname = m.group(1)
        name = fname[:-4] if fname.endswith(".nse") else fname
        cats = re.findall(r'"([^"]+)"', m.group(2))
        out[name] = cats
    return out


def list_scripts(category: Optional[str] = None,
                 mainframe: bool = False) -> list[dict]:
    """Return [{name, categories}] optionally filtered by category / mainframe."""
    db = parse_script_db()
    items = []
    for name, cats in sorted(db.items()):
        if category and category not in cats:
            continue
        if mainframe and not any(g in name for g in MAINFRAME_GLOBS):
            continue
        items.append({"name": name, "categories": cats})
    return items


def mainframe_scripts() -> list[dict]:
    return list_scripts(mainframe=True)


_ARG_RE = re.compile(r'@args\s+([^\s]+)\s+(.*)')


def script_args(name: str, sdir: Optional[Path] = None) -> list[dict]:
    """Parse a script's .nse source for its documented @args.

    Returns [{arg, desc}]. `arg` is normalised to the bare name the user types
    after --script-args (script prefix stripped when present, since nmap accepts
    the short form for the running script).
    """
    sdir = sdir or scripts_dir()
    if not sdir:
        return []
    path = Path(sdir) / f"{name}.nse"
    if not path.exists():
        return []
    text = path.read_text(errors="replace")
    seen: dict[str, str] = {}
    for m in _ARG_RE.finditer(text):
        arg = m.group(1).strip()
        desc = " ".join(m.group(2).split())
        # NSEDoc often writes @args scriptname.argname - keep the full form,
        # it's unambiguous and always valid
        seen.setdefault(arg, desc)
    # also surface stdnse.get_script_args("x") names not documented via @args
    for m in re.finditer(r'get_script_args\(\s*([^)]+)\)', text):
        for lit in re.findall(r'["\']([^"\']+)["\']', m.group(1)):
            seen.setdefault(lit, "(undocumented; referenced in source)")
    return [{"arg": a, "desc": d} for a, d in sorted(seen.items())]


def updatedb() -> tuple[bool, str]:
    """Run `nmap --script-updatedb` to rebuild script.db after adding scripts."""
    exe = find_nmap()
    if not exe:
        return False, "nmap not found"
    try:
        p = subprocess.run([exe, "--script-updatedb"], capture_output=True,
                           text=True, timeout=120)
        return (p.returncode == 0,
                "script database updated" if p.returncode == 0
                else (p.stderr.strip() or "update failed"))
    except Exception as e:  # noqa: BLE001
        return False, str(e)


def build_command(target: str, scripts: Optional[list[str]] = None,
                  script_args: Optional[dict[str, str]] = None,
                  ports: str = "", timing: str = "", scan_type: str = "",
                  service_version: bool = False, default_scripts: bool = False,
                  no_ping: bool = False, os_detect: bool = False,
                  extra: str = "", out_basename: str = "") -> str:
    """Assemble a full nmap command string from builder options."""
    parts = ["nmap"]
    if scan_type:
        parts.append(scan_type)               # -sT / -sS / -sU ...
    if service_version:
        parts.append("-sV")
    if os_detect:
        parts.append("-O")
    if default_scripts and not scripts:
        parts.append("-sC")
    if no_ping:
        parts.append("-Pn")
    if timing:
        parts.append(timing)                  # -T4
    if ports:
        parts.append(f"-p {ports}")
    if scripts:
        parts.append(f'--script {",".join(scripts)}')
    if script_args:
        joined = ",".join(f"{k}={v}" for k, v in script_args.items() if v != "")
        # allow bare flags too (value left blank means "include the key")
        bare = [k for k, v in script_args.items() if v == ""]
        allargs = ",".join(filter(None, [joined, *bare]))
        if allargs:
            parts.append(f'--script-args {allargs}')
    if out_basename:
        parts.append(f"-oA {out_basename}")
    if extra:
        parts.append(extra)
    parts.append(target)
    return " ".join(parts)
