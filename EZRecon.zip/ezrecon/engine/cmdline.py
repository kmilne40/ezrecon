"""Universal, line-authoritative editing of an nmap command line.

The editable command line is the single source of truth. Every helper here
performs a *surgical* edit that touches only its own token, so anything the user
has typed that we don't model (evasion flags, decoys, output options, exotic
targets) is preserved verbatim. Running a command is always shlex.split of the
line, so any valid nmap invocation runs exactly as written.

Nothing in here is mainframe-specific.
"""
from __future__ import annotations

import re
import shlex

# nmap options that consume a following, space-separated argument (i.e. when
# written WITHOUT '='). Used only to tell a target apart from an option value.
# Missing one is fail-safe: it just yields an extra target candidate, and the
# target setter leaves the line untouched when candidates are ambiguous.
ARG_OPTS = frozenset({
    # targets / exclusion / input
    "-iL", "-iR", "--exclude", "--excludefile", "--exclude-ports",
    # ports / discovery
    "-p", "--top-ports", "--port-ratio", "-g", "--source-port",
    # decoys / spoofing / routing
    "-D", "-S", "-e", "-b", "--spoof-mac", "--proxies", "--data",
    "--data-string", "--data-length", "--ip-options", "--ttl", "--mtu",
    # output
    "-oN", "-oX", "-oS", "-oG", "-oA", "--stylesheet", "--resume",
    # timing / performance (value forms)
    "--scan-delay", "--max-scan-delay", "--host-timeout", "--max-retries",
    "--min-rate", "--max-rate", "--min-hostgroup", "--max-hostgroup",
    "--min-parallelism", "--max-parallelism", "--min-rtt-timeout",
    "--max-rtt-timeout", "--initial-rtt-timeout", "--version-intensity",
    # NSE
    "--script", "--script-args", "--script-args-file", "--datadir",
    "--servicedb", "--versiondb",
})


# --------------------------------------------------------------------------
# tokeniser that preserves original spans (so edits can be surgical)
# --------------------------------------------------------------------------
def scan(line: str) -> list[tuple[str, int, int]]:
    """Return [(unquoted_value, start, end)] where line[start:end] is the raw
    token including any surrounding quotes. Respects single and double quotes."""
    toks: list[tuple[str, int, int]] = []
    i, n = 0, len(line)
    while i < n:
        while i < n and line[i].isspace():
            i += 1
        if i >= n:
            break
        start = i
        buf: list[str] = []
        while i < n and not line[i].isspace():
            c = line[i]
            if c in "'\"":
                q = c
                i += 1
                while i < n and line[i] != q:
                    if line[i] == "\\" and q == '"' and i + 1 < n:
                        buf.append(line[i + 1])
                        i += 2
                        continue
                    buf.append(line[i])
                    i += 1
                i += 1  # skip closing quote
            else:
                buf.append(c)
                i += 1
        toks.append(("".join(buf), start, i))
    return toks


def _collapse(line: str) -> str:
    return re.sub(r"\s{2,}", " ", line).strip()


def _sh_quote(s: str) -> str:
    return shlex.quote(s) if s else s


def _insert_before_script(line: str, token: str) -> str:
    """Insert token just before --script/--script-args, else append."""
    for val, s, _e in scan(line):
        if val.split("=", 1)[0] in ("--script", "--script-args"):
            return _collapse(line[:s] + token + " " + line[s:])
    return _collapse(line.rstrip() + " " + token)


# --------------------------------------------------------------------------
# target
# --------------------------------------------------------------------------
def target_spans(line: str) -> list[tuple[int, int, str]]:
    """Spans of the bare target tokens (not options, not option values)."""
    toks = scan(line)
    spans: list[tuple[int, int, str]] = []
    consume = False
    for idx, (val, s, e) in enumerate(toks):
        if idx == 0:  # the 'nmap' program token
            continue
        if consume:
            consume = False
            continue
        if val.startswith("-"):
            opt = val.split("=", 1)[0]
            if "=" not in val and opt in ARG_OPTS:
                consume = True
            continue
        spans.append((s, e, val))
    return spans


def set_target(line: str, target: str) -> str:
    """Replace the single target; append if none; leave alone if ambiguous."""
    target = (target or "").strip()
    spans = target_spans(line)
    if len(spans) > 1:
        return line  # ambiguous — never clobber a multi-target line
    if spans:
        s, e, _ = spans[0]
        if not target:
            return _collapse(line[:s] + line[e:])
        return line[:s] + _sh_quote(target) + line[e:]
    if not target:
        return line
    # no target yet: place right after the program token (book style: first)
    toks = scan(line)
    if toks:
        _v, _s, e = toks[0]
        return _collapse(line[:e] + " " + _sh_quote(target) + line[e:])
    return _collapse(line + " " + _sh_quote(target))


# --------------------------------------------------------------------------
# ports
# --------------------------------------------------------------------------
def _portspec(port: str) -> str:
    p = port.strip()
    if not p:
        return ""
    if p in ("-", "-p-", "-p -"):
        return "-p-"
    if p.startswith("-p"):
        p = p[2:].strip()
    return "-p" + p if p else "-p-"


def set_port(line: str, port: str) -> str:
    toks = scan(line)
    spec = _portspec(port)
    for idx, (val, s, e) in enumerate(toks):
        if val == "-p" and "=" not in val:                 # separate: -p 23
            if idx + 1 < len(toks):
                _nv, ns, ne = toks[idx + 1]
                if not spec:
                    return _collapse(line[:s] + line[ne:])
                return line[:s] + spec + line[ne:]
            if not spec:
                return _collapse(line[:s] + line[e:])
            return line[:e] + " " + spec[2:] + line[e:]
        if val.startswith("-p"):                            # attached / -p-
            if not spec:
                return _collapse(line[:s] + line[e:])
            return line[:s] + spec + line[e:]
    if not spec:
        return line
    return _insert_before_script(line, spec)


# --------------------------------------------------------------------------
# standalone flags (-sV, -Pn, -n, --open, -A, …)
# --------------------------------------------------------------------------
def has_flag(line: str, flag: str) -> bool:
    return any(val == flag for val, _s, _e in scan(line))


def set_flag(line: str, flag: str, on: bool) -> str:
    for val, s, e in scan(line):
        if val == flag:
            return line if on else _collapse(line[:s] + line[e:])
    return _insert_before_script(line, flag) if on else line


# --------------------------------------------------------------------------
# --script (bare name; optional + force prefix)
# --------------------------------------------------------------------------
def _script_name(name: str, force: bool) -> str:
    name = name[:-4] if name.endswith(".nse") else name
    return ("+" + name) if force else name


def get_script(line: str) -> str:
    toks = scan(line)
    for idx, (val, _s, _e) in enumerate(toks):
        base = val.split("=", 1)[0]
        if base == "--script":
            if "=" in val:
                return val.split("=", 1)[1]
            if idx + 1 < len(toks):
                return toks[idx + 1][0]
    return ""


def set_script(line: str, name: str, force: bool = False) -> str:
    val = _script_name(name, force)
    toks = scan(line)
    for idx, (v, s, e) in enumerate(toks):
        base = v.split("=", 1)[0]
        if base == "--script":
            if "=" in v:
                return line[:s] + f"--script={val}" + line[e:]
            if idx + 1 < len(toks):
                _nv, ns, ne = toks[idx + 1]
                return line[:ns] + val + line[ne:]
            return _collapse(line.rstrip() + " " + val)
    # insert before --script-args if present, else append
    for v, s, _e in toks:
        if v.split("=", 1)[0] == "--script-args":
            return _collapse(line[:s] + f"--script {val} " + line[s:])
    return _collapse(line.rstrip() + f" --script {val}")


# --------------------------------------------------------------------------
# --script-args (comma-separated name=value, book-style quoting, always last)
# --------------------------------------------------------------------------
_SPECIAL = set(" {},=")


def _split_args(value: str) -> list[tuple[str, str]]:
    """Split an nmap --script-args value into (name, value) pairs on top-level
    commas (commas inside {} or quotes don't split)."""
    pairs: list[tuple[str, str]] = []
    depth = 0
    q = ""
    cur: list[str] = []
    for ch in value:
        if q:
            cur.append(ch)
            if ch == q:
                q = ""
            continue
        if ch in "'\"":
            q = ch
            cur.append(ch)
        elif ch == "{":
            depth += 1
            cur.append(ch)
        elif ch == "}":
            depth = max(0, depth - 1)
            cur.append(ch)
        elif ch == "," and depth == 0:
            pairs.append("".join(cur))
            cur = []
        else:
            cur.append(ch)
    if cur:
        pairs.append("".join(cur))
    out: list[tuple[str, str]] = []
    for p in pairs:
        p = p.strip()
        if not p:
            continue
        if "=" in p:
            k, v = p.split("=", 1)
            out.append((k.strip(), v.strip().strip('"').strip("'")))
        else:
            out.append((p, ""))
    return out


def _quote_val(v: str) -> str:
    if v == "":
        return ""
    if any(c in _SPECIAL for c in v) and not (v.startswith("{") and v.endswith("}")):
        return '"' + v.replace('"', '\\"') + '"'
    return v


def join_args(pairs: list[tuple[str, str]]) -> str:
    return ",".join(f"{k}={_quote_val(v)}" for k, v in pairs)


def get_script_args(line: str):
    """Return (value_string, (start,end), form) or None."""
    toks = scan(line)
    for idx, (val, s, e) in enumerate(toks):
        base = val.split("=", 1)[0]
        if base == "--script-args":
            if "=" in val:
                return val.split("=", 1)[1], (s, e), "attached"
            if idx + 1 < len(toks):
                nv, ns, ne = toks[idx + 1]
                return nv, (ns, ne), "separate"
            return "", (e, e), "empty"
    return None


def set_script_arg(line: str, name: str, value: str = "") -> str:
    """Add or update one name=value inside --script-args (creating it if
    needed, always after --script). Empty value inserts a `name=` placeholder."""
    got = get_script_args(line)
    if got is None:
        joined = join_args([(name, value)])
        token = f"--script-args {joined}"
        # place right after the --script value if present, else append
        toks = scan(line)
        for idx, (v, s, e) in enumerate(toks):
            if v.split("=", 1)[0] == "--script":
                end = toks[idx + 1][2] if ("=" not in v and idx + 1 < len(toks)) else e
                return _collapse(line[:end] + " " + token + line[end:])
        return _collapse(line.rstrip() + " " + token)
    cur_val, (s, e), _form = got
    pairs = _split_args(cur_val)
    for i, (k, _v) in enumerate(pairs):
        if k == name:
            pairs[i] = (name, value)
            break
    else:
        pairs.append((name, value))
    return line[:s] + join_args(pairs) + line[e:]


def strip_empty_args(line: str) -> str:
    """Drop name= pairs with no value; remove --script-args if it empties."""
    got = get_script_args(line)
    if got is None:
        return line
    cur_val, (s, e), _form = got
    pairs = [(k, v) for k, v in _split_args(cur_val) if v != ""]
    toks = scan(line)
    # find the --script-args option token span (not just its value)
    for idx, (v, os_, oe) in enumerate(toks):
        if v.split("=", 1)[0] == "--script-args":
            if not pairs:
                end = toks[idx + 1][2] if ("=" not in v and idx + 1 < len(toks)) else oe
                return _collapse(line[:os_] + line[end:])
            return line[:s] + join_args(pairs) + line[e:]
    return line


# --------------------------------------------------------------------------
# compose (initial seed) and run
# --------------------------------------------------------------------------
def compose(target: str = "", program: str = "nmap") -> str:
    line = program
    if target and target.strip():
        line += " " + _sh_quote(target.strip())
    return line


def run_argv(line: str) -> list[str]:
    """Tokenise the (empty-arg-stripped) line for execution. No shell."""
    return shlex.split(strip_empty_args(line))
