"""Async email harvester (spider).

Crawls a site to a bounded depth, staying on-scope, and pulls email addresses
out of the HTML (both mailto: links and raw text). Bounded concurrency keeps
it fast without hammering the target.
"""

from __future__ import annotations

import asyncio
import re
from collections import deque
from typing import Callable, Optional
from urllib.parse import urljoin, urlparse

from ..models import Finding, Session, Severity

EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}")
HREF_RE = re.compile(r'href=[\'"]?([^\'" >]+)', re.IGNORECASE)


def extract_emails(html: str) -> set[str]:
    return set(EMAIL_RE.findall(html or ""))


def extract_links(html: str, base_url: str) -> list[str]:
    links = []
    for href in HREF_RE.findall(html or ""):
        if href.startswith(("mailto:", "javascript:", "#", "tel:")):
            continue
        links.append(urljoin(base_url, href))
    return links


async def scrape(
    base_url: str,
    max_depth: int = 2,
    concurrency: int = 20,
    max_pages: int = 200,
    timeout: float = 10.0,
    session: Optional[Session] = None,
    on_progress: Optional[Callable[[int, int], None]] = None,
) -> list[Finding]:
    if not base_url.startswith(("http://", "https://")):
        base_url = "https://" + base_url
    scope = urlparse(base_url).netloc

    emails: dict[str, str] = {}   # email -> url where first seen
    visited: set[str] = set()
    queue: deque[tuple[str, int]] = deque([(base_url, 0)])
    sem = asyncio.Semaphore(concurrency)
    pages_done = 0

    try:
        import aiohttp
    except ImportError:
        return [Finding("email", "error", "aiohttp not installed", "email-spider")]

    async with aiohttp.ClientSession(
        headers={"User-Agent": "EZRecon/2.0"}
    ) as http:

        async def fetch(url: str) -> str:
            async with sem:
                try:
                    async with http.get(
                        url, timeout=aiohttp.ClientTimeout(total=timeout), ssl=False
                    ) as resp:
                        ctype = resp.headers.get("content-type", "")
                        if "html" not in ctype and "text" not in ctype:
                            return ""
                        return await resp.text(errors="replace")
                except Exception:  # noqa: BLE001
                    return ""

        while queue and len(visited) < max_pages:
            # process a level in parallel
            batch = []
            while queue and len(batch) < concurrency and len(visited) < max_pages:
                url, depth = queue.popleft()
                if url in visited or depth > max_depth:
                    continue
                visited.add(url)
                batch.append((url, depth))

            if not batch:
                break

            htmls = await asyncio.gather(*[fetch(u) for u, _ in batch])
            for (url, depth), html in zip(batch, htmls):
                pages_done += 1
                if on_progress:
                    on_progress(pages_done, max_pages)
                for e in extract_emails(html):
                    emails.setdefault(e, url)
                if depth < max_depth:
                    for link in extract_links(html, url):
                        if urlparse(link).netloc == scope and link not in visited:
                            queue.append((link, depth + 1))

    findings = [
        Finding("email", e, f"found on {src}", "email-spider",
                Severity.LOW, meta={"url": src})
        for e, src in sorted(emails.items())
    ]
    if not findings:
        findings.append(Finding("email", "email-spider",
                                "no email addresses found", "email-spider"))
    if session is not None:
        session.add_many(findings)
        session.record_query(f"email-spider:{base_url} depth={max_depth}")
    return findings
