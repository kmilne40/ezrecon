"""EZRecon async recon engine.

Every module here exposes coroutine functions that return typed results from
``ezrecon.models``. They never touch curses/Textual - the front-ends drive
them. This keeps the engine unit-testable and reusable from the CLI, the TUI,
or another program.
"""
