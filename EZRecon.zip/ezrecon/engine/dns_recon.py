"""Async DNS reconnaissance.

Resolves every record type concurrently (the old tool did them one blocking
call at a time), parses SPF/DMARC out of TXT, does reverse lookups, and
attempts a zone transfer against each authoritative name server.
"""

from __future__ import annotations

import asyncio
import re
from typing import Optional

import dns.asyncresolver
import dns.exception
import dns.query
import dns.resolver
import dns.reversename
import dns.zone

from ..models import Finding, Session, Severity
from .base import async_resolver, is_valid_domain, is_valid_ip

RECORD_TYPES = ["A", "AAAA", "MX", "NS", "SOA", "TXT", "CNAME", "CAA"]

# Common DKIM selectors — presence reveals the email provider/tooling in use.
COMMON_DKIM_SELECTORS = [
    "default", "google", "selector1", "selector2", "k1", "k2", "dkim",
    "mail", "s1", "s2", "mandrill", "mailjet", "zoho", "everlytickey1",
    "protonmail", "fm1", "amazonses", "smtpapi",
]

# Common SRV records — presence maps out mail/UC/directory infrastructure.
COMMON_SRV = [
    ("_sip._tls", "SIP/TLS"),
    ("_sipfederationtls._tcp", "Teams/Skype federation"),
    ("_autodiscover._tcp", "Exchange autodiscover"),
    ("_ldap._tcp", "LDAP / Active Directory"),
    ("_kerberos._tcp", "Kerberos"),
    ("_xmpp-server._tcp", "XMPP"),
    ("_caldavs._tcp", "CalDAV"),
    ("_submission._tcp", "mail submission"),
]

# TXT verification-token prefixes -> the SaaS/vendor they imply.
VERIFICATION_TOKENS = {
    "google-site-verification": "Google Workspace / Search Console",
    "ms=": "Microsoft 365 / Azure",
    "facebook-domain-verification": "Meta / Facebook Business",
    "apple-domain-verification": "Apple Business",
    "atlassian-domain-verification": "Atlassian",
    "docusign=": "DocuSign",
    "adobe-idp-site-verification": "Adobe",
    "stripe-verification": "Stripe",
    "zoom-domain-verification": "Zoom",
    "cisco-ci-domain-verification": "Cisco",
    "citrix-verification-code": "Citrix",
    "logmein-verification-code": "LogMeIn/GoTo",
    "webexdomainverification": "Webex",
}


async def _resolve(resolver, domain: str, rtype: str) -> tuple[str, list[str]]:
    try:
        answers = await resolver.resolve(domain, rtype)
    except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN,
            dns.resolver.NoNameservers, dns.exception.DNSException):
        return rtype, []
    out: list[str] = []
    for r in answers:
        if rtype == "MX":
            out.append(f"{r.preference} {r.exchange.to_text().rstrip('.')}")
        elif rtype == "SOA":
            out.append(
                f"mname={r.mname.to_text().rstrip('.')} "
                f"rname={r.rname.to_text().rstrip('.')} serial={r.serial} "
                f"refresh={r.refresh} retry={r.retry} expire={r.expire} "
                f"minimum={r.minimum}"
            )
        elif rtype in ("NS", "CNAME"):
            out.append(r.target.to_text().rstrip("."))
        elif rtype == "CAA":
            out.append(f'{r.flags} {r.tag.decode() if isinstance(r.tag, bytes) else r.tag} '
                       f'"{r.value.decode() if isinstance(r.value, bytes) else r.value}"'.strip())
        elif rtype == "SRV":
            out.append(f"{r.priority} {r.weight} {r.port} "
                       f"{r.target.to_text().rstrip('.')}")
        else:
            out.append(r.to_text().strip('"'))
    return rtype, out


def _parse_spf(value: str) -> dict:
    """Pull the policy qualifier and the include:/ip mechanisms out of an SPF
    record. include: entries reveal third-party senders (SaaS/email vendors)."""
    low = value.lower()
    includes = re.findall(r"include:([^\s]+)", low)
    ips = re.findall(r"ip4:([^\s]+)", low) + re.findall(r"ip6:([^\s]+)", low)
    m = re.search(r"([~\-+?])all\b", low)
    policy = {"-": "hardfail (-all)", "~": "softfail (~all)",
              "+": "pass-all (+all, INSECURE)", "?": "neutral (?all)"}.get(
        m.group(1) if m else "", "no 'all' mechanism")
    return {"policy": policy, "includes": includes, "ips": ips}


async def _txt_records(resolver, name: str) -> tuple[bool, list[str]]:
    """Resolve TXT for a name. Returns (definitive, records).

    definitive=True means the DNS gave a real answer (records present, or a
    genuine NoAnswer/NXDOMAIN) — safe to infer absence from. definitive=False
    means the query failed (timeout/servfail); we must NOT infer 'missing' from
    it, to avoid false-positive 'no SPF/DMARC' findings.
    """
    try:
        answers = await resolver.resolve(name, "TXT")
        return True, [r.to_text().strip('"') for r in answers]
    except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN):
        return True, []
    except (dns.resolver.NoNameservers, dns.exception.DNSException):
        return False, []


def _classify_txt(value: str) -> tuple[str, Severity]:
    low = value.lower()
    if low.startswith("v=spf1"):
        sev = Severity.LOW if "~all" in low or "-all" in low else Severity.MEDIUM
        return "SPF", sev
    return "TXT", Severity.INFO


async def dns_lookup(domain: str, timeout: float = 5.0,
                     session: Optional[Session] = None) -> list[Finding]:
    """Resolve all common record types for a domain, concurrently, and pull out
    the pen-test-relevant detail (SPF senders, email-auth gaps, CAA, DKIM, SRV,
    SaaS verification tokens)."""
    domain = domain.strip().rstrip(".")
    findings: list[Finding] = []
    if not is_valid_domain(domain):
        f = Finding("dns", "error", f"invalid domain: {domain}", "dns",
                    Severity.INFO)
        return [f]

    resolver = async_resolver(timeout)
    results = await asyncio.gather(
        *[_resolve(resolver, domain, rt) for rt in RECORD_TYPES]
    )
    by_type = dict(results)
    has_spf = False

    for rtype, values in results:
        for v in values:
            if rtype == "TXT":
                key, sev = _classify_txt(v)
                findings.append(Finding("dns", key, v, "dns", sev,
                                        meta={"record": rtype}))
                if key == "SPF":
                    has_spf = True
                    spf = _parse_spf(v)
                    if spf["includes"]:
                        findings.append(Finding(
                            "dns", "SPF-senders",
                            "authorised senders: " + ", ".join(spf["includes"]),
                            "dns", Severity.INFO,
                            meta={"includes": spf["includes"], "ips": spf["ips"]}))
                    weak = "+all" in v.lower() or "all" not in v.lower()
                    findings.append(Finding(
                        "dns", "SPF-policy", spf["policy"], "dns",
                        Severity.MEDIUM if weak else Severity.LOW))
                # SaaS verification tokens hiding in TXT
                low = v.lower()
                for tok, vendor in VERIFICATION_TOKENS.items():
                    if tok in low:
                        findings.append(Finding(
                            "dns", "verification",
                            f"{vendor} (token: {tok.rstrip('=')})", "dns",
                            Severity.INFO, meta={"vendor": vendor}))
            else:
                findings.append(Finding("dns", rtype, v, "dns", Severity.INFO,
                                        meta={"record": rtype}))

    # CAA absence — without CAA, any CA may issue certs for the domain
    if not by_type.get("CAA"):
        findings.append(Finding(
            "dns", "CAA", "no CAA record (any CA may issue certificates)",
            "dns", Severity.LOW))

    # DMARC lives at _dmarc.<domain>
    dmarc_ok, dmarc = await _txt_records(resolver, f"_dmarc.{domain}")
    has_dmarc = False
    for v in dmarc:
        if "v=dmarc1" in v.lower():
            has_dmarc = True
            sev = Severity.MEDIUM if "p=none" in v.lower() else Severity.LOW
            findings.append(Finding("dns", "DMARC", v, "dns", sev))
            for addr in re.findall(r"(?:rua|ruf)=mailto:([^;,\s]+)", v, re.I):
                findings.append(Finding("dns", "DMARC-report", addr, "dns",
                                        Severity.INFO, meta={"email": addr}))

    # If we didn't see SPF in the main pass, confirm with a definitive query
    # before deciding it's genuinely absent (avoids transient false positives).
    spf_ok = True
    if not has_spf:
        spf_ok, txts = await _txt_records(resolver, domain)
        has_spf = any(t.lower().startswith("v=spf1") for t in txts)

    # email-auth gaps (spoofing exposure) — only flag on a definitive answer
    if by_type.get("MX"):
        if not has_spf and spf_ok:
            findings.append(Finding(
                "dns", "email-auth", "no SPF record — domain is spoofable",
                "dns", Severity.MEDIUM))
        if not has_dmarc and dmarc_ok:
            findings.append(Finding(
                "dns", "email-auth",
                "no DMARC record — no policy against spoofed mail",
                "dns", Severity.MEDIUM))

    # DKIM selector discovery (reveals the email provider) + common SRV
    dkim_names = [(f"{sel}._domainkey.{domain}", sel)
                  for sel in COMMON_DKIM_SELECTORS]
    srv_names = [(f"{name}.{domain}", label) for name, label in COMMON_SRV]
    dkim_res = await asyncio.gather(
        *[_resolve(resolver, n, "TXT") for n, _ in dkim_names])
    srv_res = await asyncio.gather(
        *[_resolve(resolver, n, "SRV") for n, _ in srv_names])
    for (name, sel), (_, vals) in zip(dkim_names, dkim_res):
        if any("v=dkim1" in x.lower() or "k=rsa" in x.lower() or "p=" in x
               for x in vals):
            findings.append(Finding("dns", "DKIM", f"selector '{sel}' present",
                                    "dns", Severity.INFO, meta={"selector": sel}))
    for (name, label), (_, vals) in zip(srv_names, srv_res):
        for v in vals:
            findings.append(Finding("dns", "SRV", f"{label}: {v}", "dns",
                                    Severity.INFO, meta={"service": label}))

    if session is not None:
        session.add_many(findings)
        session.record_query(f"dns:{domain}")
    return findings


async def reverse_dns(ip: str, timeout: float = 5.0,
                      session: Optional[Session] = None) -> list[Finding]:
    findings: list[Finding] = []
    if not is_valid_ip(ip):
        return [Finding("dns", "error", f"invalid ip: {ip}", "reverse-dns")]
    resolver = async_resolver(timeout)
    try:
        rev = dns.reversename.from_address(ip)
        answers = await resolver.resolve(rev, "PTR")
        for r in answers:
            findings.append(
                Finding("dns", "PTR", r.target.to_text().rstrip("."),
                        "reverse-dns", meta={"ip": ip})
            )
    except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN,
            dns.exception.DNSException):
        findings.append(Finding("dns", "PTR", f"no PTR for {ip}", "reverse-dns"))
    if session is not None:
        session.add_many(findings)
    return findings


async def zone_transfer(domain: str, timeout: float = 5.0,
                        session: Optional[Session] = None) -> list[Finding]:
    """Attempt AXFR against each NS. A success is a serious misconfig."""
    domain = domain.strip().rstrip(".")
    findings: list[Finding] = []
    if not is_valid_domain(domain):
        return [Finding("dns", "error", f"invalid domain: {domain}", "axfr")]

    resolver = async_resolver(timeout)
    _, ns_list = await _resolve(resolver, domain, "NS")
    if not ns_list:
        return [Finding("dns", "axfr", "no NS records to query", "axfr")]

    def _try(ns: str) -> tuple[str, str]:
        try:
            z = dns.zone.from_xfr(dns.query.xfr(ns, domain, timeout=timeout))
            return ns, z.to_text() if z else ""
        except Exception:  # noqa: BLE001
            return ns, ""

    loop = asyncio.get_event_loop()
    results = await asyncio.gather(
        *[loop.run_in_executor(None, _try, ns) for ns in ns_list]
    )
    any_ok = False
    for ns, data in results:
        if data:
            any_ok = True
            findings.append(
                Finding("dns", "AXFR", f"zone transfer succeeded via {ns}",
                        "axfr", Severity.HIGH,
                        meta={"ns": ns, "zone": data[:4000]})
            )
    if not any_ok:
        findings.append(
            Finding("dns", "axfr", "zone transfer refused by all name servers",
                    "axfr", Severity.INFO)
        )
    if session is not None:
        session.add_many(findings)
        session.record_query(f"axfr:{domain}")
    return findings
