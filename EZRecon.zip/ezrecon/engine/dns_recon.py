"""Async DNS reconnaissance.

Resolves every record type concurrently (the old tool did them one blocking
call at a time), parses SPF/DMARC out of TXT, does reverse lookups, and
attempts a zone transfer against each authoritative name server.
"""

from __future__ import annotations

import asyncio
from typing import Optional

import dns.asyncresolver
import dns.exception
import dns.query
import dns.resolver
import dns.reversename
import dns.zone

from ..models import Finding, Session, Severity
from .base import async_resolver, is_valid_domain, is_valid_ip

RECORD_TYPES = ["A", "AAAA", "MX", "NS", "SOA", "TXT", "CNAME"]


async def _resolve(resolver, domain: str, rtype: str) -> tuple[str, list[str]]:
    try:
        answers = await resolver.resolve(domain, rtype)
    except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN,
            dns.resolver.NoNameservers, dns.exception.DNSException):
        return rtype, []
    out: list[str] = []
    for r in answers:
        if rtype == "MX":
            out.append(f"{r.preference} {r.exchange.to_text().rstrip('.')}")
        elif rtype == "SOA":
            out.append(
                f"mname={r.mname.to_text().rstrip('.')} "
                f"rname={r.rname.to_text().rstrip('.')} serial={r.serial} "
                f"refresh={r.refresh} retry={r.retry} expire={r.expire} "
                f"minimum={r.minimum}"
            )
        elif rtype in ("NS", "CNAME"):
            out.append(r.target.to_text().rstrip("."))
        else:
            out.append(r.to_text().strip('"'))
    return rtype, out


def _classify_txt(value: str) -> tuple[str, Severity]:
    low = value.lower()
    if low.startswith("v=spf1"):
        sev = Severity.LOW if "~all" in low or "-all" in low else Severity.MEDIUM
        return "SPF", sev
    return "TXT", Severity.INFO


async def dns_lookup(domain: str, timeout: float = 5.0,
                     session: Optional[Session] = None) -> list[Finding]:
    """Resolve all common record types for a domain, concurrently."""
    domain = domain.strip().rstrip(".")
    findings: list[Finding] = []
    if not is_valid_domain(domain):
        f = Finding("dns", "error", f"invalid domain: {domain}", "dns",
                    Severity.INFO)
        return [f]

    resolver = async_resolver(timeout)
    results = await asyncio.gather(
        *[_resolve(resolver, domain, rt) for rt in RECORD_TYPES]
    )

    for rtype, values in results:
        for v in values:
            if rtype == "TXT":
                key, sev = _classify_txt(v)
            else:
                key, sev = rtype, Severity.INFO
            findings.append(Finding("dns", key, v, "dns", sev,
                                    meta={"record": rtype}))

    # DMARC lives at _dmarc.<domain>
    _, dmarc = await _resolve(resolver, f"_dmarc.{domain}", "TXT")
    for v in dmarc:
        if "v=dmarc1" in v.lower():
            sev = Severity.MEDIUM if "p=none" in v.lower() else Severity.LOW
            findings.append(Finding("dns", "DMARC", v, "dns", sev))

    if session is not None:
        session.add_many(findings)
        session.record_query(f"dns:{domain}")
    return findings


async def reverse_dns(ip: str, timeout: float = 5.0,
                      session: Optional[Session] = None) -> list[Finding]:
    findings: list[Finding] = []
    if not is_valid_ip(ip):
        return [Finding("dns", "error", f"invalid ip: {ip}", "reverse-dns")]
    resolver = async_resolver(timeout)
    try:
        rev = dns.reversename.from_address(ip)
        answers = await resolver.resolve(rev, "PTR")
        for r in answers:
            findings.append(
                Finding("dns", "PTR", r.target.to_text().rstrip("."),
                        "reverse-dns", meta={"ip": ip})
            )
    except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN,
            dns.exception.DNSException):
        findings.append(Finding("dns", "PTR", f"no PTR for {ip}", "reverse-dns"))
    if session is not None:
        session.add_many(findings)
    return findings


async def zone_transfer(domain: str, timeout: float = 5.0,
                        session: Optional[Session] = None) -> list[Finding]:
    """Attempt AXFR against each NS. A success is a serious misconfig."""
    domain = domain.strip().rstrip(".")
    findings: list[Finding] = []
    if not is_valid_domain(domain):
        return [Finding("dns", "error", f"invalid domain: {domain}", "axfr")]

    resolver = async_resolver(timeout)
    _, ns_list = await _resolve(resolver, domain, "NS")
    if not ns_list:
        return [Finding("dns", "axfr", "no NS records to query", "axfr")]

    def _try(ns: str) -> tuple[str, str]:
        try:
            z = dns.zone.from_xfr(dns.query.xfr(ns, domain, timeout=timeout))
            return ns, z.to_text() if z else ""
        except Exception:  # noqa: BLE001
            return ns, ""

    loop = asyncio.get_event_loop()
    results = await asyncio.gather(
        *[loop.run_in_executor(None, _try, ns) for ns in ns_list]
    )
    any_ok = False
    for ns, data in results:
        if data:
            any_ok = True
            findings.append(
                Finding("dns", "AXFR", f"zone transfer succeeded via {ns}",
                        "axfr", Severity.HIGH,
                        meta={"ns": ns, "zone": data[:4000]})
            )
    if not any_ok:
        findings.append(
            Finding("dns", "axfr", "zone transfer refused by all name servers",
                    "axfr", Severity.INFO)
        )
    if session is not None:
        session.add_many(findings)
        session.record_query(f"axfr:{domain}")
    return findings
