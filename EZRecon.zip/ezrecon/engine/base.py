"""Shared helpers for the engine: validators and network primitives."""

from __future__ import annotations

import ipaddress
import re
from typing import Optional

import dns.asyncresolver
import dns.resolver

_DOMAIN_RE = re.compile(r"^(?!-)([A-Za-z0-9-]{1,63}\.)+[A-Za-z]{2,63}$")

# Fast public resolvers used by default. dnspython tries them in order and
# moves on if one is unreachable; if they all fail we fall back to the system
# resolver so EZRecon still works on locked-down networks.
PUBLIC_RESOLVERS = ["1.1.1.1", "8.8.8.8", "9.9.9.9"]

# One process-wide DNS cache so overlapping lookups (brute + dns + crt.sh
# verification) don't re-query the same names.
_DNS_CACHE = dns.resolver.Cache()


def is_valid_domain(domain: str) -> bool:
    return bool(domain and _DOMAIN_RE.match(domain.strip()))


def is_valid_ip(ip: str) -> bool:
    try:
        ipaddress.ip_address(ip.strip())
        return True
    except ValueError:
        return False


def normalise_target(target: str) -> str:
    """Strip scheme/path so 'https://x.com/path' -> 'x.com'."""
    t = target.strip()
    t = re.sub(r"^[a-zA-Z]+://", "", t)
    t = t.split("/")[0].split("?")[0]
    if "@" in t:
        t = t.split("@")[-1]
    return t.strip().rstrip(".")


def async_resolver(
    timeout: float = 5.0,
    nameservers: Optional[list[str]] = None,
    use_cache: bool = True,
) -> dns.asyncresolver.Resolver:
    """Build a tuned async resolver.

    Defaults to the fast public resolvers with a shared cache. Pass
    ``nameservers=[]`` (empty list) to force the system resolver, or a custom
    list to override. Falls back to the system resolver if configuration fails.
    """
    if nameservers is None:
        nameservers = _configured_nameservers()
    try:
        if nameservers:
            r = dns.asyncresolver.Resolver(configure=False)
            r.nameservers = list(nameservers)
        else:
            r = dns.asyncresolver.Resolver()  # system config
    except Exception:  # noqa: BLE001
        r = dns.asyncresolver.Resolver()
    r.timeout = timeout
    r.lifetime = timeout
    if use_cache:
        r.cache = _DNS_CACHE
    return r


def _configured_nameservers() -> list[str]:
    """Resolver list from config; PUBLIC_RESOLVERS unless overridden."""
    try:
        from ..config import get_setting

        ns = get_setting("dns_nameservers", None)
        if ns is None:
            return list(PUBLIC_RESOLVERS)
        # empty list means "use the system resolver"
        return list(ns)
    except Exception:  # noqa: BLE001
        return list(PUBLIC_RESOLVERS)


def make_http_session(timeout: float = 15.0):
    """A shared aiohttp session with connection pooling + DNS caching.

    Reused across crt.sh, the email spider and any HTTP fingerprinting so we
    pay TLS/connection setup once and keep connections alive. Caller owns it.
    """
    import aiohttp

    connector = aiohttp.TCPConnector(
        limit=100, limit_per_host=10, ttl_dns_cache=300, ssl=False
    )
    return aiohttp.ClientSession(
        connector=connector,
        headers={"User-Agent": "EZRecon/2.0"},
        timeout=aiohttp.ClientTimeout(total=timeout),
    )


async def http_get(
    session, url: str, timeout: float = 10.0
) -> tuple[Optional[int], str]:
    """GET a URL with an aiohttp session. Returns (status, text). Never raises."""
    try:
        import aiohttp

        async with session.get(
            url, timeout=aiohttp.ClientTimeout(total=timeout), ssl=False
        ) as resp:
            text = await resp.text(errors="replace")
            return resp.status, text
    except Exception:  # noqa: BLE001 - recon is best-effort
        return None, ""
