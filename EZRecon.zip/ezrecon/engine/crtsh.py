"""Passive subdomain discovery via certificate transparency (crt.sh).

The chapter calls out CT logs as the way to find "forgotten or shadow
endpoints" that a brute force never will. This queries crt.sh's JSON API,
flattens the name_value fields, and returns unique in-scope hostnames.
"""

from __future__ import annotations

import json
from typing import Optional

from ..models import Finding, Session, Severity
from .base import is_valid_domain, make_http_session

CRTSH_URL = "https://crt.sh/?q=%25.{domain}&output=json"


def parse_crtsh(raw: str, domain: str) -> set[str]:
    """Parse crt.sh JSON text into a set of in-scope hostnames."""
    hosts: set[str] = set()
    if not raw:
        return hosts
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        # crt.sh sometimes returns newline-delimited JSON objects
        try:
            data = [json.loads(line) for line in raw.splitlines() if line.strip()]
        except json.JSONDecodeError:
            return hosts
    suffix = domain.lower().lstrip(".")
    for entry in data:
        for field in (entry.get("name_value", ""), entry.get("common_name", "")):
            for name in str(field).splitlines():
                name = name.strip().lstrip("*.").lower().rstrip(".")
                if name and (name == suffix or name.endswith("." + suffix)):
                    hosts.add(name)
    return hosts


async def crtsh_lookup(
    domain: str,
    timeout: float = 20.0,
    session: Optional[Session] = None,
    http_session=None,
    verify: bool = True,
) -> list[Finding]:
    domain = domain.strip().rstrip(".")
    if not is_valid_domain(domain):
        return [Finding("subdomain", "error", f"invalid domain: {domain}", "crt.sh")]

    url = CRTSH_URL.format(domain=domain)
    raw = ""
    owns_session = False
    try:
        import aiohttp

        if http_session is None:
            http_session = make_http_session(timeout)
            owns_session = True
        async with http_session.get(
            url, timeout=aiohttp.ClientTimeout(total=timeout),
            headers={"User-Agent": "EZRecon/2.0"},
        ) as resp:
            if resp.status == 200:
                raw = await resp.text(errors="replace")
    except Exception:  # noqa: BLE001
        raw = ""
    finally:
        if owns_session and http_session is not None:
            await http_session.close()

    hosts = parse_crtsh(raw, domain)

    live: dict[str, list[str]] = {}
    if hosts and verify:
        live = await _resolve_hosts(sorted(hosts), timeout=min(timeout, 3.0))

    findings: list[Finding] = []
    for h in sorted(hosts):
        ips = live.get(h, [])
        if ips:
            findings.append(
                Finding("subdomain", h, ", ".join(ips), "crt.sh",
                        Severity.LOW,
                        meta={"passive": True, "verified": True, "ips": ips})
            )
        else:
            note = "CT record (unresolved)" if verify else "from certificate transparency"
            findings.append(
                Finding("subdomain", h, note, "crt.sh", Severity.INFO,
                        meta={"passive": True, "verified": False})
            )
    if not findings:
        findings.append(
            Finding("subdomain", "crt.sh", "no CT records (or crt.sh unreachable)",
                    "crt.sh", Severity.INFO)
        )
    if session is not None:
        session.add_many(findings)
        session.record_query(f"crt.sh:%.{domain}")
    return findings


async def _resolve_hosts(hosts: list[str], timeout: float = 3.0,
                         concurrency: int = 100) -> dict[str, list[str]]:
    """Resolve A records for many hostnames concurrently. Returns host -> ips."""
    import asyncio

    import dns.exception
    import dns.resolver

    from .base import async_resolver

    resolver = async_resolver(timeout)
    sem = asyncio.Semaphore(concurrency)
    out: dict[str, list[str]] = {}

    async def one(host: str):
        async with sem:
            try:
                ans = await resolver.resolve(host, "A")
                out[host] = sorted({r.address for r in ans})
            except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN,
                    dns.resolver.NoNameservers, dns.exception.DNSException):
                pass

    await asyncio.gather(*[one(h) for h in hosts])
    return out
