"""Result fetching and page analysis for the dork Preview pane.

This is the only part of EZRecon that reaches out to *third-party* pages
(search engines and result destinations), so it is active, not passive, and
the front-ends gate it behind an explicit opt-in.

Two ways in to real result links:
  * DuckDuckGo's HTML endpoint  - no key, best-effort, tolerant of light use
  * Google Custom Search API    - structured, used when a key is configured

Then, for any result page, we fetch it, pull readable text, and surface where
the dork terms appear in context (extractive). An optional LLM summary (via the
Anthropic API, if a key is set) adds a natural-language "what is this / why does
it matter" on top.
"""

from __future__ import annotations

import html
import re
from dataclasses import dataclass, field
from typing import Optional
from urllib.parse import parse_qs, unquote, urlparse

from ..config import get_key, get_setting
from .base import make_http_session

DDG_HTML = "https://html.duckduckgo.com/html/"
DDG_LITE = "https://lite.duckduckgo.com/lite/"

# A realistic desktop browser UA. DuckDuckGo's HTML endpoint answers with an
# HTTP 202 "anomaly" (anti-bot) page when it doesn't trust the client, so we
# present as a normal browser rather than a self-identifying tool.
BROWSER_UA = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"
)
BROWSER_HEADERS = {
    "User-Agent": BROWSER_UA,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://duckduckgo.com/",
    "Origin": "https://duckduckgo.com",
    "Content-Type": "application/x-www-form-urlencoded",
}

# default OSINT-relevant terms to highlight in a page, on top of any pulled
# from the dork query itself
DEFAULT_TERMS = [
    "JCL", "LPAR", "RACF", "EBCDIC", "z/OS", "OS/390", "TSO", "ISPF", "CICS",
    "IMS", "Db2", "DRDA", "VTAM", "mainframe", "SYSIN", "password", "confidential",
]


@dataclass
class Result:
    title: str
    url: str
    snippet: str = ""
    source: str = "ddg"


@dataclass
class PageIntel:
    url: str
    final_url: str = ""
    status: int = 0
    content_type: str = ""
    title: str = ""
    description: str = ""
    size: int = 0
    text: str = ""
    contexts: list[dict] = field(default_factory=list)  # {term, snippet}
    error: str = ""


# --------------------------------------------------------------------------
# result fetching
# --------------------------------------------------------------------------
def _strip_tags(s: str) -> str:
    s = re.sub(r"<[^>]+>", "", s)
    return html.unescape(s).strip()


def parse_ddg_html(raw: str, limit: int = 10) -> list[Result]:
    """Parse DuckDuckGo HTML results into Result objects."""
    results: list[Result] = []
    if not raw:
        return results
    # each result anchor: class="result__a" href="...">Title</a>
    for m in re.finditer(
        r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>',
        raw, re.IGNORECASE | re.DOTALL,
    ):
        href, title = m.group(1), _strip_tags(m.group(2))
        url = _decode_ddg_href(href)
        if url:
            results.append(Result(title=title or url, url=url, source="ddg"))
        if len(results) >= limit:
            break
    # snippets, matched positionally where possible
    snippets = [
        _strip_tags(s.group(1))
        for s in re.finditer(
            r'class="result__snippet"[^>]*>(.*?)</a>', raw,
            re.IGNORECASE | re.DOTALL,
        )
    ]
    for i, snip in enumerate(snippets[: len(results)]):
        results[i].snippet = snip
    return results


def parse_ddg_lite_html(raw: str, limit: int = 10) -> list[Result]:
    """Parse the lite DuckDuckGo endpoint (table layout) into Results."""
    results: list[Result] = []
    if not raw:
        return results
    links = list(re.finditer(
        r'<a[^>]+class="result-link"[^>]+href="([^"]+)"[^>]*>(.*?)</a>',
        raw, re.IGNORECASE | re.DOTALL,
    ))
    snippets = [
        _strip_tags(s.group(1))
        for s in re.finditer(
            r'class="result-snippet"[^>]*>(.*?)</td>', raw,
            re.IGNORECASE | re.DOTALL,
        )
    ]
    for i, m in enumerate(links):
        href, title = m.group(1), _strip_tags(m.group(2))
        url = _decode_ddg_href(href)
        if not url:
            continue
        snip = snippets[i] if i < len(snippets) else ""
        results.append(Result(title=title or url, url=url, snippet=snip,
                              source="ddg-lite"))
        if len(results) >= limit:
            break
    return results


def _decode_ddg_href(href: str) -> str:
    """DDG often wraps the real URL in //duckduckgo.com/l/?uddg=<encoded>."""
    if href.startswith("//"):
        href = "https:" + href
    parsed = urlparse(href)
    if "duckduckgo.com" in parsed.netloc and parsed.path.startswith("/l/"):
        qs = parse_qs(parsed.query)
        if "uddg" in qs:
            return unquote(qs["uddg"][0])
    return href


async def _ddg_fetch(url: str, query: str, timeout: float,
                     http_session=None) -> tuple[int, str]:
    """POST a query to a DuckDuckGo endpoint. Returns (status, body).

    Separated out so the retry/parse orchestration in ddg_search can be tested
    without real network access.
    """
    import aiohttp

    owns = False
    try:
        if http_session is None:
            http_session = make_http_session(timeout)
            owns = True
        async with http_session.post(
            url,
            data={"q": query, "kl": "us-en"},
            timeout=aiohttp.ClientTimeout(total=timeout),
            headers=BROWSER_HEADERS,
            allow_redirects=True,
        ) as resp:
            return resp.status, await resp.text(errors="replace")
    finally:
        if owns and http_session is not None:
            await http_session.close()


async def ddg_search(query: str, limit: int = 10, timeout: float = 15.0,
                     http_session=None, retries: int = 2) -> tuple[list[Result], str]:
    """Best-effort DuckDuckGo search (no key). Returns (results, error).

    DuckDuckGo actively fights scraping: its HTML endpoint returns HTTP 202
    (an anti-bot "anomaly" page) when it distrusts a request. We present as a
    normal browser, retry with backoff, and fall back to the lite endpoint.
    Even so, keyless scraping can be blocked from some networks - in that case
    the reliable path is the Custom Search API (engine="api").
    """
    import asyncio

    last_status = 0
    attempts = [(DDG_HTML, parse_ddg_html), (DDG_LITE, parse_ddg_lite_html)]
    for url, parser in attempts:
        for attempt in range(retries + 1):
            try:
                status, raw = await _ddg_fetch(url, query, timeout, http_session)
            except Exception as e:  # noqa: BLE001
                return [], f"DuckDuckGo fetch failed: {e}"
            last_status = status
            if status == 200 and raw:
                parsed = parser(raw, limit)
                if parsed:
                    return parsed, ""
                # 200 but nothing parsed - try the next endpoint
                break
            if status in (202, 403, 429) or status >= 500:
                # anti-bot / throttle - brief backoff, then retry
                await asyncio.sleep(0.8 * (attempt + 1))
                continue
            break  # some other status - move to the next endpoint

    if last_status == 202:
        return [], ("DuckDuckGo blocked the request (HTTP 202 anti-bot). This "
                    "often clears if you wait and retry, or run fewer dorks at "
                    "once; from some networks it stays blocked — use a Google "
                    "API key (Via API) for reliable results.")
    if last_status == 429:
        return [], "DuckDuckGo rate-limited the request (HTTP 429) — wait and retry."
    if last_status:
        return [], f"DuckDuckGo returned HTTP {last_status} (no results parsed)."
    return [], "DuckDuckGo returned no results."


async def api_search(query: str, limit: int = 10) -> tuple[list[Result], str]:
    """Google CSE search, reusing the dork module's API call."""
    from . import google_dork

    api_key = get_key("google_api_key")
    cse_id = get_key("google_cse_id")
    if not (api_key and cse_id):
        return [], "no Google API key configured"
    import asyncio

    loop = asyncio.get_event_loop()
    try:
        items = await loop.run_in_executor(
            None, google_dork._do_cse, query, api_key, cse_id, limit
        )
    except Exception as e:  # noqa: BLE001
        return [], str(e)
    return [Result(title=i["title"], url=i["link"], snippet=i["snippet"],
                   source="google-api") for i in items], ""


async def get_results(query: str, engine: str = "auto", limit: int = 10,
                      http_session=None) -> tuple[list[Result], str]:
    """Resolve a dork query to real result links.

    engine: 'auto' uses the Google API when a key is configured, else DDG;
    'api' forces Google; 'ddg' forces DuckDuckGo.
    """
    from ..config import has_google

    if engine == "api" or (engine == "auto" and has_google()):
        results, err = await api_search(query, limit)
        if results or engine == "api":
            return results, err
        # fall through to DDG on API failure in auto mode
    return await ddg_search(query, limit, http_session=http_session)


# --------------------------------------------------------------------------
# page analysis
# --------------------------------------------------------------------------
def _readable_text(raw: str) -> str:
    raw = re.sub(r"(?is)<(script|style|noscript).*?</\1>", " ", raw)
    text = re.sub(r"(?s)<[^>]+>", " ", raw)
    text = html.unescape(text)
    return re.sub(r"\s+", " ", text).strip()


def _title(raw: str) -> str:
    m = re.search(r"(?is)<title[^>]*>(.*?)</title>", raw)
    return _strip_tags(m.group(1)) if m else ""


def _description(raw: str) -> str:
    m = re.search(
        r'(?is)<meta[^>]+name=["\']description["\'][^>]+content=["\'](.*?)["\']',
        raw,
    )
    return _strip_tags(m.group(1)) if m else ""


def extract_context(text: str, terms: list[str], window: int = 90,
                    per_term: int = 3, total: int = 25) -> list[dict]:
    """Find where each term appears, with a window of surrounding context."""
    hits: list[dict] = []
    low = text.lower()
    for term in terms:
        if not term:
            continue
        t = term.lower()
        start = 0
        found = 0
        while found < per_term and len(hits) < total:
            idx = low.find(t, start)
            if idx == -1:
                break
            a = max(0, idx - window)
            b = min(len(text), idx + len(term) + window)
            prefix = "…" if a > 0 else ""
            suffix = "…" if b < len(text) else ""
            snippet = (prefix + text[a:idx] + "❱" + text[idx:idx + len(term)]
                       + "❰" + text[idx + len(term):b] + suffix)
            hits.append({"term": term, "snippet": re.sub(r"\s+", " ", snippet)})
            start = idx + len(term)
            found += 1
    return hits


def terms_from_query(query: str) -> list[str]:
    """Pull highlight terms out of a dork string plus the default set."""
    q = query
    # keep quoted phrases and filetype/keyword operands
    quoted = re.findall(r'"([^"]+)"', q)
    ops = re.findall(r"(?:filetype|inurl|intitle|intext):([^\s\"]+)", q, re.I)
    bare = [w for w in re.findall(r"[A-Za-z0-9/_.-]{3,}", q)
            if not w.lower().startswith(("site:", "http"))]
    terms = list(dict.fromkeys(quoted + ops + DEFAULT_TERMS + bare))
    # drop the domain-y and operator tokens
    return [t for t in terms if t.lower() not in ("site", "filetype", "inurl",
            "intitle", "intext", "and", "or")][:24]


async def fetch_page(url: str, terms: Optional[list[str]] = None,
                     timeout: float = 15.0, http_session=None,
                     max_bytes: int = 800_000) -> PageIntel:
    """Fetch a page and build extractive intel from it."""
    import aiohttp

    intel = PageIntel(url=url)
    owns = False
    try:
        if http_session is None:
            http_session = make_http_session(timeout)
            owns = True
        async with http_session.get(
            url, timeout=aiohttp.ClientTimeout(total=timeout),
            headers={"User-Agent": "Mozilla/5.0 (EZRecon)"}, ssl=False,
        ) as resp:
            intel.status = resp.status
            intel.final_url = str(resp.url)
            intel.content_type = resp.headers.get("content-type", "")
            raw = (await resp.content.read(max_bytes)).decode(
                "utf-8", errors="replace")
            intel.size = len(raw)
            if "html" in intel.content_type or "text" in intel.content_type \
                    or not intel.content_type:
                intel.title = _title(raw)
                intel.description = _description(raw)
                intel.text = _readable_text(raw)
            else:
                intel.text = ""
    except Exception as e:  # noqa: BLE001
        intel.error = f"fetch failed: {e}"
    finally:
        if owns and http_session is not None:
            await http_session.close()

    if intel.text:
        intel.contexts = extract_context(intel.text, terms or DEFAULT_TERMS)
    return intel


# --------------------------------------------------------------------------
# optional LLM summary (Anthropic)
# --------------------------------------------------------------------------
def has_llm() -> bool:
    return bool(get_key("anthropic_api_key"))


def summarise_llm(intel: PageIntel, query: str, timeout: float = 40.0) -> str:
    """Natural-language summary via the Anthropic API. Requires a key."""
    key = get_key("anthropic_api_key")
    if not key:
        return ""
    if not intel.text:
        return "(no readable text to summarise)"
    import requests

    model = get_setting("anthropic_model", "claude-haiku-4-5-20251001")
    body = (
        f"You are assisting an authorised OSINT assessment. A search for "
        f"`{query}` returned this page. In 3-4 sentences, say what the page is "
        f"and why it may be relevant to a mainframe security review, then list "
        f"the specific places where notable terms (JCL, LPAR, RACF, EBCDIC, "
        f"credentials, internal hostnames, emails) appear. Be factual; if "
        f"nothing notable is present, say so.\n\n"
        f"TITLE: {intel.title}\nURL: {intel.final_url or intel.url}\n\n"
        f"PAGE TEXT (truncated):\n{intel.text[:6000]}"
    )
    try:
        resp = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": model,
                "max_tokens": 400,
                "messages": [{"role": "user", "content": body}],
            },
            timeout=timeout,
        )
        if resp.status_code != 200:
            detail = ""
            try:
                detail = resp.json().get("error", {}).get("message", "")
            except Exception:  # noqa: BLE001
                detail = resp.text[:200]
            return f"(LLM summary failed: HTTP {resp.status_code} {detail})"
        data = resp.json()
        parts = [b.get("text", "") for b in data.get("content", [])
                 if b.get("type") == "text"]
        return "\n".join(p for p in parts if p).strip() or "(empty summary)"
    except Exception as e:  # noqa: BLE001
        return f"(LLM summary failed: {e})"
