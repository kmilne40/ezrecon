"""Shodan lookups with a baked-in mainframe query library.

Wraps the shodan library's blocking calls in a thread. Ships the z/OS banner
queries from the chapter (TSO IKJ56700A, IBM FTP, CICS, Db2/DRDA, NJE) so the
user can fire a mainframe sweep without remembering the syntax.
"""

from __future__ import annotations

import asyncio
import json
from functools import lru_cache
from pathlib import Path
from typing import Optional

from ..config import get_key
from ..models import Finding, Session, Severity

_QUERIES = Path(__file__).parent.parent / "data" / "shodan_queries.json"


@lru_cache(maxsize=1)
def mainframe_queries() -> list[dict]:
    return json.loads(_QUERIES.read_text())["queries"]


def _client():
    key = get_key("shodan_api_key")
    if not key:
        return None
    try:
        import shodan

        return shodan.Shodan(key)
    except Exception:  # noqa: BLE001
        return None


def _do_search(query: str, limit: int) -> list[dict]:
    api = _client()
    if api is None:
        raise RuntimeError("no-key")
    results = api.search(query, limit=limit)
    out = []
    for m in results.get("matches", [])[:limit]:
        out.append({
            "ip": m.get("ip_str", ""),
            "port": m.get("port", ""),
            "org": m.get("org", "") or "",
            "hostnames": ", ".join(m.get("hostnames", []) or []),
            "data": (m.get("data", "") or "").strip()[:200],
        })
    return out


def _do_host(ip: str) -> dict:
    api = _client()
    if api is None:
        raise RuntimeError("no-key")
    return api.host(ip)


async def search(
    query: str, limit: int = 20, session: Optional[Session] = None
) -> list[Finding]:
    if not get_key("shodan_api_key"):
        return [Finding("shodan", "error",
                        "no Shodan API key configured", "shodan", Severity.INFO)]
    loop = asyncio.get_event_loop()
    try:
        matches = await loop.run_in_executor(None, _do_search, query, limit)
    except Exception as e:  # noqa: BLE001
        return [Finding("shodan", "error", f"shodan query failed: {e}", "shodan")]

    findings: list[Finding] = []
    for m in matches:
        val = f"{m['ip']}:{m['port']}"
        if m["hostnames"]:
            val += f" ({m['hostnames']})"
        if m["data"]:
            val += f" | {m['data']}"
        findings.append(Finding("shodan", m["ip"], val, f"shodan:{query}",
                                Severity.MEDIUM, meta=m))
    if not findings:
        findings.append(Finding("shodan", "shodan", f"no results for: {query}",
                                "shodan"))
    if session is not None:
        session.add_many(findings)
        session.record_query(f"shodan:{query}")
    return findings


async def host_info(ip: str, session: Optional[Session] = None) -> list[Finding]:
    if not get_key("shodan_api_key"):
        return [Finding("shodan", "error", "no Shodan API key configured", "shodan")]
    loop = asyncio.get_event_loop()
    try:
        info = await loop.run_in_executor(None, _do_host, ip)
    except Exception as e:  # noqa: BLE001
        return [Finding("shodan", "error", f"shodan host lookup failed: {e}", "shodan")]

    findings: list[Finding] = []
    ports = info.get("ports", [])
    findings.append(Finding("shodan", ip,
                            f"org={info.get('org','?')} os={info.get('os','?')} "
                            f"ports={ports}", "shodan", Severity.MEDIUM))
    for item in info.get("data", []):
        p = item.get("port", "")
        banner = (item.get("data", "") or "").strip()[:160]
        findings.append(Finding("shodan", f"{ip}:{p}", banner, "shodan"))
    if session is not None:
        session.add_many(findings)
        session.record_query(f"shodan-host:{ip}")
    return findings


async def mainframe_sweep(
    domain_or_ip: str = "", limit: int = 10, session: Optional[Session] = None
) -> list[Finding]:
    """Run the whole mainframe query library, optionally scoped to a target."""
    if not get_key("shodan_api_key"):
        return [Finding("shodan", "error", "no Shodan API key configured", "shodan")]
    findings: list[Finding] = []
    for q in mainframe_queries():
        query = q["query"]
        if domain_or_ip:
            query = f"{query} hostname:{domain_or_ip}"
        sub = await search(query, limit=limit)
        for f in sub:
            if f.key not in ("error", "shodan"):
                f.meta["query_label"] = q["label"]
                findings.append(f)
    if session is not None:
        session.add_many(findings)
    return findings
