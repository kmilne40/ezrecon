"""Dangling DNS / subdomain-takeover detection.

A record that still resolves but points at a deprovisioned resource is
takeover-ready if the target namespace is still claimable. Detection uses three
signals (per OWASP WSTG / can-i-take-over-xyz):

  1. CNAME chain lands on a known provider base domain, and (with --http) the
     page returns that provider's "unclaimed" fingerprint  -> HIGH (confirmed).
  2. CNAME points at a known provider whose signal is NXDOMAIN-on-target, and
     the final target is NXDOMAIN  -> HIGH (confirmed).
  3. CNAME/A whose final target is NXDOMAIN (dangling pointer)  -> MEDIUM.

A CNAME that merely resolves is NOT flagged - if an attacker already claimed the
resource it resolves fine (to theirs), so we rely on fingerprints / NXDOMAIN, not
resolution success.

The fingerprint set ships as a snapshot and is refreshable from the upstream
can-i-take-over-xyz project (`update_fingerprints`).
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Callable, Optional

import dns.asyncresolver
import dns.exception
import dns.resolver

from ..models import Finding, Session, Severity
from .base import async_resolver, is_valid_domain, make_http_session

_FP_FILE = Path(__file__).parent.parent / "data" / "takeover_fingerprints.json"
_UPSTREAM = ("https://raw.githubusercontent.com/EdOverflow/"
             "can-i-take-over-xyz/master/fingerprints.json")


def load_fingerprints() -> list[dict]:
    """Load the fingerprint set, normalising to a common shape.

    Accepts both our snapshot ({"fingerprints": [...]}) and the upstream
    can-i-take-over-xyz format (a bare list, or {"fingerprints": [...]}), and
    normalises `cname`/`fingerprint` to lists.
    """
    try:
        raw = json.loads(_FP_FILE.read_text())
    except Exception:  # noqa: BLE001
        return []
    entries = raw.get("fingerprints", raw) if isinstance(raw, dict) else raw
    out: list[dict] = []
    for e in entries:
        if not isinstance(e, dict):
            continue
        cname = e.get("cname") or []
        if isinstance(cname, str):
            cname = [cname]
        fp = e.get("fingerprint") or []
        if isinstance(fp, str):
            fp = [fp] if fp else []
        out.append({
            "service": e.get("service", "unknown"),
            "cname": [c.lower() for c in cname if c],
            "fingerprint": [f for f in fp if f],
            "nxdomain": bool(e.get("nxdomain", False)),
            "status": e.get("status", ""),
        })
    return out


async def update_fingerprints(session_http=None) -> tuple[bool, str]:
    """Refresh the fingerprint snapshot from the upstream project."""
    import aiohttp
    owns = False
    try:
        if session_http is None:
            session_http = make_http_session(20.0)
            owns = True
        async with session_http.get(_UPSTREAM,
                                    timeout=aiohttp.ClientTimeout(total=20)) as r:
            if r.status != 200:
                return False, f"upstream returned HTTP {r.status}"
            text = await r.text()
        data = json.loads(text)
        # keep it in our snapshot wrapper for consistency
        _FP_FILE.write_text(json.dumps({"fingerprints": data}
                                       if isinstance(data, list) else data,
                                       indent=2))
        n = len(load_fingerprints())
        return True, f"updated: {n} provider fingerprints"
    except Exception as e:  # noqa: BLE001
        return False, f"update failed: {e}"
    finally:
        if owns and session_http is not None:
            await session_http.close()


async def _resolve_chain(resolver, host: str) -> tuple[list[str], bool]:
    """Follow the CNAME chain; return (targets, final_target_is_nxdomain)."""
    chain: list[str] = []
    current = host
    for _ in range(10):  # guard against loops
        try:
            answers = await resolver.resolve(current, "CNAME")
        except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN,
                dns.resolver.NoNameservers, dns.exception.DNSException):
            break
        target = str(answers[0].target).rstrip(".").lower()
        if not target or target in chain:
            break
        chain.append(target)
        current = target
    # does the final target still resolve to an address?
    final = chain[-1] if chain else host
    final_nx = False
    try:
        await resolver.resolve(final, "A")
    except dns.resolver.NXDOMAIN:
        final_nx = True
    except (dns.resolver.NoAnswer, dns.resolver.NoNameservers,
            dns.exception.DNSException):
        final_nx = False
    return chain, final_nx


def _match_provider(chain: list[str], fps: list[dict]) -> Optional[dict]:
    for fp in fps:
        for base in fp["cname"]:
            if any(base in t for t in chain):
                return fp
    return None


async def _fetch_body(host: str, timeout: float = 10.0) -> str:
    """Fetch the host over HTTPS then HTTP; return the body (best effort)."""
    import aiohttp
    session = make_http_session(timeout)
    body = ""
    try:
        for scheme in ("https", "http"):
            try:
                async with session.get(f"{scheme}://{host}", ssl=False,
                                       timeout=aiohttp.ClientTimeout(total=timeout),
                                       allow_redirects=True) as r:
                    body = await r.text(errors="replace")
                    if body:
                        break
            except Exception:  # noqa: BLE001
                continue
    finally:
        await session.close()
    return body


def classify(host: str, chain: list[str], final_nx: bool, fps: list[dict],
             body: str = "") -> Optional[Finding]:
    """Turn resolution evidence into a takeover Finding (or None)."""
    provider = _match_provider(chain, fps)
    cname_txt = " -> ".join(chain) if chain else "(no CNAME)"

    if provider:
        # confirmed by HTTP fingerprint?
        if body and provider["fingerprint"]:
            low = body.lower()
            if any(f.lower() in low for f in provider["fingerprint"]):
                return Finding(
                    "takeover", host,
                    f"CONFIRMED takeover candidate: {provider['service']} "
                    f"({cname_txt}) — provider fingerprint matched",
                    "takeover", Severity.HIGH,
                    meta={"service": provider["service"], "cname": chain,
                          "confirmed": True, "signal": "http-fingerprint"})
        # confirmed by NXDOMAIN-on-target providers (e.g. Azure)
        if provider["nxdomain"] and final_nx:
            return Finding(
                "takeover", host,
                f"CONFIRMED takeover candidate: {provider['service']} "
                f"({cname_txt}) — target is NXDOMAIN",
                "takeover", Severity.HIGH,
                meta={"service": provider["service"], "cname": chain,
                      "confirmed": True, "signal": "nxdomain"})
        # provider matched but not confirmed
        return Finding(
            "takeover", host,
            f"candidate: CNAME to {provider['service']} ({cname_txt}) — "
            f"unconfirmed; run with --http to verify",
            "takeover", Severity.MEDIUM,
            meta={"service": provider["service"], "cname": chain,
                  "confirmed": False, "signal": "cname-provider"})

    # dangling pointer: resolves via CNAME but final target is dead
    if chain and final_nx:
        return Finding(
            "takeover", host,
            f"dangling CNAME: {cname_txt} — final target is NXDOMAIN",
            "takeover", Severity.MEDIUM,
            meta={"cname": chain, "confirmed": False, "signal": "nxdomain"})
    return None


async def check_host(host: str, do_http: bool = False, timeout: float = 5.0,
                     session: Optional[Session] = None,
                     fps: Optional[list[dict]] = None) -> Optional[Finding]:
    host = host.strip().rstrip(".").lower()
    if not is_valid_domain(host):
        return None
    fps = fps if fps is not None else load_fingerprints()
    resolver = async_resolver(timeout)
    chain, final_nx = await _resolve_chain(resolver, host)
    # quick provider pre-check decides whether an HTTP fetch is worthwhile
    provider = _match_provider(chain, fps)
    body = ""
    if do_http and provider and provider["fingerprint"]:
        body = await _fetch_body(host, timeout=max(timeout, 8.0))
    finding = classify(host, chain, final_nx, fps, body=body)
    if finding and session is not None:
        session.add(finding)
    return finding


def discovered_hosts(session: Session) -> list[str]:
    """Subdomains found so far (plus the apex) that are worth checking."""
    hosts: list[str] = []
    if session.target:
        hosts.append(session.target.strip().lower())
    for f in session.by_category("subdomain"):
        if f.key in ("wildcard", "crt.sh", "error"):
            continue
        h = f.key.strip().lower()
        if h and h not in hosts:
            hosts.append(h)
    return hosts


async def check_all(session: Session, do_http: bool = False, cap: int = 100,
                    concurrency: int = 20, timeout: float = 5.0,
                    on_stage: Optional[Callable[[str], None]] = None) -> list[Finding]:
    """Check every discovered host for dangling-DNS / takeover conditions."""
    fps = load_fingerprints()
    hosts = discovered_hosts(session)[:cap]
    sem = asyncio.Semaphore(concurrency)
    findings: list[Finding] = []

    async def _one(h: str):
        async with sem:
            if on_stage:
                on_stage(f"takeover check {h}")
            f = await check_host(h, do_http=do_http, timeout=timeout, fps=fps)
            if f:
                findings.append(f)

    await asyncio.gather(*[_one(h) for h in hosts])
    if session is not None and findings:
        session.add_many(findings)
    if session is not None:
        session.record_query(f"takeover:{session.target}")
    return findings
