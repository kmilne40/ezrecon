"""Document metadata harvesting (FOCA/metagoofil-style).

Public documents leak internal intel in their metadata: author and
last-modified-by usernames (naming conventions, real names), the authoring
software and its version (patch level / attack surface), company/manager fields,
and sometimes internal file paths and templates. EZRecon already surfaces
document URLs via Google/GitHub dorks and the Wayback harvester; this fetches
those and extracts the metadata.

Dependency-light: Office files (docx/xlsx/pptx) are ZIP+XML, read with stdlib
zipfile + xml.etree. PDFs are parsed best-effort from the Info dictionary (and
XMP) on the raw bytes, with pypdf used only if it's already installed.
"""

from __future__ import annotations

import io
import re
import zipfile
from typing import Callable, Optional
from xml.etree import ElementTree as ET

from ..models import Finding, Session, Severity
from .base import make_http_session

_OFFICE_EXT = (".docx", ".xlsx", ".pptx", ".docm", ".xlsm", ".pptm")
_PDF_EXT = (".pdf",)
_DOC_EXT = _OFFICE_EXT + _PDF_EXT

# fields whose values are (likely) usernames / people
_PERSON_FIELDS = ("creator", "lastModifiedBy", "author", "manager")
# fields that reveal software / versions
_SOFTWARE_FIELDS = ("Application", "AppVersion", "Producer", "Creator", "PDFProducer")


def _localname(tag: str) -> str:
    return tag.rsplit("}", 1)[-1] if "}" in tag else tag


def is_document(url: str) -> bool:
    low = url.lower().split("?")[0]
    return low.endswith(_DOC_EXT)


def extract_office(data: bytes) -> dict:
    """Pull core.xml + app.xml metadata from an OOXML (docx/xlsx/pptx)."""
    meta: dict = {}
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except Exception:  # noqa: BLE001
        return meta
    for part in ("docProps/core.xml", "docProps/app.xml"):
        try:
            xml = zf.read(part)
        except KeyError:
            continue
        try:
            root = ET.fromstring(xml)
        except Exception:  # noqa: BLE001
            continue
        for el in root.iter():
            name = _localname(el.tag)
            val = (el.text or "").strip()
            if val and name not in ("coreProperties", "Properties"):
                meta[name] = val
    return meta


_PDF_FIELDS = ("Title", "Author", "Creator", "Producer", "CreationDate",
               "ModDate", "Company", "Subject", "Keywords")


def extract_pdf(data: bytes) -> dict:
    """Best-effort PDF metadata from the Info dictionary (and XMP)."""
    meta: dict = {}
    # optional fast/robust path
    try:
        import pypdf
        r = pypdf.PdfReader(io.BytesIO(data))
        di = r.metadata or {}
        for k, v in di.items():
            key = str(k).lstrip("/")
            if v:
                meta[key] = str(v)
        if meta:
            return meta
    except Exception:  # noqa: BLE001
        pass

    text = data.decode("latin-1", "replace")
    for field in _PDF_FIELDS:
        # /Field (literal string)
        m = re.search(rf"/{field}\s*\(((?:[^()\\]|\\.)*)\)", text)
        if m:
            meta[field] = _pdf_unescape(m.group(1))
            continue
        # /Field <hex string>
        m = re.search(rf"/{field}\s*<([0-9A-Fa-f]+)>", text)
        if m:
            try:
                meta[field] = bytes.fromhex(m.group(1)).decode(
                    "utf-16-be", "replace").strip("\x00")
            except Exception:  # noqa: BLE001
                pass
    # XMP dc:creator / xmp:CreatorTool as a fallback
    for tag, key in (("dc:creator", "Author"), ("xmp:CreatorTool", "Creator"),
                     ("pdf:Producer", "Producer")):
        if key not in meta:
            m = re.search(rf"<{tag}>(?:\s*<[^>]+>)*\s*([^<]+)", text)
            if m and m.group(1).strip():
                meta[key] = m.group(1).strip()
    return meta


def _pdf_unescape(s: str) -> str:
    return (s.replace("\\(", "(").replace("\\)", ")")
             .replace("\\\\", "\\").strip())


# format-aware field roles: Office 'creator' is a person; PDF '/Creator' is
# the authoring application, not a person.
_PERSON_BY_KIND = {
    "office": {"creator", "lastmodifiedby", "manager"},
    "pdf": {"author"},
}
_SOFTWARE_BY_KIND = {
    "office": {"application", "appversion"},
    "pdf": {"creator", "producer"},
}


def derive(meta: dict, kind: str = "office") -> dict:
    """Reduce raw metadata to intel: people, software, company."""
    people, software, company = set(), set(), set()
    pfields = _PERSON_BY_KIND.get(kind, _PERSON_BY_KIND["office"])
    sfields = _SOFTWARE_BY_KIND.get(kind, _SOFTWARE_BY_KIND["office"])
    for k, v in meta.items():
        if not v:
            continue
        kl = k.lower()
        if kl in pfields and not v.lower().startswith("microsoft"):
            people.add(v)
        if kl in sfields:
            software.add(v)
        if kl in ("company", "manager"):
            company.add(v)
    return {"people": sorted(people), "software": sorted(software),
            "company": sorted(company)}


def _kind_of(data: bytes, url: str) -> str:
    low = url.lower().split("?")[0]
    if low.endswith(_PDF_EXT) or data[:5] == b"%PDF-":
        return "pdf"
    return "office"


async def fetch_doc(url: str, timeout: float = 20.0, max_bytes: int = 8_000_000,
                    http_session=None) -> tuple[bytes, str]:
    import aiohttp
    owns = False
    try:
        if http_session is None:
            http_session = make_http_session(timeout)
            owns = True
        async with http_session.get(
            url, timeout=aiohttp.ClientTimeout(total=timeout),
            allow_redirects=True,
        ) as r:
            if r.status != 200:
                return b"", f"HTTP {r.status}"
            data = await r.content.read(max_bytes)
            return data, ""
    except Exception as e:  # noqa: BLE001
        return b"", str(e)
    finally:
        if owns and http_session is not None:
            await http_session.close()


def extract(data: bytes, url: str) -> tuple[dict, str]:
    kind = _kind_of(data, url)
    meta = extract_pdf(data) if kind == "pdf" else extract_office(data)
    return meta, kind


def doc_urls_from_session(session: Session) -> list[str]:
    """Collect document URLs already discovered (dorks, wayback, github)."""
    urls: list[str] = []
    for cat in ("dork", "wayback", "github"):
        for f in session.by_category(cat):
            u = f.meta.get("url", "")
            if u and is_document(u) and u not in urls:
                urls.append(u)
    return urls


async def harvest(urls: list[str], session: Optional[Session] = None,
                  cap: int = 40, concurrency: int = 6,
                  on_stage: Optional[Callable[[str], None]] = None,
                  http_session=None) -> list[Finding]:
    """Fetch documents and record their metadata + derived intel."""
    import asyncio
    urls = [u for u in urls if is_document(u)][:cap]
    sem = asyncio.Semaphore(concurrency)
    findings: list[Finding] = []
    agg_people, agg_software = set(), set()

    async def _one(url: str):
        async with sem:
            if on_stage:
                on_stage(f"docmeta {url.rsplit('/', 1)[-1]}")
            data, err = await fetch_doc(url, http_session=http_session)
            if err or not data:
                return
            meta, kind = extract(data, url)
            if not meta:
                return
            d = derive(meta, kind)
            agg_people.update(d["people"])
            agg_software.update(d["software"])
            bits = []
            if d["people"]:
                bits.append("author(s): " + ", ".join(d["people"]))
            if d["software"]:
                bits.append("software: " + ", ".join(d["software"]))
            if d["company"]:
                bits.append("company: " + ", ".join(d["company"]))
            sev = Severity.MEDIUM if d["people"] else Severity.LOW
            findings.append(Finding(
                "docmeta", url, "; ".join(bits) or "metadata found", "docmeta",
                sev, meta={"url": url, "raw": meta, **d}))

    await asyncio.gather(*[_one(u) for u in urls])

    # aggregate intel findings for the dossier
    if agg_people:
        findings.append(Finding(
            "docmeta", "people",
            "usernames/authors from documents: " + ", ".join(sorted(agg_people)),
            "docmeta", Severity.MEDIUM,
            meta={"people": sorted(agg_people)}))
    if agg_software:
        findings.append(Finding(
            "docmeta", "software",
            "software/versions seen: " + ", ".join(sorted(agg_software)),
            "docmeta", Severity.LOW, meta={"software": sorted(agg_software)}))

    if session is not None and findings:
        session.add_many(findings)
        session.record_query(f"docmeta:{len(urls)} docs")
    return findings
