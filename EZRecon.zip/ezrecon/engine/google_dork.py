"""Google dorking via the Custom Search JSON API.

Ships the mainframe dork catalogue (Listing 6-1) as a set of toggleable
queries. The base 'site:{domain}' dork anchors the search; other dorks are
appended to it unless they are flagged unanchored. Every query that runs is
recorded so it can be exported to queries.txt for the lab report.
"""

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Optional
from urllib.parse import quote_plus

from ..config import get_key
from ..models import Finding, Session, Severity

_CATALOGUE = Path(__file__).parent.parent / "data" / "mainframe_dorks.json"
CSE_URL = "https://www.googleapis.com/customsearch/v1"

# No-key mode: build a clickable search URL for each dork instead of calling
# the API. This is the classic dork workflow - paste/click into a browser.
SEARCH_ENGINES = {
    "google": "https://www.google.com/search?q={q}",
    "bing": "https://www.bing.com/search?q={q}",
    "duckduckgo": "https://duckduckgo.com/?q={q}",
    "startpage": "https://www.startpage.com/sp/search?query={q}",
}


@dataclass
class Dork:
    id: int
    query: str
    note: str
    anchored: bool
    default: bool
    enabled: bool = False


@lru_cache(maxsize=1)
def _raw_catalogue() -> list[dict]:
    return json.loads(_CATALOGUE.read_text())["dorks"]


def load_catalogue() -> list[Dork]:
    dorks = []
    for d in _raw_catalogue():
        dorks.append(Dork(id=d["id"], query=d["query"], note=d.get("note", ""),
                          anchored=d.get("anchored", True),
                          default=d.get("default", False),
                          enabled=d.get("default", False)))
    return dorks


def build_query(dork: Dork, domain: str) -> str:
    q = dork.query.replace("{domain}", domain)
    if dork.id == 1:  # the base 'site:' dork is already complete
        return q
    if dork.anchored:
        return f"site:{domain} {q}"
    return q


def search_url(query: str, engine: str = "google") -> str:
    """Build a clickable web-search URL for a dork query (no API needed)."""
    tmpl = SEARCH_ENGINES.get(engine, SEARCH_ENGINES["google"])
    return tmpl.format(q=quote_plus(query))


def dork_links(
    domain: str,
    dorks: Optional[list[Dork]] = None,
    engine: str = "google",
    session: Optional[Session] = None,
) -> list[Finding]:
    """No-key mode: emit a clickable search URL per selected dork.

    Nothing is fetched - these are links you open in a browser, so there's no
    API key, no quota and no terms-of-service issue. The raw dork strings are
    still recorded for queries.txt.
    """
    dorks = dorks if dorks is not None else load_catalogue()
    active = [d for d in dorks if d.enabled or d.id == 1]
    queries = [build_query(d, domain) for d in active]
    return links_for_queries(queries, engine=engine, session=session)


def links_for_queries(
    queries: list[str],
    engine: str = "google",
    session: Optional[Session] = None,
) -> list[Finding]:
    """No-key link findings from explicit (possibly hand-edited) query strings."""
    findings: list[Finding] = []
    for q in queries:
        q = q.strip()
        if not q:
            continue
        url = search_url(q, engine)
        if session is not None:
            session.record_query(q)
        findings.append(
            Finding("dork", q, url, f"dork-link:{engine}", Severity.INFO,
                    meta={"url": url, "query": q, "engine": engine})
        )
    if session is not None:
        session.add_many(findings)
    return findings


def _do_cse(query: str, api_key: str, cse_id: str, num: int) -> list[dict]:
    import requests

    resp = requests.get(
        CSE_URL,
        params={"q": query, "key": api_key, "cx": cse_id, "num": min(num, 10)},
        timeout=15,
    )
    if resp.status_code != 200:
        # Google returns the real reason in the JSON body - surface it instead
        # of a bare "400 Bad Request".
        detail = ""
        try:
            err = resp.json().get("error", {})
            msg = err.get("message", "")
            reasons = ", ".join(
                e.get("reason", "") for e in err.get("errors", []) if e.get("reason")
            )
            status = err.get("status", "")
            detail = " ".join(p for p in (msg, f"[{reasons}]" if reasons else "",
                                          f"({status})" if status else "") if p)
        except Exception:  # noqa: BLE001
            detail = resp.text[:200]
        raise RuntimeError(f"HTTP {resp.status_code}: {detail or 'no detail returned'}")

    data = resp.json()
    return [
        {"title": i.get("title", ""), "link": i.get("link", ""),
         "snippet": i.get("snippet", "")}
        for i in data.get("items", [])
    ]


def _is_fatal_cse_error(msg: str) -> bool:
    """Credential/config errors that will fail identically for every dork."""
    m = msg.lower()
    if "http 400" in m or "http 403" in m:
        return True
    return any(k in m for k in (
        "api key not valid", "invalid value", "invalid argument",
        "permission_denied", "has not been used", "is disabled",
        "keyinvalid", "daily limit", "quota",
    ))


async def run_dorks(
    domain: str,
    dorks: Optional[list[Dork]] = None,
    num_results: int = 5,
    session: Optional[Session] = None,
) -> list[Finding]:
    dorks = dorks if dorks is not None else [d for d in load_catalogue() if d.enabled]
    active = [d for d in dorks if d.enabled or d.id == 1]
    queries = [build_query(d, domain) for d in active]
    return await run_queries(queries, num_results=num_results, session=session)


async def run_queries(
    queries: list[str],
    num_results: int = 5,
    session: Optional[Session] = None,
) -> list[Finding]:
    """Fetch results via the Custom Search API for explicit query strings."""
    api_key = get_key("google_api_key")
    cse_id = get_key("google_cse_id")
    if not (api_key and cse_id):
        return [Finding("dork", "error",
                        "Google API key / CSE ID not configured — use no-key link "
                        "mode instead: `ezrecon dork <domain> --links` (or the "
                        "'Open as links' button in the TUI).",
                        "google-dork", Severity.INFO)]

    loop = asyncio.get_event_loop()
    findings: list[Finding] = []

    for query in queries:
        query = query.strip()
        if not query:
            continue
        if session is not None:
            session.record_query(query)
        try:
            items = await loop.run_in_executor(
                None, _do_cse, query, api_key, cse_id, num_results
            )
        except Exception as e:  # noqa: BLE001
            msg = str(e)
            if _is_fatal_cse_error(msg):
                findings.append(Finding(
                    "dork", "error",
                    f"Google Custom Search rejected the request: {msg}. "
                    "Check that the API key is valid, the Custom Search API is "
                    "enabled for its project, and the CSE ID (cx) is correct.",
                    "google-dork", Severity.HIGH,
                    meta={"raw": msg, "fatal": True}))
                break
            findings.append(Finding("dork", "error", f"{query} -> {e}",
                                    "google-dork"))
            continue
        for it in items:
            sev = Severity.MEDIUM if any(
                k in (it["title"] + it["snippet"]).lower()
                for k in ("password", "jcl", "lpar", "racf", "confidential")
            ) else Severity.LOW
            findings.append(
                Finding("dork", it["link"] or it["title"],
                        f"{it['title']} :: {it['snippet'][:120]}",
                        f"dork:{query}", sev, meta={"query": query, **it})
            )
        if not items:
            findings.append(Finding("dork", "info", f"no hits: {query}",
                                    "google-dork", Severity.INFO))

    if session is not None:
        session.add_many(findings)
    return findings
