"""Why a finding is rated the way it is — one source of truth.

Both the report exporters and the TUI finding-detail panel call `explain()`, so
the written report and the on-screen explanation can never drift apart. The
rationale is contextual: it reads the finding's value and meta so, e.g., a WHOIS
transfer-lock that IS set reads very differently from one that is not.

Resolution order (most specific wins):
  1. the engine set finding.meta["why"]/["impact"]/["remediation"] itself
  2. a registry keyed by (category, key) that inspects the finding
  3. a per-category fallback
  4. a per-severity generic fallback
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional

from ..models import Finding, Severity


@dataclass
class Rationale:
    why: str
    impact: str
    remediation: str
    confidence: str  # "verified" | "inferred" | "reported"

    def as_lines(self) -> list[str]:
        out = [f"Why {self._sevless()}: {self.why}"]
        if self.impact:
            out.append(f"Impact: {self.impact}")
        if self.remediation:
            out.append(f"Fix: {self.remediation}")
        out.append(f"Confidence: {self.confidence}")
        return out

    def _sevless(self) -> str:
        return "rated this way"


# --------------------------------------------------------------------------
# confidence
# --------------------------------------------------------------------------
def _confidence(f: Finding) -> str:
    if "confidence" in f.meta:
        return str(f.meta["confidence"])
    if f.meta.get("verified") is True:
        return "verified (resolved/confirmed)"
    if f.meta.get("verified") is False:
        return "inferred (not confirmed)"
    src = (f.source or "").lower()
    if any(s in src for s in ("passive", "crt.sh", "otx", "wayback", "hibp",
                              "shodan", "fofa", "keyserver", "pgp")):
        return "reported by a third-party source"
    if f.category in ("whois", "dns"):
        return "read directly from DNS/WHOIS"
    return "observed by eZrecon"


# --------------------------------------------------------------------------
# per-(category,key) explainers — each reads the finding for context
# --------------------------------------------------------------------------
def _whois_transfer(f: Finding) -> tuple[str, str, str]:
    if f.meta.get("locked") is True or "locked against transfer" in f.value:
        return ("the domain carries clientTransferProhibited, so the registrar "
                "will refuse an unauthorised transfer request",
                "low — an attacker cannot move the domain away without first "
                "defeating the registrar account",
                "no action; keep the registrar lock and account MFA in place")
    return ("no transfer-prohibited status is set, so the domain is not locked "
            "against being transferred to another registrar",
            "an attacker who phishes or breaches the registrar login can move "
            "the domain, taking mail and web with it (domain hijack)",
            "enable the registrar lock (clientTransferProhibited) and MFA on "
            "the registrar account")


def _whois_expiry(f: Finding) -> tuple[str, str, str]:
    days = f.meta.get("days_left")
    if isinstance(days, int) and days < 60:
        return (f"the registration expires in {days} days",
                "a lapsed domain can be re-registered by anyone, handing them "
                "mail, web and any service that trusts the name",
                "renew now and enable auto-renew; consider a multi-year "
                "registration")
    return ("the registration is not close to expiry",
            "informational — no immediate exposure",
            "keep auto-renew enabled")


def _whois_dnssec(f: Finding) -> tuple[str, str, str]:
    return ("the zone is not DNSSEC-signed",
            "responses can be spoofed by an on-path attacker or a poisoned "
            "resolver, redirecting mail and web without touching the domain",
            "sign the zone with DNSSEC and publish the DS record at the "
            "registrar")


def _dns_spf_policy(f: Finding) -> tuple[str, str, str]:
    v = f.value.lower()
    if "+all" in v or "insecure" in v:
        return ("the SPF record ends in +all, which authorises the whole "
                "internet to send as this domain",
                "anyone can send mail that passes SPF as the organisation, "
                "ideal for phishing and business-email compromise",
                "change the SPF policy to -all (hardfail) or ~all (softfail)")
    if "no 'all'" in v:
        return ("the SPF record has no all mechanism, so it neither passes nor "
                "fails unlisted senders cleanly",
                "receivers cannot reliably reject forged senders",
                "add a terminating -all (or ~all) to the SPF record")
    return ("SPF terminates in a fail/softfail, which is the intended posture",
            "low — unlisted senders are marked or rejected",
            "consider -all (hardfail) if not already, once senders are mapped")


def _dns_spf_senders(f: Finding) -> tuple[str, str, str]:
    return ("the SPF include: mechanisms name every third party allowed to "
            "send as this domain",
            "this maps the organisation's SaaS and mail supply chain (a "
            "phishing pretext and a supplier-compromise path)",
            "informational; keep the include list minimal and reviewed")


def _dns_email_auth(f: Finding) -> tuple[str, str, str]:
    if "spf" in f.value.lower():
        return ("the domain has MX (it receives mail) but publishes no SPF",
                "mail can be spoofed as this domain with nothing to fail on",
                "publish an SPF record listing legitimate senders, ending -all")
    return ("the domain has MX but publishes no DMARC policy",
            "even with SPF/DKIM there is no instruction to reject forgeries, "
            "and no reporting of abuse",
            "publish a DMARC record, starting at p=none with rua reporting, "
            "then move to quarantine/reject")


def _dns_dmarc(f: Finding) -> tuple[str, str, str]:
    if "p=none" in f.value.lower():
        return ("a DMARC policy exists but is set to p=none (monitor only)",
                "forged mail is reported but not blocked, so spoofing still "
                "reaches inboxes",
                "once reports look clean, move the policy to quarantine then "
                "reject")
    return ("a DMARC policy is published and enforcing",
            "low — forgeries are quarantined or rejected",
            "keep it enforcing and watch the aggregate reports")


def _dns_caa(f: Finding) -> tuple[str, str, str]:
    return ("no CAA record is published",
            "any certificate authority may issue a certificate for the domain, "
            "widening the mis-issuance and impersonation surface",
            "publish a CAA record naming only the CAs you use")


def _dns_axfr(f: Finding) -> tuple[str, str, str]:
    return ("a name server allowed a full zone transfer (AXFR)",
            "the entire internal DNS map — every host, service and internal "
            "name — is handed over in one request",
            "restrict AXFR to authorised secondaries only")


def _sub_generic(f: Finding) -> tuple[str, str, str]:
    verified = f.meta.get("verified")
    if verified is True or (f.meta.get("ips")):
        return ("a subdomain that resolves to a live address",
                "each live host is fresh attack surface and a pivot into the "
                "estate",
                "confirm it should be public; decommission forgotten hosts")
    return ("a subdomain seen in a passive source but not (yet) resolving",
            "a lead — it may be internal, retired, or a takeover candidate",
            "resolve and probe before relying on it")


def _bucket(f: Finding) -> tuple[str, str, str]:
    if f.severity == Severity.HIGH or "public" in f.key.lower():
        return ("a cloud bucket that exists AND is publicly readable",
                "an immediate data leak — anyone can list and download its "
                "contents, a common way mainframe extracts and backups escape",
                "make the bucket private and audit what was exposed")
    return ("a cloud bucket that exists but is not public",
            "attack surface and a naming-convention leak, not yet a breach",
            "confirm access controls and remove if unused")


def _takeover(f: Finding) -> tuple[str, str, str]:
    return ("a DNS record points at a decommissioned third-party service that "
            "can be re-registered",
            "an attacker can claim the hostname and serve content as the "
            "organisation — phishing, cookie theft, OAuth abuse",
            "remove the dangling record or re-claim the service immediately")


def _breach(f: Finding) -> tuple[str, str, str]:
    return ("an address tied to the domain appears in a known breach",
            "leaked credentials feed password-reuse attacks against the "
            "organisation's logins; even data-only breaches inform phishing",
            "force a reset, enable MFA, and check for reuse on corporate SSO")


def _exposure_thirdparty(f: Finding) -> tuple[str, str, str]:
    return ("an internet-wide scanner already indexes this asset as exposed",
            "the service is reachable and fingerprinted without you touching "
            "the target — an attacker sees the same",
            "confirm the exposure is intended and firewalled appropriately")


REGISTRY: dict[tuple[str, str], Callable[[Finding], tuple[str, str, str]]] = {
    ("whois", "transfer-lock"): _whois_transfer,
    ("whois", "expiry"): _whois_expiry,
    ("whois", "DNSSEC"): _whois_dnssec,
    ("dns", "SPF-policy"): _dns_spf_policy,
    ("dns", "SPF-senders"): _dns_spf_senders,
    ("dns", "email-auth"): _dns_email_auth,
    ("dns", "DMARC"): _dns_dmarc,
    ("dns", "CAA"): _dns_caa,
    ("dns", "AXFR"): _dns_axfr,
    ("subdomain", "passive-summary"): lambda f: (
        "a roll-up of the keyless passive subdomain sources",
        "shows how much of the estate is visible without touching the target",
        "use the resolved names as targets; treat unresolved ones as leads"),
    ("bucket", "public"): _bucket,
    ("takeover", "dangling"): _takeover,
}

CATEGORY_FALLBACK: dict[str, Callable[[Finding], tuple[str, str, str]]] = {
    "subdomain": _sub_generic,
    "bucket": _bucket,
    "takeover": _takeover,
    "breach": _breach,
    "shodan": _exposure_thirdparty,
    "fofa": _exposure_thirdparty,
}


def _generic(f: Finding) -> tuple[str, str, str]:
    if f.severity == Severity.HIGH:
        return ("a high-impact exposure or a confirmed weakness",
                "likely a direct foothold or data exposure — treat as priority",
                "investigate and remediate before the engagement moves on")
    if f.severity == Severity.MEDIUM:
        return ("a weakness or notable exposure worth acting on",
                "raises risk or aids an attacker's next step",
                "review and harden as part of routine remediation")
    if f.severity == Severity.LOW:
        return ("a minor exposure or a useful data point",
                "small on its own; valuable combined with other findings",
                "note it and fold into the wider picture")
    return ("an informational data point gathered during recon",
            "context for the assessment, not a weakness in itself",
            "no action required")


def explain(f: Finding) -> Rationale:
    # layer 1: engine-provided
    if f.meta.get("why"):
        return Rationale(
            why=str(f.meta.get("why")),
            impact=str(f.meta.get("impact", "")),
            remediation=str(f.meta.get("remediation", "")),
            confidence=_confidence(f))
    # layer 2: exact (category, key)
    fn = REGISTRY.get((f.category, f.key))
    # layer 3: per-category
    if fn is None:
        fn = CATEGORY_FALLBACK.get(f.category)
    # layer 4: generic per-severity
    if fn is None:
        fn = _generic
    why, impact, remediation = fn(f)
    return Rationale(why=why, impact=impact, remediation=remediation,
                     confidence=_confidence(f))


def one_line(f: Finding) -> str:
    """A compact single-line reason, for inline use in tables/logs."""
    return explain(f).why


_SHORT_WHY = {
    ("whois", "transfer-lock"): "Not transfer-locked — domain-hijack risk",
    ("whois", "expiry"): "Registration expiring soon — re-registration risk",
    ("dns", "SPF-policy"): "Weak SPF policy — domain can be spoofed",
    ("dns", "DMARC"): "DMARC monitor-only — forgeries still delivered",
    ("dns", "AXFR"): "Zone transfer exposes entire internal DNS",
    ("bucket", "public"): "Public bucket — anyone can read its contents",
    ("takeover", "dangling"): "Dangling DNS — hostname can be hijacked",
}


def short_why(f: Finding, max_words: int = 10) -> str:
    """A ≤max_words reason for the finding's severity, for the CLI 'Why' column.

    Only meaningful for medium/high — callers should blank info/low. Curated for
    the common cases so it reads as a punchy fragment, otherwise derived from the
    same rationale as everything else and trimmed to max_words."""
    # context-sensitive special cases first
    if f.category == "dns" and f.key == "email-auth":
        return ("Domain spoofable — no DMARC policy set"
                if "dmarc" in f.value.lower()
                else "No SPF record — domain is spoofable")
    if f.category in ("shodan", "fofa") and f.key not in ("error", "fofa", "shodan"):
        return "Service exposed and indexed by internet scanners"
    curated = _SHORT_WHY.get((f.category, f.key))
    if curated:
        return curated
    if f.category == "breach":
        return "Breached credentials enable account takeover"

    why = explain(f).why
    for sep in (" — ", "; ", ", so ", ", "):
        if sep in why:
            why = why.split(sep)[0]
            break
    why = why.rstrip(" .").strip()
    words = why.split()
    if len(words) > max_words:
        why = " ".join(words[:max_words]).rstrip(",") + "…"
    return why[:1].upper() + why[1:] if why else ""
