"""Auto-recon: the one-shot passive sweep.

Give it a domain and it runs the passive chain into a single Session. The
independent stages (whois, DNS, crt.sh, subdomain brute, email, optional
Shodan) run concurrently; the stages that depend on what those discovered
(native banner grab, ASN enrichment) run afterwards.

Each stage reports progress through an optional callback so the TUI/CLI can
show a live status line.
"""

from __future__ import annotations

import asyncio
from typing import Callable, Optional

from ..config import get_key, get_setting
from ..models import Session
from . import (
    asn,
    crtsh,
    dns_recon,
    docmeta,
    email_scraper,
    geo,
    harvester,
    passive_subs,
    ports,
    profile as profile_mod,
    shodan_recon,
    subdomains,
    takeover,
    wayback,
    whois_recon,
)
from .base import make_http_session, normalise_target

Stage = Callable[[str], None]


def _dedupe_subdomains(session: Session) -> None:
    """Collapse duplicate subdomains (brute + crt.sh), preferring resolved ones."""
    chosen: dict[str, int] = {}
    new = []
    for f in session.findings:
        if f.category == "subdomain" and f.key not in ("wildcard", "crt.sh", "error"):
            if f.key in chosen:
                idx = chosen[f.key]
                if f.meta.get("ips") and not new[idx].meta.get("ips"):
                    new[idx] = f  # keep the resolved one
                continue
            chosen[f.key] = len(new)
            new.append(f)
        else:
            new.append(f)
    session.findings = new


async def auto_recon(
    target: str,
    do_whois: bool = True,
    do_dns: bool = True,
    do_crtsh: bool = True,
    do_subdomains: bool = True,
    do_passive: bool = True,
    do_email: bool = True,
    do_ports: bool = False,
    do_shodan: bool = False,
    do_asn: bool = True,
    do_geo: bool = True,
    do_takeover: bool = True,
    do_wayback: bool = True,
    do_docmeta: bool = True,
    do_harvest: bool = True,
    do_profile: bool = True,
    timeout: float = 5.0,
    on_stage: Optional[Stage] = None,
) -> Session:
    domain = normalise_target(target)
    sess = Session(domain)
    brute_timeout = float(get_setting("brute_timeout", 2.0))

    def stage(msg: str):
        if on_stage:
            on_stage(msg)

    http = make_http_session(timeout)
    try:
        # ---- independent stages, run concurrently -----------------------
        async def s_whois():
            stage("whois")
            await whois_recon.whois_lookup(domain, session=sess)

        async def s_dns():
            stage("dns")
            await dns_recon.dns_lookup(domain, timeout=timeout, session=sess)
            await dns_recon.zone_transfer(domain, timeout=timeout, session=sess)

        async def s_crtsh():
            stage("crt.sh")
            await crtsh.crtsh_lookup(domain, session=sess, http_session=http,
                                     verify=True)

        async def s_subs():
            stage("subdomain brute")
            await subdomains.brute_force(
                domain, concurrency=int(get_setting("dns_concurrency", 100)),
                timeout=brute_timeout, session=sess)

        async def s_email():
            stage("email spider")
            await email_scraper.scrape(
                domain, max_depth=1,
                concurrency=int(get_setting("spider_concurrency", 20)),
                session=sess)

        async def s_shodan():
            stage("shodan sweep")
            await shodan_recon.mainframe_sweep(domain, limit=5, session=sess)

        jobs = []
        if do_whois:
            jobs.append(s_whois())
        if do_dns:
            jobs.append(s_dns())
        if do_crtsh:
            jobs.append(s_crtsh())
        if do_subdomains:
            jobs.append(s_subs())
        if do_email:
            jobs.append(s_email())
        if do_shodan and get_key("shodan_api_key"):
            jobs.append(s_shodan())

        if jobs:
            await asyncio.gather(*jobs)

        _dedupe_subdomains(sess)

        # ---- dependent stages, run after discovery ----------------------
        post = []

        async def s_ports():
            stage("banner grab")
            hosts = {domain}
            for f in sess.by_category("subdomain"):
                if any(k in f.key for k in ("mainframe", "mf", "zos", "tso", "cics")):
                    hosts.add(f.key)
            for h in list(hosts)[:5]:
                await ports.scan(
                    h, concurrency=int(get_setting("port_concurrency", 200)),
                    timeout=min(timeout, 4.0), session=sess)

        async def s_asn():
            stage("asn enrichment")
            ips = asn.ips_from_session(sess)
            if ips:
                await asn.enrich_ips(ips, session=sess)

        async def s_passive():
            stage("passive subdomains")
            try:
                await passive_subs.passive_lookup(domain, session=sess,
                                                  http_session=http)
            except Exception:  # noqa: BLE001
                pass

        async def s_geo():
            stage("ip geolocation")
            try:
                ips = list(asn.ips_from_session(sess))[:25]
                for ip in ips:
                    await geo.geolocate(ip, session=sess, http_session=http)
            except Exception:  # noqa: BLE001
                pass

        if do_ports:
            post.append(s_ports())
        if do_asn:
            post.append(s_asn())
        if do_passive:
            post.append(s_passive())
        if do_geo:
            post.append(s_geo())
        if post:
            await asyncio.gather(*post)

        # ---- passive OSINT chain (keyless; active/keyed stages stay opt-in) ----
        # takeover: DNS-only classification over discovered hosts (no HTTP)
        if do_takeover:
            stage("takeover check")
            try:
                await takeover.check_all(sess, do_http=False,
                                         on_stage=lambda m: stage(f"takeover {m}"))
            except Exception:  # noqa: BLE001
                pass

        # wayback: archived URLs (feeds docmeta)
        if do_wayback:
            stage("wayback")
            try:
                await wayback.harvest(domain, session=sess,
                                      http_session=http, on_stage=stage)
            except Exception:  # noqa: BLE001
                pass

        # docmeta: pull metadata from any documents wayback/dorks surfaced
        if do_docmeta:
            doc_urls = docmeta.doc_urls_from_session(sess)
            if doc_urls:
                stage(f"doc metadata ({len(doc_urls)})")
                try:
                    await docmeta.harvest(doc_urls, session=sess,
                                          http_session=http, on_stage=stage)
                except Exception:  # noqa: BLE001
                    pass

        # harvest: consolidate all emails/names + infer naming (PGP is keyless)
        if do_harvest:
            stage("people harvest")
            try:
                await harvester.harvest(domain, session=sess, do_pgp=True,
                                        http_session=http, on_stage=stage)
            except Exception:  # noqa: BLE001
                pass

        # profile: key people + technology in use, from public sources
        if do_profile:
            stage("osint profile (people + technology)")
            try:
                await profile_mod.build_profile(domain, session=sess,
                                                on_stage=stage)
            except Exception:  # noqa: BLE001
                pass
    finally:
        await http.close()

    stage("done")
    return sess
