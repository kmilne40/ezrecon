"""GitHub code-search dorking.

Public repos leak the things mainframe shops least want public: JCL, COBOL,
copybooks, connection strings, and hard-coded creds. This builds GitHub
code-search queries scoped to the target (org / domain keyword) and returns
them as clickable links (keyless, like the Google dork link mode), or fetches
results directly when a GitHub token is configured (the code-search API needs
auth).

Query qualifiers: org:, user:, repo:, filename:, extension:, path:, language:,
"exact string". Docs: https://github.com/search?type=code
"""

from __future__ import annotations

import json
from typing import Callable, Optional
from urllib.parse import quote_plus

from ..config import get_key
from ..models import Finding, Session, Severity
from .base import make_http_session

_WEB = "https://github.com/search?type=code&q="
_API = "https://api.github.com/search/code?q="

# mainframe / secret oriented dork templates. {scope} is the org: or keyword.
_TEMPLATES = [
    ("mainframe JCL", '{scope} extension:jcl', Severity.MEDIUM),
    ("COBOL source", '{scope} extension:cbl', Severity.MEDIUM),
    ("COBOL copybooks", '{scope} extension:cpy', Severity.MEDIUM),
    ("REXX", '{scope} extension:rexx', Severity.LOW),
    ("HLASM", '{scope} extension:hlasm', Severity.LOW),
    ("RACF references", '{scope} RACF', Severity.LOW),
    ("z/OS / LPAR mentions", '{scope} "z/OS" OR LPAR', Severity.LOW),
    ("connection strings", '{scope} jdbc:db2 OR DSN=', Severity.MEDIUM),
    (".env files", '{scope} filename:.env', Severity.HIGH),
    ("config with password", '{scope} filename:config password', Severity.HIGH),
    ("private keys", '{scope} extension:pem OR extension:key', Severity.HIGH),
    ("hardcoded password", '{scope} "password" in:file', Severity.MEDIUM),
    ("API keys", '{scope} api_key OR apikey OR access_key', Severity.MEDIUM),
    ("FTP/host creds", '{scope} "ftp://" OR "userid" OR "passphrase"', Severity.LOW),
]


def _scope(domain: str, org: str = "") -> str:
    if org:
        return f"org:{org}"
    # keyword scope: bare second-level name works better than the full FQDN
    name = domain.split(".")[0] if domain else ""
    return f'"{domain}"' + (f" OR {name}" if name and name != domain else "")


def build_dorks(domain: str, org: str = "") -> list[dict]:
    scope = _scope(domain, org)
    out = []
    for label, tmpl, sev in _TEMPLATES:
        q = tmpl.format(scope=scope)
        out.append({"label": label, "query": q,
                    "url": _WEB + quote_plus(q), "severity": sev})
    return out


def dork_links(domain: str, org: str = "",
               session: Optional[Session] = None) -> list[Finding]:
    """Keyless: emit GitHub code-search URLs as findings (click to run)."""
    findings = []
    for d in build_dorks(domain, org):
        findings.append(Finding(
            "github", d["label"], d["url"], "github-link", Severity.INFO,
            meta={"url": d["url"], "query": d["query"],
                  "intent": d["severity"].value}))
    if session is not None:
        session.add_many(findings)
        session.record_query(f"github-dorks:{org or domain}")
    return findings


def has_token() -> bool:
    return bool(get_key("github_token"))


async def _api_query(query: str, limit: int, timeout: float,
                     http_session=None) -> tuple[list[dict], str]:
    import aiohttp
    token = get_key("github_token")
    if not token:
        return [], ("GitHub code-search API needs a token. Add one with "
                    "`ezrecon config set github_token <TOKEN>` (a fine-grained "
                    "PAT with public-repo read is enough), or use link mode.")
    url = _API + quote_plus(query) + f"&per_page={min(limit, 100)}"
    headers = {"Authorization": f"Bearer {token}",
               "Accept": "application/vnd.github+json",
               "X-GitHub-Api-Version": "2022-11-28"}
    owns = False
    try:
        if http_session is None:
            http_session = make_http_session(timeout)
            owns = True
        async with http_session.get(
            url, headers=headers, timeout=aiohttp.ClientTimeout(total=timeout),
        ) as r:
            if r.status == 403:
                return [], "GitHub API rate-limited or token lacks scope (403)."
            if r.status == 422:
                return [], "GitHub rejected the query (422) — refine qualifiers."
            if r.status != 200:
                return [], f"GitHub API HTTP {r.status}"
            data = json.loads(await r.text())
    except Exception as e:  # noqa: BLE001
        return [], f"GitHub API error: {e}"
    finally:
        if owns and http_session is not None:
            await http_session.close()
    items = []
    for it in (data.get("items") or [])[:limit]:
        items.append({
            "name": it.get("name", ""),
            "path": it.get("path", ""),
            "repo": it.get("repository", {}).get("full_name", ""),
            "url": it.get("html_url", ""),
        })
    return items, ""


async def run_dorks(domain: str, org: str = "", limit: int = 10,
                    timeout: float = 20.0, session: Optional[Session] = None,
                    on_stage: Optional[Callable[[str], None]] = None,
                    http_session=None) -> list[Finding]:
    """Token mode: run each dork via the API and record concrete hits."""
    findings: list[Finding] = []
    for d in build_dorks(domain, org):
        if on_stage:
            on_stage(f"github {d['label']}")
        items, err = await _api_query(d["query"], limit, timeout,
                                      http_session=http_session)
        if err:
            findings.append(Finding("github", "error", err, "github",
                                    Severity.INFO))
            break  # token/ratelimit errors are fatal for the batch
        for it in items:
            findings.append(Finding(
                "github", it["repo"] + "/" + it["path"],
                f"[{d['label']}] {it['url']}", "github", d["severity"],
                meta={"url": it["url"], "repo": it["repo"], "path": it["path"],
                      "label": d["label"]}))
    if session is not None and findings:
        session.add_many(findings)
        session.record_query(f"github:{org or domain}")
    return findings
