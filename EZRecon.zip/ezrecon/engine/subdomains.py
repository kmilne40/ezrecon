"""Concurrent subdomain brute force with wildcard-DNS detection.

The old tool resolved candidates one at a time. This runs them through a
bounded pool of concurrent resolvers, and first probes a random label to
detect wildcard DNS so we don't report the whole wordlist as "found".
"""

from __future__ import annotations

import asyncio
import random
import string
from pathlib import Path
from typing import Callable, Optional

import dns.asyncresolver
import dns.exception
import dns.resolver

from ..models import Finding, Session, Severity
from .base import async_resolver, is_valid_domain

DEFAULT_WORDLIST = Path(__file__).parent.parent / "data" / "subdomains.txt"


def load_wordlist(path: Optional[str] = None) -> list[str]:
    p = Path(path) if path else DEFAULT_WORDLIST
    if not p.exists():
        return []
    words = []
    for line in p.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            words.append(line)
    return words


async def _detect_wildcard(resolver, domain: str) -> set[str]:
    """Resolve a random label; anything it returns is a wildcard IP set."""
    label = "".join(random.choices(string.ascii_lowercase + string.digits, k=16))
    try:
        answers = await resolver.resolve(f"{label}.{domain}", "A")
        return {r.address for r in answers}
    except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN,
            dns.resolver.NoNameservers, dns.exception.DNSException):
        return set()


async def brute_force(
    domain: str,
    wordlist: Optional[list[str]] = None,
    concurrency: int = 100,
    timeout: float = 2.0,
    session: Optional[Session] = None,
    on_progress: Optional[Callable[[int, int], None]] = None,
) -> list[Finding]:
    domain = domain.strip().rstrip(".")
    if not is_valid_domain(domain):
        return [Finding("subdomain", "error", f"invalid domain: {domain}",
                        "subdomains")]

    words = wordlist if wordlist is not None else load_wordlist()
    resolver = async_resolver(timeout)
    wildcard_ips = await _detect_wildcard(resolver, domain)

    findings: list[Finding] = []
    sem = asyncio.Semaphore(concurrency)
    done = 0
    total = len(words)
    lock = asyncio.Lock()

    async def check(word: str):
        nonlocal done
        host = f"{word}.{domain}"
        async with sem:
            try:
                answers = await resolver.resolve(host, "A")
                ips = {r.address for r in answers}
                # skip if it only resolves to the wildcard address(es)
                real = ips - wildcard_ips
                if real:
                    findings.append(
                        Finding("subdomain", host, ", ".join(sorted(real)),
                                "subdomains", Severity.LOW,
                                meta={"ips": sorted(real)})
                    )
            except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN,
                    dns.resolver.NoNameservers, dns.exception.DNSException):
                pass
            async with lock:
                done += 1
                if on_progress:
                    on_progress(done, total)

    if wildcard_ips:
        findings.append(
            Finding("subdomain", "wildcard", f"wildcard DNS active ({', '.join(sorted(wildcard_ips))})",
                    "subdomains", Severity.INFO)
        )

    await asyncio.gather(*[check(w) for w in words])

    findings.sort(key=lambda f: f.key)
    if session is not None:
        session.add_many(findings)
        session.record_query(f"subdomain-brute:{domain}")
    return findings
