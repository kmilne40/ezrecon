"""OSINT profile — the people and the technology behind a domain.

Pulls together, from public sources only:
  * Key people — names and usernames from document metadata authors, the
    email-naming pattern, and forum/search results, de-duplicated.
  * People discussing the domain — posters on technical communities whose
    address is @domain, which is both a named human and a technology signal.
  * Technology in use — passive fingerprinting of the organisation's own site
    (Server / X-Powered-By headers, meta generator, common signatures) plus a
    technology-keyword pass over forum posts and search snippets, each with the
    evidence behind it.

Reuses the harvester's web/forum search so there is one search path, not two.
"""

from __future__ import annotations

import re
from typing import Callable, Optional

from ..models import Finding, Session, Severity
from .base import make_http_session

# header/body signatures -> technology name
TECH_SIGNATURES = [
    ("server", "nginx", "nginx"),
    ("server", "apache", "Apache"),
    ("server", "microsoft-iis", "Microsoft IIS"),
    ("server", "cloudflare", "Cloudflare"),
    ("server", "litespeed", "LiteSpeed"),
    ("server", "openresty", "OpenResty"),
    ("x-powered-by", "php", "PHP"),
    ("x-powered-by", "asp.net", "ASP.NET"),
    ("x-powered-by", "express", "Express/Node.js"),
    ("x-powered-by", "servlet", "Java Servlet"),
    ("x-aspnet-version", "", "ASP.NET"),
    ("x-drupal-cache", "", "Drupal"),
    ("x-generator", "", "%value%"),
    ("via", "varnish", "Varnish"),
    ("set-cookie", "wordpress", "WordPress"),
    ("set-cookie", "jsessionid", "Java (JSESSIONID)"),
    ("set-cookie", "asp.net_sessionid", "ASP.NET"),
]

# technologies worth spotting in prose (forum posts, snippets). Mainframe first.
TECH_KEYWORDS = [
    "z/OS", "CICS", "RACF", "Db2", "IMS", "JCL", "COBOL", "TSO", "ISPF",
    "VTAM", "IBM MQ", "WebSphere", "z/VM", "PL/I", "Assembler", "RRSF",
    "ACF2", "Top Secret", "Endevor", "Connect:Direct", "NDM",
    "nginx", "Apache", "IIS", "Citrix", "VMware", "Cisco", "Fortinet",
    "Palo Alto", "SAP", "Oracle", "PostgreSQL", "MySQL", "MongoDB",
    "Kubernetes", "Docker", "Jenkins", "GitLab", "Splunk", "ServiceNow",
    "SharePoint", "Exchange", "Active Directory", "Okta", "Salesforce",
]

_TITLE_RE = re.compile(
    r"\b(CEO|CTO|CIO|CISO|VP|director|head of [a-z ]+|manager|"
    r"administrator|sysadmin|sysprog|systems programmer|engineer|developer|"
    r"architect|DBA|analyst|consultant)\b", re.I)
_META_GEN_RE = re.compile(
    r'<meta[^>]+name=["\']generator["\'][^>]+content=["\']([^"\']+)', re.I)


def detect_tech_from_headers(headers: dict, body: str = "") -> list[tuple[str, str]]:
    """Return [(tech, evidence)] from response headers and a little body."""
    out: list[tuple[str, str]] = []
    seen: set[str] = set()
    low = {k.lower(): str(v) for k, v in headers.items()}
    for hdr, needle, name in TECH_SIGNATURES:
        val = low.get(hdr, "")
        if not val:
            continue
        if needle and needle not in val.lower():
            continue
        tech = val if name == "%value%" else name
        if tech.lower() not in seen:
            seen.add(tech.lower())
            out.append((tech, f"{hdr}: {val[:80]}"))
    m = _META_GEN_RE.search(body or "")
    if m and m.group(1).strip().lower() not in seen:
        out.append((m.group(1).strip(), "meta generator"))
    return out


def detect_tech_in_text(text: str) -> list[str]:
    """Technology keywords mentioned in a blob of prose."""
    low = text.lower()
    hits = []
    for kw in TECH_KEYWORDS:
        if kw.lower() in low and kw not in hits:
            hits.append(kw)
    return hits


def _name_from_email(local: str) -> str:
    parts = re.split(r"[._\-]", local)
    parts = [p for p in parts if p and not p.isdigit()]
    if len(parts) >= 2:
        return " ".join(p.capitalize() for p in parts[:2])
    return local


async def fingerprint_site(domain: str, http_session=None) -> list[tuple[str, str]]:
    import aiohttp
    owns = False
    if http_session is None:
        http_session = make_http_session(12.0)
        owns = True
    try:
        for scheme in ("https://", "http://"):
            try:
                async with http_session.get(
                        scheme + domain,
                        timeout=aiohttp.ClientTimeout(total=12.0)) as r:
                    body = await r.text(errors="replace")
                    return detect_tech_from_headers(dict(r.headers), body[:20000])
            except Exception:  # noqa: BLE001
                continue
    finally:
        if owns:
            await http_session.close()
    return []


async def build_profile(domain: str, session: Optional[Session] = None,
                        keywords: Optional[list[str]] = None,
                        on_stage: Optional[Callable[[str], None]] = None
                        ) -> list[Finding]:
    from . import harvester
    findings: list[Finding] = []

    # --- technology: passive site fingerprint ---
    if on_stage:
        on_stage(f"fingerprinting {domain}")
    tech_evidence: dict[str, str] = {}
    for tech, ev in await fingerprint_site(domain):
        tech_evidence[tech] = ev

    # --- people + mentions from the web/forum search ---
    if on_stage:
        on_stage("searching forums and the web for people and mentions")
    web_emails, mentions = await harvester.web_gather(
        domain, keywords=keywords, on_stage=on_stage)

    # people from @domain addresses (forum posters, search hits)
    people: dict[str, dict] = {}
    for email, tags in web_emails.items():
        local = email.split("@", 1)[0]
        people.setdefault(email, {"name": _name_from_email(local),
                                  "email": email, "sources": set()})
        people[email]["sources"].update(tags)

    # people from document metadata authors already in the session
    if session is not None:
        for f in session.by_category("docmeta"):
            if f.key == "people":
                for nm in f.meta.get("people", []):
                    key = nm.lower()
                    people.setdefault(key, {"name": nm, "email": "",
                                            "sources": set()})
                    people[key]["sources"].add("docmeta")

    # role guesses + tech keywords from the forum mentions
    for m in mentions:
        blob = f"{m.key} {m.value}"
        for tech in detect_tech_in_text(blob):
            tech_evidence.setdefault(tech, f"mentioned in {m.meta.get('via','forum')} result")
        tm = _TITLE_RE.search(blob)
        if tm:
            # attach the role to any person whose name appears in the same blob
            for p in people.values():
                if p["name"] and p["name"].lower() in blob.lower():
                    p["role"] = tm.group(0)

    # also scan any dork/wayback snippets already gathered for tech
    if session is not None:
        for cat in ("dork", "wayback"):
            for f in session.by_category(cat):
                for tech in detect_tech_in_text(f"{f.key} {f.value}"):
                    tech_evidence.setdefault(tech, f"seen in {cat} result")

    # --- emit findings ---
    for p in sorted(people.values(), key=lambda x: x["name"].lower()):
        detail = p["email"] or "(name only)"
        if p.get("role"):
            detail += f" — {p['role']}"
        srcs = ", ".join(sorted(p["sources"])) or "public"
        findings.append(Finding(
            "person", p["name"], f"{detail}  [{srcs}]", "profile",
            Severity.INFO,
            meta={"email": p["email"], "role": p.get("role", ""),
                  "sources": sorted(p["sources"]),
                  "why": "a named individual tied to the domain from public "
                         "sources — a social-engineering and phishing target",
                  "impact": "userid and pretext material",
                  "remediation": "security-awareness training; minimise public "
                                 "exposure of role detail"}))

    for tech in sorted(tech_evidence):
        findings.append(Finding(
            "tech", tech, tech_evidence[tech], "profile", Severity.INFO,
            meta={"evidence": tech_evidence[tech],
                  "why": "technology the organisation appears to run, from "
                         "site fingerprints and public discussion",
                  "impact": "narrows the vulnerability and exploit surface to "
                            "research (versions, known CVEs, default creds)",
                  "remediation": "reduce version/tech disclosure in headers and "
                                 "public posts"}))

    findings.append(Finding(
        "profile", "summary",
        f"{len(people)} people and {len(tech_evidence)} technologies from "
        f"public sources", "profile", Severity.INFO,
        meta={"people": len(people), "tech": len(tech_evidence)}))

    if session is not None:
        session.add_many(findings)
        session.add_many(mentions)   # keep the forum mentions as evidence
        session.record_query(f"profile:{domain}")
    return findings
