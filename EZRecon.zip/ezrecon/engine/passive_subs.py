"""Passive subdomain discovery from several keyless sources.

The brute force finds names you can guess; certificate transparency (crt.sh, its
own module) finds names in certs. This adds the other passive angle — public
passive-DNS and CT aggregators that require no API key — then verifies every
candidate by resolving it, so what you get back is real, de-duplicated, and low
on false positives:

  * HackerTarget hostsearch     (host,ip lines)
  * AlienVault OTX passive DNS  (JSON)
  * CertSpotter issuances       (JSON, CT)
  * JLDC / Anubis               (JSON array)

Every source is best-effort and isolated: one being down or rate-limited never
stops the others.
"""

from __future__ import annotations

import asyncio
import json
import re
from typing import Optional
from urllib.parse import quote

from ..models import Finding, Session, Severity
from .base import is_valid_domain, make_http_session
from .crtsh import _resolve_hosts

_HOST_RE = re.compile(r"[A-Za-z0-9_.\-]+")


def _in_scope(name: str, domain: str) -> str:
    name = name.strip().lstrip("*.").lower().rstrip(".")
    suffix = domain.lower().lstrip(".")
    # true subdomains only (exclude the apex itself — it isn't a subdomain)
    if name and name != suffix and name.endswith("." + suffix):
        if _HOST_RE.fullmatch(name):
            return name
    return ""


# --------------------------------------------------------------------------
# per-source parsers (pure — unit-testable without network)
# --------------------------------------------------------------------------
def parse_hackertarget(raw: str, domain: str) -> set[str]:
    hosts: set[str] = set()
    if not raw or "error" in raw.lower()[:40] or "API count" in raw:
        return hosts
    for line in raw.splitlines():
        host = line.split(",", 1)[0]
        h = _in_scope(host, domain)
        if h:
            hosts.add(h)
    return hosts


def parse_otx(raw: str, domain: str) -> set[str]:
    hosts: set[str] = set()
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return hosts
    for rec in data.get("passive_dns", []) if isinstance(data, dict) else []:
        h = _in_scope(str(rec.get("hostname", "")), domain)
        if h:
            hosts.add(h)
    return hosts


def parse_certspotter(raw: str, domain: str) -> set[str]:
    hosts: set[str] = set()
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return hosts
    if not isinstance(data, list):
        return hosts
    for entry in data:
        for name in entry.get("dns_names", []) if isinstance(entry, dict) else []:
            h = _in_scope(str(name), domain)
            if h:
                hosts.add(h)
    return hosts


def parse_jldc(raw: str, domain: str) -> set[str]:
    hosts: set[str] = set()
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return hosts
    if not isinstance(data, list):
        return hosts
    for name in data:
        h = _in_scope(str(name), domain)
        if h:
            hosts.add(h)
    return hosts


SOURCES = [
    ("hackertarget",
     "https://api.hackertarget.com/hostsearch/?q={d}", parse_hackertarget),
    ("otx",
     "https://otx.alienvault.com/api/v1/indicators/domain/{d}/passive_dns",
     parse_otx),
    ("certspotter",
     "https://api.certspotter.com/v1/issuances?domain={d}"
     "&include_subdomains=true&expand=dns_names", parse_certspotter),
    ("jldc",
     "https://jldc.me/anubis/subdomains/{d}", parse_jldc),
]


# --------------------------------------------------------------------------
# orchestration
# --------------------------------------------------------------------------
async def _fetch(http, url: str, timeout: float) -> str:
    import aiohttp
    try:
        async with http.get(url, timeout=aiohttp.ClientTimeout(total=timeout),
                             headers={"User-Agent": "EZRecon/2.0"}) as r:
            if r.status == 200:
                return await r.text(errors="replace")
    except Exception:  # noqa: BLE001 - best-effort
        return ""
    return ""


async def passive_lookup(
    domain: str,
    timeout: float = 20.0,
    session: Optional[Session] = None,
    http_session=None,
    verify: bool = True,
) -> list[Finding]:
    domain = domain.strip().rstrip(".")
    if not is_valid_domain(domain):
        return [Finding("subdomain", "error", f"invalid domain: {domain}",
                        "passive")]

    owns = False
    if http_session is None:
        http_session = make_http_session(timeout)
        owns = True
    try:
        raws = await asyncio.gather(
            *[_fetch(http_session, url.format(d=quote(domain)), timeout)
              for _n, url, _p in SOURCES])
    finally:
        if owns:
            await http_session.close()

    # union hostnames, remembering which sources found each
    by_host: dict[str, set[str]] = {}
    contributing: set[str] = set()
    for (name, _url, parser), raw in zip(SOURCES, raws):
        got = parser(raw, domain)
        if got:
            contributing.add(name)
        for h in got:
            by_host.setdefault(h, set()).add(name)

    hosts = sorted(by_host)
    live: dict[str, list[str]] = {}
    if hosts and verify:
        live = await _resolve_hosts(hosts, timeout=min(timeout, 3.0))

    findings: list[Finding] = []
    for h in hosts:
        srcs = sorted(by_host[h])
        ips = live.get(h, [])
        if ips:
            findings.append(Finding(
                "subdomain", h, ", ".join(ips), "passive", Severity.LOW,
                meta={"passive": True, "verified": True, "ips": ips,
                      "sources": srcs}))
        elif not verify:
            findings.append(Finding(
                "subdomain", h, "passive record (" + ", ".join(srcs) + ")",
                "passive", Severity.INFO,
                meta={"passive": True, "verified": False, "sources": srcs}))
        # when verifying, silently drop names that don't resolve -> fewer FPs

    resolved = sum(1 for f in findings if f.meta.get("verified"))
    findings.insert(0, Finding(
        "subdomain", "passive-summary",
        f"{resolved} live of {len(hosts)} passive names from "
        f"{len(contributing)} source(s): {', '.join(sorted(contributing)) or 'none reachable'}",
        "passive", Severity.INFO,
        meta={"sources": sorted(contributing), "total": len(hosts),
              "resolved": resolved}))

    if session is not None:
        session.add_many(findings)
        session.record_query(f"passive-subs:{domain}")
    return findings
