"""MyMap: an nmap/NSE script wrapper, ported into EZRecon.

Based on Kev Milne's standalone MyMap (with Hubert Januszewski and Sophie Hall).
This is the engine half: it categorises the installed NSE scripts, searches
them, reads their descriptions, builds nmap commands, runs them (active recon,
so the TUI gates this behind the active toggle), highlights interesting lines in
the output, and writes a short findings paragraph. Speed-dial commands are saved
to a user file so they persist and can be reused, seeded with a few useful
mainframe-flavoured defaults.

Running is done through an argv list rather than a shell, so nothing the user
types is handed to a shell to interpret.
"""

from __future__ import annotations

import asyncio
import os
import re
import shlex
import time
from collections import defaultdict
from pathlib import Path
from typing import Callable, Optional

from ..config import config_path, get_setting

DEFAULT_SCRIPTS_DIR = "/usr/share/nmap/scripts"

# custom sub-menus, in the order MyMap shows them
CUSTOM_CATEGORIES = [
    "MAINFRAME", "SSL", "SMB", "SSH", "RDP",
    "DATABASE", "VULN", "BRUTE", "FTP", "RPC",
]

# output-highlighting keyword sets (ported from MyMap's view_output)
RED_KEYWORDS = [
    "VULN", "Login Success", "State: VULNERABLE", "Anonymous FTP login allowed",
    "Windows NT", "Windows 2000", "Windows 2003", "Windows 2008", "ESXi 6.5.0",
    "EOL", "out of support", "OUT OF SUPPORT", "Out of Support", "Warning",
]
MAGENTA_KEYWORDS = ["dangerous", "weak"]
YELLOW_KEYWORDS = ["deprecated"]

# keywords the report scans for (ported from MyMap's generate_report)
REPORT_KEYWORDS = [
    "vuln", "exploit", "risk", "danger", "warning", "critical", "high",
    "medium", "low", "Insecure", "dangerous", "Anonymous FTP Login",
    "State: VULNERABLE", "EOL", "Windows 2000", "Windows NT", "Windows 2003",
    "Windows 2008", "Out of Support", "Login Success",
]


# --------------------------------------------------------------------------
# scripts + categories
# --------------------------------------------------------------------------
def scripts_dir() -> Path:
    return Path(str(get_setting("nmap_scripts_dir", DEFAULT_SCRIPTS_DIR)))


def have_nmap() -> bool:
    from shutil import which
    return which("nmap") is not None


def _list_script_files() -> list[str]:
    d = scripts_dir()
    try:
        return sorted(f for f in os.listdir(d) if f.endswith(".nse"))
    except (FileNotFoundError, PermissionError):
        return []


def categorize_scripts() -> dict[str, list[str]]:
    """Group the installed NSE scripts.

    Prefix categories (the token before the first '-') plus the custom
    sub-menus MyMap defines (MAINFRAME, SSL, SMB, and so on). Returns an ordered
    dict with the custom categories first, then the prefix categories A-Z.
    """
    scripts = _list_script_files()
    prefix: dict[str, list[str]] = defaultdict(list)
    for s in scripts:
        prefix[s.split("-")[0]].append(s)

    custom: dict[str, list[str]] = {c: [] for c in CUSTOM_CATEGORIES}
    for s in scripts:
        if s.startswith(("tn3270", "cics", "tso", "vtam", "lu", "db2", "ims")):
            custom["MAINFRAME"].append(s)
        if s.startswith("ssl") or s.startswith("tls"):
            custom["SSL"].append(s)
        if s.startswith("smb"):
            custom["SMB"].append(s)
        if s.startswith("ssh"):
            custom["SSH"].append(s)
        if s.startswith("rdp"):
            custom["RDP"].append(s)
        if s.startswith(("oracle", "mysql", "mssql", "ms-sql", "pgsql", "db2")):
            custom["DATABASE"].append(s)
        if "vuln" in s:
            custom["VULN"].append(s)
        if "brute" in s:
            custom["BRUTE"].append(s)
        if "ftp" in s:
            custom["FTP"].append(s)
        if "rpc" in s:
            custom["RPC"].append(s)

    out: dict[str, list[str]] = {}
    for c in CUSTOM_CATEGORIES:
        if custom[c]:
            out[c] = sorted(custom[c])
    for c in sorted(prefix):
        out[c] = sorted(prefix[c])
    return out


def search_scripts(term: str) -> list[str]:
    """Scripts whose filename contains the term (case-insensitive, max 8 chars)."""
    term = (term or "").strip().lower()[:8]
    if not term:
        return []
    return [s for s in _list_script_files() if term in s.lower()]


def describe_script(name: str) -> str:
    """Pull the description block out of an .nse file, if present."""
    p = scripts_dir() / name
    try:
        lines = p.read_text(errors="replace").splitlines(keepends=True)
    except (FileNotFoundError, PermissionError, OSError):
        return ""
    start = next((i for i, ln in enumerate(lines) if "description = [[" in ln), None)
    if start is None:
        return ""
    chunk = []
    for ln in lines[start:]:
        if "]]" in ln:
            chunk.append(ln.split("]]")[0])
            break
        chunk.append(ln)
    return "".join(chunk).replace("description = [[", "").strip()


_ARG_RE = re.compile(r"@args\s+(\S+)\s+(.*)")
_SNAME_RE = re.compile(r"""get_script_args\(\s*SCRIPT_NAME\s*\.\.\s*['"]\.?([\w.]+)['"]""")
_LIT_RE = re.compile(r"""get_script_args\(\s*['"]([\w.]+)['"]""")

# common library args worth surfacing for whole classes of script
_LIB_ARGS = {
    "brute": ["brute.mode", "brute.firstonly", "brute.threads", "brute.delay"],
    "creds": ["userdb", "passdb", "unpwdb.timelimit", "unpwdb.passlimit"],
    "smb": ["smbusername", "smbpassword", "smbdomain"],
}


def script_args(name: str) -> list[dict]:
    """Documented and referenced --script-args for an NSE script.

    Reads the .nse source: @args names from the NSEDoc block, plus the argument
    names referenced through get_script_args(). For brute/creds/smb scripts the
    common library args are appended, since those apply too.
    """
    fname = name if name.endswith(".nse") else name + ".nse"
    stem = fname[:-4]
    try:
        text = (scripts_dir() / fname).read_text(errors="replace")
    except (FileNotFoundError, PermissionError, OSError):
        return []
    out: list[dict] = []
    seen: set[str] = set()

    def add(n, d=""):
        n = n.strip()
        if n and n not in seen:
            seen.add(n)
            out.append({"name": n, "desc": d.strip()})

    for m in _ARG_RE.finditer(text):
        add(m.group(1), m.group(2))
    for m in _SNAME_RE.finditer(text):
        add(f"{stem}.{m.group(1)}")
    for m in _LIT_RE.finditer(text):
        add(m.group(1))
    low = text.lower()
    for lib, largs in _LIB_ARGS.items():
        if (lib == "brute" and "brute" in low) or \
           (lib == "creds" and ("unpwdb" in low or "passdb" in low or "brute" in low)) or \
           (lib == "smb" and stem.startswith("smb")):
            for a in largs:
                add(a)
    return out



def build_argv(script: str = "", target: str = "", port: str = "",
               extra: str = "", output_file: str = "",
               timing: str = "-T4") -> list[str]:
    """Compose the nmap argv. A file target uses -iL; an IP is passed directly."""
    argv = ["nmap"]
    if timing:
        argv.append(timing)
    if port:
        # accept "80", "-p 80", "80,443" or "-p-"
        p = port.strip()
        if p in ("-p-", "-p -"):
            argv.append("-p-")
        elif p.startswith("-p"):
            argv += shlex.split(p)
        else:
            argv += ["-p", p]
    if extra:
        argv += shlex.split(extra)
    if script:
        argv.append(f"--script={scripts_dir()}/{script}")
    if output_file:
        argv += ["-oN", output_file]
    tgt = (target or "").strip()
    if tgt:
        if os.path.isfile(tgt):
            argv += ["-iL", tgt]
        else:
            argv.append(tgt)
    return argv


def command_str(argv: list[str]) -> str:
    return " ".join(shlex.quote(a) for a in argv)


def default_output_file() -> str:
    return time.strftime("%Y_%m_%d-%I_%M_%S_%p") + ".txt"


async def run_argv(argv: list[str], on_line: Optional[Callable[[str], None]] = None,
                   timeout: float = 900.0) -> tuple[str, str]:
    """Run nmap, streaming stdout lines to on_line. Returns (output, error)."""
    if not argv or argv[0] != "nmap":
        return "", "refusing to run a non-nmap command"
    if not have_nmap():
        return "", "nmap not found. Install it (e.g. `sudo apt install nmap`)."
    try:
        proc = await asyncio.create_subprocess_exec(
            *argv, stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT)
    except Exception as e:  # noqa: BLE001
        return "", f"could not start nmap: {e}"
    lines: list[str] = []
    try:
        async def pump():
            assert proc.stdout is not None
            async for raw in proc.stdout:
                ln = raw.decode("utf-8", "replace").rstrip("\n")
                lines.append(ln)
                if on_line:
                    on_line(ln)
        await asyncio.wait_for(pump(), timeout=timeout)
        await asyncio.wait_for(proc.wait(), timeout=timeout)
    except asyncio.TimeoutError:
        try:
            proc.kill()
        except Exception:  # noqa: BLE001
            pass
        return "\n".join(lines), "nmap timed out"
    return "\n".join(lines), ""


# --------------------------------------------------------------------------
# output highlighting + report
# --------------------------------------------------------------------------
def line_style(line: str) -> str:
    """Rich style for a line of nmap output, empty string for no highlight."""
    if any(k in line for k in RED_KEYWORDS):
        return "bold red"
    if any(k in line for k in MAGENTA_KEYWORDS):
        return "magenta"
    if any(k in line for k in YELLOW_KEYWORDS):
        return "#ffb000"
    return ""


def generate_report(output: str, script: str, target: str) -> str:
    """Short pentest-style paragraph plus highlighted context lines."""
    who = f" for target {target}" if target else " for target"
    report = f"Penetration testing report{who} using {script}:\n"
    if any(k.lower() in output.lower() for k in REPORT_KEYWORDS):
        report += ("The scan has identified potential vulnerabilities. It is "
                   "recommended to investigate these findings further and apply "
                   "necessary patches or configuration changes to mitigate any "
                   "risk.")
    else:
        report += ("The scan did not identify any obvious vulnerabilities. "
                   "However, this does not guarantee the security of the system. "
                   "Regular scans and updates are recommended.")
    report += "\n\nHighlighted lines from the output:\n"
    lines = output.split("\n")
    for kw in REPORT_KEYWORDS:
        for idx in [i for i, ln in enumerate(lines) if kw in ln]:
            report += f"Potential item related to '{kw}':\n"
            for i in range(max(0, idx - 3), min(len(lines), idx + 4)):
                report += lines[i] + "\n"
    return report


# --------------------------------------------------------------------------
# speed dial (persisted, seeded with defaults)
# --------------------------------------------------------------------------
DEFAULT_DIALS = {
    "http": "-p 80",
    "https": "-p 443",
    "VTAM": "-p 23 -T4 --script nwg-vtam-enum",
    "ftp-anon": "-T4 -p 21 --script=ftp-anon",
}


def speed_dial_path() -> Path:
    return config_path().parent / "mymap_speed_dial.json"


def load_dials() -> dict[str, str]:
    import json
    p = speed_dial_path()
    if p.exists():
        try:
            return json.loads(p.read_text()).get("speed_dial", {})
        except Exception:  # noqa: BLE001
            return {}
    return dict(DEFAULT_DIALS)


def _save_dials(dials: dict[str, str]) -> Path:
    import json
    p = speed_dial_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps({"speed_dial": dials}, indent=2))
    return p


def save_dial(title: str, flags: str) -> tuple[bool, str]:
    title, flags = (title or "").strip(), (flags or "").strip()
    if not title:
        return False, "A title is required."
    if not flags:
        return False, "There are no flags to save."
    dials = load_dials()
    dials[title] = flags
    _save_dials(dials)
    return True, f"Saved speed dial {title!r}."


def delete_dial(title: str) -> tuple[bool, str]:
    dials = load_dials()
    if title not in dials:
        return False, f"No speed dial named {title!r}."
    del dials[title]
    _save_dials(dials)
    return True, f"Deleted speed dial {title!r}."
