"""AI-OSINT deep-research prompt generator.

Emits a ready-to-paste deep-research prompt (modelled on Listing 6-8) that
tells an LLM to produce a passive OSINT report for the target with strict
evidence rules. Optionally folds in what EZRecon already discovered so the
model has a factual starting point instead of hallucinating one.
"""

from __future__ import annotations

from typing import Optional

from ..models import Session

REPORT_STRUCTURE = """\
Deliverables / Report structure:
  1. Executive summary (max 8 bullet points)
  2. Technical infrastructure overview (domains, subdomains, hosting, mainframe indicators)
  3. Exposed assets and clues (files, repos, forums, pastes, misconfigurations)
  4. Mainframe / legacy system usage (z/OS, CICS, RACF, TSO, Db2, IMS, NJE clues)
  5. Human targets (roles, emails, naming conventions) for social-engineering awareness
  6. Prioritised 10-point action plan with remediation per finding

Format & evidence rules:
  * Use ONLY public / passive sources; list every source used.
  * For every factual claim include at least one evidence URL or raw output
    snippet AND a UTC timestamp.
  * Do not speculate; mark anything uncertain as "unconfirmed".
  * Export a queries.txt containing the exact queries used.
"""


def build_prompt(target: str, session: Optional[Session] = None) -> str:
    scope = target.strip()
    known = ""
    if session is not None and session.findings:
        lines = []
        for cat in session.categories():
            items = session.by_category(cat)[:15]
            if not items:
                continue
            lines.append(f"  [{cat}]")
            for f in items:
                lines.append(f"    - {f.key}: {f.value[:120]}")
        if lines:
            known = (
                "\nEZRecon has already gathered the following (treat as leads to "
                "verify, not as ground truth):\n" + "\n".join(lines) + "\n"
            )

    return (
        f'"Produce a passive OSINT security report for {scope} and *.{scope} '
        f"following the 'Deliverables / Report structure' and 'Format & evidence "
        f"rules' below. Use only public/passive sources (list used). For every "
        f"factual claim include at least one evidence URL or raw output snippet "
        f"and timestamp (UTC). Provide remediation for each finding and a "
        f'prioritized 10-point action plan. Also export a queries.txt with exact '
        f'queries used."\n\n'
        f"{REPORT_STRUCTURE}"
        f"{known}"
    )
