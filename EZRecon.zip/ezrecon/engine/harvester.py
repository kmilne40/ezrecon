"""People / email aggregation (theHarvester-style).

Rather than yet another scraper, this consolidates the email and name intel
EZRecon already gathers (the email spider, document metadata, crt.sh cert
subjects, dork snippets), adds a keyless PGP keyserver lookup, deduplicates the
result, and infers the organisation's email-naming convention - so from a
handful of known addresses and some names you can generate the likely addresses
for everyone else.

Keyless. The PGP source uses the HKP index on keyserver.ubuntu.com.
"""

from __future__ import annotations

import re
from collections import Counter
from typing import Callable, Optional
from urllib.parse import quote

from ..models import Finding, Session, Severity
from .base import make_http_session

_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
_KEYSERVER = "https://keyserver.ubuntu.com/pks/lookup"


async def keyserver_emails(domain: str, timeout: float = 15.0,
                           http_session=None) -> tuple[list[str], str]:
    """Query the HKP index for keys whose UID contains @domain."""
    import aiohttp
    url = f"{_KEYSERVER}?search={quote(domain)}&op=index&options=mr"
    owns = False
    try:
        if http_session is None:
            http_session = make_http_session(timeout)
            owns = True
        async with http_session.get(
            url, timeout=aiohttp.ClientTimeout(total=timeout),
        ) as r:
            if r.status == 404:
                return [], ""  # no keys is a normal, non-error result
            if r.status != 200:
                return [], f"keyserver HTTP {r.status}"
            text = await r.text()
    except Exception as e:  # noqa: BLE001
        return [], f"keyserver error: {e}"
    finally:
        if owns and http_session is not None:
            await http_session.close()
    emails = sorted({e for e in _EMAIL_RE.findall(text)
                     if e.lower().endswith("@" + domain.lower())
                     or e.lower().endswith("." + domain.lower())})
    return emails, ""


def collect_emails(session: Session) -> dict[str, set[str]]:
    """Gather every email already discovered, tagged by which source found it."""
    found: dict[str, set[str]] = {}

    def _add(email: str, source: str):
        email = email.strip().lower()
        if _EMAIL_RE.fullmatch(email):
            found.setdefault(email, set()).add(source)

    for f in session.by_category("email"):
        for e in _EMAIL_RE.findall(f"{f.key} {f.value}"):
            _add(e, f.source or "spider")
    for f in session.by_category("docmeta"):
        # docmeta 'people' are usernames, not emails, but may be addresses
        for e in _EMAIL_RE.findall(f.value):
            _add(e, "docmeta")
    for cat in ("dork", "wayback", "subdomain"):
        for f in session.by_category(cat):
            for e in _EMAIL_RE.findall(f"{f.key} {f.value}"):
                _add(e, cat)
    return found


def _classify_localpart(local: str) -> str:
    if "." in local:
        a, _, b = local.partition(".")
        if len(a) == 1:
            return "{f}.{last}"
        if len(b) == 1:
            return "{first}.{l}"
        return "{first}.{last}"
    if "_" in local:
        return "{first}_{last}"
    if re.fullmatch(r"[a-z]\.[a-z]+", local):
        return "{f}.{last}"
    return "{flast}"  # single token (jsmith / johnsmith / initials)


def infer_pattern(emails: list[str]) -> dict:
    """Deduce the dominant email-naming convention from known addresses."""
    locals_ = [e.split("@", 1)[0] for e in emails if "@" in e]
    if not locals_:
        return {"pattern": "", "confidence": 0.0, "examples": []}
    counts = Counter(_classify_localpart(lp) for lp in locals_)
    pattern, n = counts.most_common(1)[0]
    return {"pattern": pattern, "confidence": round(n / len(locals_), 2),
            "examples": locals_[:5], "distribution": dict(counts)}


def generate_candidates(names: list[str], domain: str, pattern: str) -> list[str]:
    """Given 'First Last' names and a pattern, produce likely addresses."""
    out = []
    for name in names:
        parts = [p for p in re.split(r"[\s,]+", name.strip()) if p]
        if len(parts) < 2:
            continue
        first, last = parts[0].lower(), parts[-1].lower()
        f, l = first[0], last[0]
        addr = (pattern.replace("{first}", first).replace("{last}", last)
                .replace("{f}", f).replace("{l}", l)
                .replace("{flast}", f + last))
        if "{" not in addr:
            out.append(f"{addr}@{domain}")
    return sorted(set(out))


async def harvest(domain: str, session: Optional[Session] = None,
                  do_pgp: bool = True, names: Optional[list[str]] = None,
                  on_stage: Optional[Callable[[str], None]] = None,
                  http_session=None) -> list[Finding]:
    """Consolidate all email/name intel + PGP lookup + pattern inference."""
    findings: list[Finding] = []
    sources = collect_emails(session) if session is not None else {}

    if do_pgp:
        if on_stage:
            on_stage(f"pgp keyserver {domain}")
        pgp, err = await keyserver_emails(domain, http_session=http_session)
        for e in pgp:
            sources.setdefault(e.lower(), set()).add("pgp")
        if err:
            findings.append(Finding("email", "pgp-note", err, "harvester",
                                    Severity.INFO))

    all_emails = sorted(sources)
    # per-email findings (deduped, with the sources that found each)
    for e in all_emails:
        findings.append(Finding(
            "email", e, e, "harvester", Severity.LOW,
            meta={"email": e, "sources": sorted(sources[e])}))

    # naming-convention inference
    pat = infer_pattern(all_emails)
    if pat["pattern"]:
        findings.append(Finding(
            "email", "pattern",
            f"likely email format: {pat['pattern']}@{domain} "
            f"(confidence {pat['confidence']}, from {len(all_emails)} addresses)",
            "harvester", Severity.INFO, meta=pat))

    # generated candidates from names (docmeta people + any passed in)
    doc_names = []
    if session is not None:
        for f in session.by_category("docmeta"):
            if f.key == "people":
                doc_names += f.meta.get("people", [])
    all_names = list({*(names or []), *doc_names})
    if pat["pattern"] and all_names:
        cands = generate_candidates(all_names, domain, pat["pattern"])
        # don't re-list ones we already confirmed
        new = [c for c in cands if c not in sources]
        if new:
            findings.append(Finding(
                "email", "candidates",
                f"{len(new)} inferred addresses from names + pattern: "
                + ", ".join(new[:20]) + ("…" if len(new) > 20 else ""),
                "harvester", Severity.INFO,
                meta={"candidates": new, "pattern": pat["pattern"]}))

    summary = Finding(
        "email", "harvest-summary",
        f"{len(all_emails)} unique emails across "
        f"{len(set().union(*sources.values())) if sources else 0} sources",
        "harvester", Severity.INFO,
        meta={"total": len(all_emails)})
    findings.insert(0, summary)

    if session is not None and findings:
        session.add_many(findings)
        session.record_query(f"harvester:{domain}")
    return findings
