"""EZRecon - mainframe-focused passive reconnaissance toolkit.

A ground-up rebuild of the EZRecon tool referenced in *Hacking Mainframes*
(Chapter 6). Async recon engine with a Textual TUI and a scriptable CLI.
"""

__version__ = "2.5.2"
__author__ = "Kev Milne (OffensiveSec.org)"

APP_NAME = "EZRecon"
APP_TAGLINE = "Passive reconnaissance for the mainframe hunter"
