"""Per-session runtime options for the TUI.

These mirror the CLI flags (wordlist, depths, ports, preview engine) so the
interactive front-end can drive the same engine parameters instead of relying
on hardcoded defaults. One ``Options`` instance lives on the app and is passed
into the module workers.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from . import config


@dataclass
class Options:
    # subdomains
    wordlist_path: str = ""            # empty -> built-in list
    dns_concurrency: int = 100
    brute_timeout: float = 2.0
    # email spider
    email_seed: str = ""              # empty -> the target itself
    email_depth: int = 2
    email_max_pages: int = 200
    spider_concurrency: int = 20
    known_emails: list[str] = field(default_factory=list)
    # ports
    ports: str = ""                   # empty -> mainframe profile; else "21,23,.."
    port_concurrency: int = 200
    # preview
    preview_engine: str = "auto"
    preview_limit: int = 10
    # chaining
    chain_enabled: bool = True
    chain_cap: int = 10

    @classmethod
    def from_config(cls) -> "Options":
        return cls(
            dns_concurrency=int(config.get_setting("dns_concurrency", 100)),
            brute_timeout=float(config.get_setting("brute_timeout", 2.0)),
            spider_concurrency=int(config.get_setting("spider_concurrency", 20)),
            port_concurrency=int(config.get_setting("port_concurrency", 200)),
        )

    def port_list(self) -> list[int] | None:
        if not self.ports.strip():
            return None
        out: list[int] = []
        for p in self.ports.replace(" ", "").split(","):
            if p.isdigit():
                out.append(int(p))
        return out or None
