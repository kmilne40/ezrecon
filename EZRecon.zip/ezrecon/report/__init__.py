"""Report generation: turn a Session into md / html / json + queries.txt."""
