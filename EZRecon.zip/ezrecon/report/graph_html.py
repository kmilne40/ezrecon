"""Interactive HTML graph export.

Emits a single self-contained HTML file with a force-directed, draggable,
zoomable entity graph (Cytoscape.js loaded from a CDN, with a graceful
fallback message if offline). Phosphor-themed to match the tool. Clicking a
node shows its details and the pivot commands you can run in EZRecon.
"""

from __future__ import annotations

import html
import json

from ..engine.graph import Graph, KIND_COLOUR
from ..engine.pivots import pivots_for
from ..models import Session


def graph_to_html(graph: Graph, session: Session) -> str:
    elements = []
    for n in graph.nodes.values():
        pivots = [{"id": p[0], "label": p[1], "active": p[2]}
                  for p in pivots_for(n.kind)]
        elements.append({
            "data": {
                "id": n.id, "label": n.label, "kind": n.kind,
                "colour": n.colour,
                "url": n.meta.get("url", ""),
                "detail": _detail(n),
                "pivots": pivots,
            }
        })
    for e in graph.edges:
        elements.append({"data": {"source": e.source, "target": e.target,
                                  "label": e.rel}})

    data_json = json.dumps(elements)
    legend = "".join(
        f'<span class="chip" style="--c:{c}">{html.escape(k)}</span>'
        for k, c in KIND_COLOUR.items()
    )
    target = html.escape(session.target)

    return _TEMPLATE.replace("__DATA__", data_json) \
                    .replace("__TARGET__", target) \
                    .replace("__LEGEND__", legend) \
                    .replace("__COUNTS__",
                             f"{len(graph.nodes)} nodes · {len(graph.edges)} edges")


def _detail(node) -> str:
    bits = [f"{node.kind}: {node.label}"]
    for k in ("asn", "prefix", "as_name", "service", "banner", "hint", "url",
              "role", "fingerprint"):
        v = node.meta.get(k)
        if v:
            bits.append(f"{k}: {v}")
    return "\n".join(bits)


_TEMPLATE = r"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<title>EZRecon graph — __TARGET__</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/cytoscape/3.28.1/cytoscape.min.js"></script>
<style>
  :root{--bg:#060a06;--fg:#33ff66;--dim:#1f8a3a;--hi:#b6ffce;--amber:#ffb000;}
  *{box-sizing:border-box;}
  body{margin:0;background:var(--bg);color:var(--fg);
       font-family:"DejaVu Sans Mono","Courier New",monospace;overflow:hidden;}
  header{padding:.6rem 1rem;border-bottom:1px solid var(--dim);}
  header h1{margin:0;color:var(--hi);font-size:1rem;}
  header .meta{color:var(--dim);font-size:.8rem;}
  #legend{padding:.4rem 1rem;border-bottom:1px solid var(--dim);font-size:.75rem;}
  .chip{margin-right:.8rem;color:var(--c);}
  .chip::before{content:"\25CF ";}
  #cy{position:absolute;top:0;left:0;right:340px;bottom:0;margin-top:96px;}
  #panel{position:absolute;top:96px;right:0;width:340px;bottom:0;
         border-left:1px solid var(--dim);padding:1rem;overflow:auto;
         background:#04120a;}
  #panel h2{color:var(--amber);font-size:.9rem;margin:.2rem 0 .6rem;}
  #panel pre{white-space:pre-wrap;color:var(--hi);font-size:.8rem;}
  #panel .pivots{margin-top:1rem;}
  #panel .pivot{display:block;margin:.3rem 0;padding:.35rem .5rem;
        border:1px solid var(--dim);color:var(--fg);text-decoration:none;
        font-size:.8rem;background:#08100a;}
  #panel .pivot.active{border-color:var(--amber);}
  #panel .cmd{color:var(--dim);font-size:.72rem;user-select:all;}
  a{color:var(--amber);}
  .fallback{padding:2rem;color:var(--amber);}
</style></head><body>
<header>
  <h1>EZRecon entity graph — __TARGET__</h1>
  <div class="meta">__COUNTS__ · drag to move · scroll to zoom · click a node</div>
</header>
<div id="legend">__LEGEND__</div>
<div id="cy"></div>
<div id="panel"><h2>Select a node</h2>
  <div>Click any node to see its details and the EZRecon pivots you can run
  against it.</div></div>
<script>
var ELEMENTS = __DATA__;
function esc(s){return (s||"").replace(/[&<>]/g,function(c){
  return {"&":"&amp;","<":"&lt;",">":"&gt;"}[c];});}
if (typeof cytoscape === "undefined") {
  document.getElementById("cy").innerHTML =
    '<div class="fallback">Cytoscape could not load (offline?). '+
    'The graph data is still embedded in this file. Re-open with a connection '+
    'to render the interactive view.</div>';
} else {
  var cy = cytoscape({
    container: document.getElementById("cy"),
    elements: ELEMENTS,
    style: [
      {selector:"node", style:{
        "background-color":"data(colour)","label":"data(label)",
        "color":"#b6ffce","font-size":"9px","font-family":"monospace",
        "text-valign":"bottom","text-margin-y":"3px","width":"18px",
        "height":"18px","border-width":"1px","border-color":"#0a0e0a"}},
      {selector:"edge", style:{
        "width":1,"line-color":"#1f8a3a","target-arrow-color":"#1f8a3a",
        "target-arrow-shape":"triangle","curve-style":"bezier",
        "label":"data(label)","font-size":"7px","color":"#1f8a3a",
        "text-rotation":"autorotate"}},
      {selector:"node:selected", style:{
        "border-width":"2px","border-color":"#ffb000"}}
    ],
    layout:{name:"cose",animate:false,padding:30,nodeRepulsion:8000}
  });
  cy.on("tap","node",function(evt){
    var d = evt.target.data();
    var html = "<h2>"+esc(d.label)+"</h2>";
    html += "<pre>"+esc(d.detail)+"</pre>";
    if (d.url) html += '<div><a href="'+esc(d.url)+'" target="_blank">open URL</a></div>';
    if (d.pivots && d.pivots.length){
      html += '<div class="pivots"><h2>Pivots</h2>';
      d.pivots.forEach(function(p){
        html += '<div class="pivot'+(p.active?" active":"")+'">'+esc(p.label)+
          (p.active?" <span style=\"color:#ffb000\">[active]</span>":"")+
          '<div class="cmd">node: '+esc(d.id)+'</div></div>';
      });
      html += '</div>';
    }
    document.getElementById("panel").innerHTML = html;
  });
}
</script>
</body></html>"""
