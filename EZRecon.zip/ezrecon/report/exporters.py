"""Structured report as plain text, DOCX and PDF.

A single block model (headings, body, bullets, monospace, rules) is rendered to
all three formats so a delivered report looks the same whichever you save. The
DOCX and PDF writers are pure Python — no third-party dependencies — so the tool
stays self-contained.
"""
from __future__ import annotations

import html
import struct  # noqa: F401  (kept for future binary needs)
import time
import zipfile
from pathlib import Path

from ..models import Session, Severity

SEV_ORDER = {"high": 0, "medium": 1, "low": 2, "info": 3}
BLUE = "1F497D"


# --------------------------------------------------------------------------
# block model
# --------------------------------------------------------------------------
def build_blocks(session: Session) -> list[tuple[str, str]]:
    """Turn a Session into an ordered list of (kind, text) blocks.

    kind is one of: h1, h2, body, bullet, mono, rule, spacer.
    """
    d = session.to_dict()
    blocks: list[tuple[str, str]] = []
    blocks.append(("h1", f"eZrecon Reconnaissance Report"))
    blocks.append(("body", f"Target: {session.target or '(none)'}"))
    blocks.append(("body", f"Generated: {d['started_iso']}"))
    blocks.append(("body", f"Findings: {d['finding_count']}"))
    blocks.append(("rule", ""))

    # summary counts
    counts = {"high": 0, "medium": 0, "low": 0, "info": 0}
    for f in session.findings:
        counts[f.severity.value] = counts.get(f.severity.value, 0) + 1
    blocks.append(("h2", "Summary"))
    blocks.append(("body",
                   f"High: {counts['high']}    Medium: {counts['medium']}    "
                   f"Low: {counts['low']}    Info: {counts['info']}"))
    blocks.append(("spacer", ""))

    # key findings
    hi = session.highlights()
    if hi:
        blocks.append(("h2", "Key findings"))
        for f in hi:
            blocks.append(("bullet",
                           f"[{f.severity.value.upper()}] {f.category}/{f.key}: "
                           f"{f.value}"))
        blocks.append(("spacer", ""))

    # by category
    for cat in session.categories():
        items = [i for i in session.by_category(cat) if i.key != "error"]
        if not items:
            continue
        blocks.append(("h2", cat.title()))
        for f in sorted(items, key=lambda x: SEV_ORDER[x.severity.value]):
            tag = "" if f.severity == Severity.INFO else f"[{f.severity.value}] "
            blocks.append(("bullet", f"{tag}{f.key}: {f.value}"))
        blocks.append(("spacer", ""))

    # queries
    if session.queries:
        blocks.append(("h2", "Queries used"))
        for q in session.queries:
            blocks.append(("mono", q))
        blocks.append(("spacer", ""))

    blocks.append(("rule", ""))
    blocks.append(("body",
                   "Produced with eZrecon. Reconnaissance only — stay within "
                   "your rules of engagement."))
    return blocks


# --------------------------------------------------------------------------
# plain text
# --------------------------------------------------------------------------
def render_txt(session: Session) -> str:
    lines: list[str] = []
    for kind, text in build_blocks(session):
        if kind == "h1":
            lines.append(text.upper())
            lines.append("=" * len(text))
        elif kind == "h2":
            lines.append("")
            lines.append(text)
            lines.append("-" * len(text))
        elif kind == "bullet":
            lines.append(f"  - {text}")
        elif kind == "mono":
            lines.append(f"    {text}")
        elif kind == "rule":
            lines.append("-" * 72)
        elif kind == "spacer":
            lines.append("")
        else:
            lines.append(text)
    return "\n".join(lines) + "\n"


# --------------------------------------------------------------------------
# DOCX (pure python: a zip of WordprocessingML)
# --------------------------------------------------------------------------
def _r(text: str, bold=False, color=None, font=None, size=None) -> str:
    rpr = []
    if bold:
        rpr.append("<w:b/>")
    if color:
        rpr.append(f'<w:color w:val="{color}"/>')
    if font:
        rpr.append(f'<w:rFonts w:ascii="{font}" w:hAnsi="{font}" w:cs="{font}"/>')
    if size:
        rpr.append(f'<w:sz w:val="{size}"/><w:szCs w:val="{size}"/>')
    rpr_xml = f"<w:rPr>{''.join(rpr)}</w:rPr>" if rpr else ""
    return (f'<w:r>{rpr_xml}<w:t xml:space="preserve">'
            f'{html.escape(text, quote=False)}</w:t></w:r>')


def _p(runs: str, before=None, after="80", border=False) -> str:
    ppr = []
    if border:
        ppr.append('<w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" '
                   f'w:color="{BLUE}"/></w:pBdr>')
    spc = []
    if before:
        spc.append(f'w:before="{before}"')
    if after:
        spc.append(f'w:after="{after}"')
    if spc:
        ppr.append(f'<w:spacing {" ".join(spc)}/>')
    ppr_xml = f"<w:pPr>{''.join(ppr)}</w:pPr>" if ppr else ""
    return f"<w:p>{ppr_xml}{runs}</w:p>"


def _blocks_to_docx_body(blocks) -> str:
    out = []
    for kind, text in blocks:
        if kind == "h1":
            out.append(_p(_r(text, bold=True, color=BLUE, size="44"),
                          after="120"))
        elif kind == "h2":
            out.append(_p(_r(text, bold=True, color=BLUE, size="30"),
                          before="200", after="80"))
        elif kind == "bullet":
            out.append(_p(_r("•  " + text, size="21"), after="40"))
        elif kind == "mono":
            out.append(_p(_r(text, font="Consolas", size="19", color=BLUE),
                          after="20"))
        elif kind == "rule":
            out.append(_p("", after="80", border=True))
        elif kind == "spacer":
            out.append(_p("", after="40"))
        else:
            out.append(_p(_r(text, size="22")))
    return "".join(out)


def render_docx(session: Session, path: Path) -> Path:
    path = Path(path)
    body = _blocks_to_docx_body(build_blocks(session))
    document = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/'
        '2006/main"><w:body>' + body +
        '<w:sectPr><w:pgSz w:w="12240" w:h="15840"/>'
        '<w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" '
        'w:header="720" w:footer="720" w:gutter="0"/></w:sectPr>'
        '</w:body></w:document>')
    content_types = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/'
        'content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-'
        'package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/word/document.xml" ContentType="application/vnd.'
        'openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
        '</Types>')
    rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/'
        'relationships"><Relationship Id="rId1" Type="http://schemas.'
        'openxmlformats.org/officeDocument/2006/relationships/officeDocument" '
        'Target="word/document.xml"/></Relationships>')
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", content_types)
        z.writestr("_rels/.rels", rels)
        z.writestr("word/document.xml", document)
    return path


# --------------------------------------------------------------------------
# PDF (pure python: a minimal single-font-family text PDF)
# --------------------------------------------------------------------------
_PAGE_W, _PAGE_H = 612, 792          # US Letter, points
_MARGIN = 54
_LEADING = 14
_BODY_SIZE = 10
_MONO_W = 0.6                         # Courier advance width per point of size


def _wrap(text: str, size: float, max_w: float) -> list[str]:
    cpl = max(8, int(max_w / (size * _MONO_W)))
    words = text.split(" ")
    lines, cur = [], ""
    for w in words:
        if len(w) > cpl:                       # hard-break very long tokens
            if cur:
                lines.append(cur)
                cur = ""
            while len(w) > cpl:
                lines.append(w[:cpl])
                w = w[cpl:]
            cur = w
            continue
        trial = w if not cur else cur + " " + w
        if len(trial) <= cpl:
            cur = trial
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines or [""]


_TRANSLIT = {"\u2014": "-", "\u2013": "-", "\u2192": "->", "\u2190": "<-",
             "\u2018": "'", "\u2019": "'", "\u201c": '"', "\u201d": '"',
             "\u2026": "...", "\u2022": "-", "\u00a0": " "}


def _ascii(s: str) -> str:
    for k, v in _TRANSLIT.items():
        s = s.replace(k, v)
    return s.encode("latin-1", "replace").decode("latin-1")


def _pdf_escape(s: str) -> str:
    return s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def render_pdf(session: Session, path: Path) -> Path:
    path = Path(path)
    max_w = _PAGE_W - 2 * _MARGIN
    # flatten blocks into laid-out lines: (font_key, size, text, gap_before)
    laid: list[tuple[str, float, str, float]] = []
    for kind, text in build_blocks(session):
        if kind == "h1":
            for ln in _wrap(text, 18, max_w):
                laid.append(("F2", 18, ln, 6))
            laid.append(("F1", _BODY_SIZE, "", 2))
        elif kind == "h2":
            for ln in _wrap(text, 13, max_w):
                laid.append(("F2", 13, ln, 8))
        elif kind == "bullet":
            wrapped = _wrap(text, _BODY_SIZE, max_w - 12)
            for i, ln in enumerate(wrapped):
                laid.append(("F1", _BODY_SIZE,
                             ("- " if i == 0 else "  ") + ln, 0))
        elif kind == "mono":
            for ln in _wrap(text, 9, max_w):
                laid.append(("F3", 9, "    " + ln, 0))
        elif kind == "rule":
            laid.append(("RULE", 0, "", 4))
        elif kind == "spacer":
            laid.append(("F1", _BODY_SIZE, "", 4))
        else:
            for ln in _wrap(text, _BODY_SIZE, max_w):
                laid.append(("F1", _BODY_SIZE, ln, 0))

    # paginate into content streams
    pages: list[str] = []
    y = _PAGE_H - _MARGIN
    cur: list[str] = []

    def flush():
        if cur:
            pages.append("\n".join(cur))

    for font, size, text, gap in laid:
        need = (size or _LEADING) + gap
        if y - need < _MARGIN:
            flush()
            cur = []
            y = _PAGE_H - _MARGIN
        y -= gap
        if font == "RULE":
            y -= 2
            cur.append(f"{_MARGIN} {y:.1f} m {_PAGE_W - _MARGIN} {y:.1f} l S")
            y -= 4
            continue
        y -= size
        cur.append("BT /%s %d Tf %d %.1f Td (%s) Tj ET" %
                   (font, size, _MARGIN, y, _pdf_escape(_ascii(text))))
        y -= 3
    flush()
    if not pages:
        pages = [""]

    # assemble the PDF objects
    objs: list[str] = []

    def add(obj: str) -> int:
        objs.append(obj)
        return len(objs)

    font_objs = {
        "F1": add("<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>"),
        "F2": add("<< /Type /Font /Subtype /Type1 /BaseFont /Courier-Bold >>"),
        "F3": add("<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>"),
    }
    fonts_res = " ".join(f"/{k} {v} 0 R" for k, v in font_objs.items())
    kids_ids: list[int] = []
    pages_id_placeholder = len(objs) + 1  # will be the Pages object id
    # reserve pages object id by adding placeholder later; build page/content first
    page_ids: list[int] = []
    for stream in pages:
        content = f"<< /Length {len(stream)} >>\nstream\n{stream}\nendstream"
        cid = add(content)
        pid = add(
            f"<< /Type /Page /Parent {pages_id_placeholder} 0 R "
            f"/MediaBox [0 0 {_PAGE_W} {_PAGE_H}] "
            f"/Resources << /Font << {fonts_res} >> >> "
            f"/Contents {cid} 0 R >>")
        page_ids.append(pid)
        kids_ids.append(pid)
    kids = " ".join(f"{i} 0 R" for i in kids_ids)
    pages_id = add(f"<< /Type /Pages /Kids [{kids}] /Count {len(kids_ids)} >>")
    # fix parent references if the placeholder guessed wrong
    if pages_id != pages_id_placeholder:
        for pid in page_ids:
            objs[pid - 1] = objs[pid - 1].replace(
                f"/Parent {pages_id_placeholder} 0 R", f"/Parent {pages_id} 0 R")
    catalog_id = add(f"<< /Type /Catalog /Pages {pages_id} 0 R >>")

    # serialise with a correct xref table
    out = "%PDF-1.4\n"
    offsets = [0]
    for i, obj in enumerate(objs, start=1):
        offsets.append(len(out.encode("latin-1", "replace")))
        out += f"{i} 0 obj\n{obj}\nendobj\n"
    xref_pos = len(out.encode("latin-1", "replace"))
    n = len(objs) + 1
    out += f"xref\n0 {n}\n0000000000 65535 f \n"
    for off in offsets[1:]:
        out += f"{off:010d} 00000 n \n"
    out += (f"trailer\n<< /Size {n} /Root {catalog_id} 0 R >>\n"
            f"startxref\n{xref_pos}\n%%EOF")
    path.write_bytes(out.encode("latin-1", "replace"))
    return path


# --------------------------------------------------------------------------
# facade
# --------------------------------------------------------------------------
def save_report(session: Session, path: Path, fmt: str) -> Path:
    fmt = fmt.lower().lstrip(".")
    path = Path(path)
    if path.suffix.lower() != f".{fmt}":
        path = path.with_suffix(f".{fmt}")
    if fmt == "txt":
        path.write_text(render_txt(session))
        return path
    if fmt == "docx":
        return render_docx(session, path)
    if fmt == "pdf":
        return render_pdf(session, path)
    raise ValueError(f"unknown report format: {fmt}")
