"""Structured report as plain text, DOCX and PDF.

A single block model (headings, body, bullets, monospace, rules) is rendered to
all three formats so a delivered report looks the same whichever you save. The
DOCX and PDF writers are pure Python — no third-party dependencies — so the tool
stays self-contained.
"""
from __future__ import annotations

import html
import struct  # noqa: F401  (kept for future binary needs)
import time
import zipfile
from pathlib import Path

from ..models import Session, Severity

SEV_ORDER = {"high": 0, "medium": 1, "low": 2, "info": 3}
BLUE = "1F497D"


# --------------------------------------------------------------------------
# block model
# --------------------------------------------------------------------------
def _risk(counts: dict) -> tuple[int, str]:
    score = min(100, counts["high"] * 10 + counts["medium"] * 4 + counts["low"])
    if counts["high"] or score >= 40:
        band = "High"
    elif counts["medium"] or score >= 15:
        band = "Elevated"
    elif score > 0:
        band = "Low"
    else:
        band = "Informational"
    return score, band


def _host_map(session: Session) -> dict:
    """Group findings by the host/IP they concern, for an asset view."""
    hosts: dict[str, list] = {}
    for f in session.findings:
        h = ""
        if f.category == "subdomain" and f.key not in (
                "wildcard", "crt.sh", "error", "passive-summary"):
            h = f.key
        else:
            h = f.meta.get("host") or f.meta.get("ip") or ""
        if h:
            hosts.setdefault(h, []).append(f)
    return hosts


def build_blocks(session: Session) -> list[tuple[str, str]]:
    """Turn a Session into an ordered list of (kind, text) blocks.

    kind is one of: h1, h2, body, bullet, sub, mono, rule, spacer.
    """
    from ..engine import rationale as _rat
    d = session.to_dict()
    blocks: list[tuple[str, str]] = []
    blocks.append(("h1", "eZrecon Reconnaissance Report"))
    blocks.append(("body", f"Target: {session.target or '(none)'}"))
    blocks.append(("body", f"Generated: {d['started_iso']}"))
    blocks.append(("body", f"Findings: {d['finding_count']}"))
    blocks.append(("rule", ""))

    counts = {"high": 0, "medium": 0, "low": 0, "info": 0}
    for f in session.findings:
        counts[f.severity.value] = counts.get(f.severity.value, 0) + 1
    score, band = _risk(counts)

    # executive summary + risk score
    blocks.append(("h2", "Executive summary"))
    blocks.append(("body",
                   f"Exposure rating: {band} (score {score}/100).  "
                   f"High: {counts['high']}   Medium: {counts['medium']}   "
                   f"Low: {counts['low']}   Info: {counts['info']}."))
    top = sorted([f for f in session.findings
                  if f.severity.rank >= Severity.MEDIUM.rank
                  and f.key != "error"],
                 key=lambda x: -x.severity.rank)[:6]
    if top:
        blocks.append(("body", "What matters most:"))
        for f in top:
            blocks.append(("bullet",
                           f"[{f.severity.value.upper()}] {f.category}/{f.key}: "
                           f"{f.value}"))
            blocks.append(("sub", "Why: " + _rat.one_line(f)))
    else:
        blocks.append(("body",
                       "No medium or high findings — the estate looks tidy "
                       "from a passive vantage point."))
    blocks.append(("spacer", ""))

    # prioritised remediation
    if top:
        blocks.append(("h2", "Prioritised remediation"))
        for i, f in enumerate(top, 1):
            blocks.append(("bullet",
                           f"{i}. {f.category}/{f.key} — "
                           + _rat.explain(f).remediation))
        blocks.append(("spacer", ""))

    # by category, with the why/impact/fix under each non-info finding
    for cat in session.categories():
        items = [i for i in session.by_category(cat) if i.key != "error"]
        if not items:
            continue
        blocks.append(("h2", cat.title()))
        for f in sorted(items, key=lambda x: SEV_ORDER[x.severity.value]):
            tag = "" if f.severity == Severity.INFO else f"[{f.severity.value}] "
            blocks.append(("bullet", f"{tag}{f.key}: {f.value}"))
            if f.severity != Severity.INFO:
                r = _rat.explain(f)
                blocks.append(("sub", f"Why: {r.why}"))
                if r.impact:
                    blocks.append(("sub", f"Impact: {r.impact}"))
                if r.remediation:
                    blocks.append(("sub", f"Fix: {r.remediation}"))
                blocks.append(("sub", f"Confidence: {r.confidence}"))
        blocks.append(("spacer", ""))

    # attack surface by host
    hosts = _host_map(session)
    if hosts:
        blocks.append(("h2", "Attack surface by host"))
        for host in sorted(hosts):
            fs = hosts[host]
            worst = max(fs, key=lambda x: x.severity.rank).severity.value
            blocks.append(("bullet", f"{host}  ({len(fs)} finding(s), "
                                     f"highest: {worst})"))
            for f in sorted(fs, key=lambda x: SEV_ORDER[x.severity.value])[:8]:
                blocks.append(("sub", f"{f.category}/{f.key}: {f.value[:90]}"))
        blocks.append(("spacer", ""))

    if session.queries:
        blocks.append(("h2", "Queries used"))
        for q in session.queries:
            blocks.append(("mono", q))
        blocks.append(("spacer", ""))

    blocks.append(("rule", ""))
    blocks.append(("body",
                   "Produced with eZrecon. Reconnaissance only — stay within "
                   "your rules of engagement. Severity rationale is contextual "
                   "to each check; confidence notes whether a finding was "
                   "verified or inferred."))
    return blocks


# --------------------------------------------------------------------------
# plain text
# --------------------------------------------------------------------------
def render_txt(session: Session) -> str:
    lines: list[str] = []
    for kind, text in build_blocks(session):
        if kind == "h1":
            lines.append(text.upper())
            lines.append("=" * len(text))
        elif kind == "h2":
            lines.append("")
            lines.append(text)
            lines.append("-" * len(text))
        elif kind == "bullet":
            lines.append(f"  - {text}")
        elif kind == "sub":
            lines.append(f"      · {text}")
        elif kind == "mono":
            lines.append(f"    {text}")
        elif kind == "rule":
            lines.append("-" * 72)
        elif kind == "spacer":
            lines.append("")
        else:
            lines.append(text)
    return "\n".join(lines) + "\n"


# --------------------------------------------------------------------------
# DOCX (pure python: a zip of WordprocessingML)
# --------------------------------------------------------------------------
def _r(text: str, bold=False, color=None, font=None, size=None) -> str:
    rpr = []
    if bold:
        rpr.append("<w:b/>")
    if color:
        rpr.append(f'<w:color w:val="{color}"/>')
    if font:
        rpr.append(f'<w:rFonts w:ascii="{font}" w:hAnsi="{font}" w:cs="{font}"/>')
    if size:
        rpr.append(f'<w:sz w:val="{size}"/><w:szCs w:val="{size}"/>')
    rpr_xml = f"<w:rPr>{''.join(rpr)}</w:rPr>" if rpr else ""
    return (f'<w:r>{rpr_xml}<w:t xml:space="preserve">'
            f'{html.escape(text, quote=False)}</w:t></w:r>')


def _p(runs: str, before=None, after="80", border=False) -> str:
    ppr = []
    if border:
        ppr.append('<w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" '
                   f'w:color="{BLUE}"/></w:pBdr>')
    spc = []
    if before:
        spc.append(f'w:before="{before}"')
    if after:
        spc.append(f'w:after="{after}"')
    if spc:
        ppr.append(f'<w:spacing {" ".join(spc)}/>')
    ppr_xml = f"<w:pPr>{''.join(ppr)}</w:pPr>" if ppr else ""
    return f"<w:p>{ppr_xml}{runs}</w:p>"


def _blocks_to_docx_body(blocks) -> str:
    out = []
    for kind, text in blocks:
        if kind == "h1":
            out.append(_p(_r(text, bold=True, color=BLUE, size="44"),
                          after="120"))
        elif kind == "h2":
            out.append(_p(_r(text, bold=True, color=BLUE, size="30"),
                          before="200", after="80"))
        elif kind == "bullet":
            out.append(_p(_r("•  " + text, size="21"), after="40"))
        elif kind == "sub":
            out.append(_p(_r("      " + text, size="18", color="666666"),
                          after="20"))
        elif kind == "mono":
            out.append(_p(_r(text, font="Consolas", size="19", color=BLUE),
                          after="20"))
        elif kind == "rule":
            out.append(_p("", after="80", border=True))
        elif kind == "spacer":
            out.append(_p("", after="40"))
        else:
            out.append(_p(_r(text, size="22")))
    return "".join(out)


def render_docx(session: Session, path: Path) -> Path:
    path = Path(path)
    body = _blocks_to_docx_body(build_blocks(session))
    document = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/'
        '2006/main"><w:body>' + body +
        '<w:sectPr><w:pgSz w:w="12240" w:h="15840"/>'
        '<w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" '
        'w:header="720" w:footer="720" w:gutter="0"/></w:sectPr>'
        '</w:body></w:document>')
    content_types = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/'
        'content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-'
        'package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/word/document.xml" ContentType="application/vnd.'
        'openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
        '</Types>')
    rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/'
        'relationships"><Relationship Id="rId1" Type="http://schemas.'
        'openxmlformats.org/officeDocument/2006/relationships/officeDocument" '
        'Target="word/document.xml"/></Relationships>')
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", content_types)
        z.writestr("_rels/.rels", rels)
        z.writestr("word/document.xml", document)
    return path


# --------------------------------------------------------------------------
# PDF (pure python: a minimal single-font-family text PDF)
# --------------------------------------------------------------------------
_PAGE_W, _PAGE_H = 612, 792          # US Letter, points
_MARGIN = 54
_LEADING = 14
_BODY_SIZE = 10
_MONO_W = 0.6                         # Courier advance width per point of size


def _wrap(text: str, size: float, max_w: float) -> list[str]:
    cpl = max(8, int(max_w / (size * _MONO_W)))
    words = text.split(" ")
    lines, cur = [], ""
    for w in words:
        if len(w) > cpl:                       # hard-break very long tokens
            if cur:
                lines.append(cur)
                cur = ""
            while len(w) > cpl:
                lines.append(w[:cpl])
                w = w[cpl:]
            cur = w
            continue
        trial = w if not cur else cur + " " + w
        if len(trial) <= cpl:
            cur = trial
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines or [""]


_TRANSLIT = {"\u2014": "-", "\u2013": "-", "\u2192": "->", "\u2190": "<-",
             "\u2018": "'", "\u2019": "'", "\u201c": '"', "\u201d": '"',
             "\u2026": "...", "\u2022": "-", "\u00a0": " "}


def _ascii(s: str) -> str:
    for k, v in _TRANSLIT.items():
        s = s.replace(k, v)
    return s.encode("latin-1", "replace").decode("latin-1")


def _pdf_escape(s: str) -> str:
    return s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def render_pdf(session: Session, path: Path) -> Path:
    path = Path(path)
    max_w = _PAGE_W - 2 * _MARGIN
    # flatten blocks into laid-out lines: (font_key, size, text, gap_before)
    laid: list[tuple[str, float, str, float]] = []
    for kind, text in build_blocks(session):
        if kind == "h1":
            for ln in _wrap(text, 18, max_w):
                laid.append(("F2", 18, ln, 6))
            laid.append(("F1", _BODY_SIZE, "", 2))
        elif kind == "h2":
            for ln in _wrap(text, 13, max_w):
                laid.append(("F2", 13, ln, 8))
        elif kind == "bullet":
            wrapped = _wrap(text, _BODY_SIZE, max_w - 12)
            for i, ln in enumerate(wrapped):
                laid.append(("F1", _BODY_SIZE,
                             ("- " if i == 0 else "  ") + ln, 0))
        elif kind == "sub":
            wrapped = _wrap(text, 9, max_w - 24)
            for i, ln in enumerate(wrapped):
                laid.append(("F1", 9, ("      · " if i == 0 else "        ") + ln, 0))
        elif kind == "mono":
            for ln in _wrap(text, 9, max_w):
                laid.append(("F3", 9, "    " + ln, 0))
        elif kind == "rule":
            laid.append(("RULE", 0, "", 4))
        elif kind == "spacer":
            laid.append(("F1", _BODY_SIZE, "", 4))
        else:
            for ln in _wrap(text, _BODY_SIZE, max_w):
                laid.append(("F1", _BODY_SIZE, ln, 0))

    # paginate into content streams
    pages: list[str] = []
    y = _PAGE_H - _MARGIN
    cur: list[str] = []

    def flush():
        if cur:
            pages.append("\n".join(cur))

    for font, size, text, gap in laid:
        need = (size or _LEADING) + gap
        if y - need < _MARGIN:
            flush()
            cur = []
            y = _PAGE_H - _MARGIN
        y -= gap
        if font == "RULE":
            y -= 2
            cur.append(f"{_MARGIN} {y:.1f} m {_PAGE_W - _MARGIN} {y:.1f} l S")
            y -= 4
            continue
        y -= size
        cur.append("BT /%s %d Tf %d %.1f Td (%s) Tj ET" %
                   (font, size, _MARGIN, y, _pdf_escape(_ascii(text))))
        y -= 3
    flush()
    if not pages:
        pages = [""]

    # assemble the PDF objects
    objs: list[str] = []

    def add(obj: str) -> int:
        objs.append(obj)
        return len(objs)

    font_objs = {
        "F1": add("<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>"),
        "F2": add("<< /Type /Font /Subtype /Type1 /BaseFont /Courier-Bold >>"),
        "F3": add("<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>"),
    }
    fonts_res = " ".join(f"/{k} {v} 0 R" for k, v in font_objs.items())
    kids_ids: list[int] = []
    pages_id_placeholder = len(objs) + 1  # will be the Pages object id
    # reserve pages object id by adding placeholder later; build page/content first
    page_ids: list[int] = []
    for stream in pages:
        content = f"<< /Length {len(stream)} >>\nstream\n{stream}\nendstream"
        cid = add(content)
        pid = add(
            f"<< /Type /Page /Parent {pages_id_placeholder} 0 R "
            f"/MediaBox [0 0 {_PAGE_W} {_PAGE_H}] "
            f"/Resources << /Font << {fonts_res} >> >> "
            f"/Contents {cid} 0 R >>")
        page_ids.append(pid)
        kids_ids.append(pid)
    kids = " ".join(f"{i} 0 R" for i in kids_ids)
    pages_id = add(f"<< /Type /Pages /Kids [{kids}] /Count {len(kids_ids)} >>")
    # fix parent references if the placeholder guessed wrong
    if pages_id != pages_id_placeholder:
        for pid in page_ids:
            objs[pid - 1] = objs[pid - 1].replace(
                f"/Parent {pages_id_placeholder} 0 R", f"/Parent {pages_id} 0 R")
    catalog_id = add(f"<< /Type /Catalog /Pages {pages_id} 0 R >>")

    # serialise with a correct xref table
    out = "%PDF-1.4\n"
    offsets = [0]
    for i, obj in enumerate(objs, start=1):
        offsets.append(len(out.encode("latin-1", "replace")))
        out += f"{i} 0 obj\n{obj}\nendobj\n"
    xref_pos = len(out.encode("latin-1", "replace"))
    n = len(objs) + 1
    out += f"xref\n0 {n}\n0000000000 65535 f \n"
    for off in offsets[1:]:
        out += f"{off:010d} 00000 n \n"
    out += (f"trailer\n<< /Size {n} /Root {catalog_id} 0 R >>\n"
            f"startxref\n{xref_pos}\n%%EOF")
    path.write_bytes(out.encode("latin-1", "replace"))
    return path


# --------------------------------------------------------------------------
# facade
# --------------------------------------------------------------------------
def render_html(session: Session, path: Path) -> Path:
    """A self-contained, offline HTML report mirroring the TUI: severity-tagged
    findings with their why/impact/fix, an executive summary and risk score, and
    an attack-surface-by-host view. No external assets, no network."""
    from ..engine import rationale as _rat
    path = Path(path)
    counts = {"high": 0, "medium": 0, "low": 0, "info": 0}
    for f in session.findings:
        counts[f.severity.value] = counts.get(f.severity.value, 0) + 1
    score, band = _risk(counts)
    esc = lambda s: html.escape(str(s), quote=True)
    SEVCOL = {"high": "#ff5555", "medium": "#ffb000", "low": "#7dffb0",
              "info": "#8aa0a8"}

    def badge(sev):
        return (f'<span class="sev" style="background:{SEVCOL[sev]}">'
                f'{sev.upper()}</span>')

    def finding_row(f):
        r = _rat.explain(f)
        rid = esc(f"{f.category}-{f.key}")
        detail = ""
        if f.severity != Severity.INFO:
            detail = (f'<div class="why"><b>Why:</b> {esc(r.why)}<br>'
                      f'<b>Impact:</b> {esc(r.impact)}<br>'
                      f'<b>Fix:</b> {esc(r.remediation)}<br>'
                      f'<span class="conf">confidence: {esc(r.confidence)}</span></div>')
        return (f'<tr class="r {f.severity.value}"><td>{badge(f.severity.value)}</td>'
                f'<td class="cat">{esc(f.category)}</td>'
                f'<td class="key">{esc(f.key)}</td>'
                f'<td class="val">{esc(f.value)}{detail}</td></tr>')

    rows = "".join(finding_row(f) for f in sorted(
        session.findings, key=lambda x: (-x.severity.rank, x.category))
        if f.key != "error")

    hosts = _host_map(session)
    host_html = ""
    if hosts:
        parts = []
        for h in sorted(hosts):
            fs = hosts[h]
            worst = max(fs, key=lambda x: x.severity.rank).severity.value
            lis = "".join(f"<li>{badge(x.severity.value)} {esc(x.category)}/"
                          f"{esc(x.key)}: {esc(x.value[:100])}</li>" for x in fs)
            parts.append(f'<details><summary>{badge(worst)} <b>{esc(h)}</b> '
                         f'({len(fs)})</summary><ul>{lis}</ul></details>')
        host_html = ("<h2>Attack surface by host</h2>" + "".join(parts))

    top = sorted([f for f in session.findings
                  if f.severity.rank >= Severity.MEDIUM.rank and f.key != "error"],
                 key=lambda x: -x.severity.rank)[:6]
    top_html = "".join(
        f"<li>{badge(f.severity.value)} <b>{esc(f.category)}/{esc(f.key)}</b>: "
        f"{esc(f.value[:120])}<br><span class='why'>{esc(_rat.one_line(f))}</span></li>"
        for f in top) or "<li>No medium or high findings.</li>"

    doc = f"""<!doctype html><html><head><meta charset="utf-8">
<title>eZrecon report — {esc(session.target)}</title>
<style>
 body{{background:#060a06;color:#c9ffd8;font:14px/1.5 -apple-system,Segoe UI,Roboto,monospace;margin:0;padding:24px;}}
 h1,h2{{color:#33ff66;}} a{{color:#7dffb0;}}
 .meta{{color:#8aa0a8;margin-bottom:12px;}}
 .score{{display:inline-block;padding:8px 16px;border:1px solid #33ff66;border-radius:6px;margin:8px 0;font-size:18px;}}
 table{{width:100%;border-collapse:collapse;margin-top:8px;}}
 td{{padding:6px 8px;border-bottom:1px solid #12331c;vertical-align:top;}}
 .sev{{color:#060a06;font-weight:700;padding:1px 7px;border-radius:4px;font-size:11px;}}
 .cat{{color:#7dffb0;}} .key{{color:#b6ffce;}} .val{{color:#c9ffd8;}}
 .why{{color:#9fb8ab;font-size:12px;margin-top:4px;padding-left:8px;border-left:2px solid #1c4a2c;}}
 .conf{{color:#6f8c7d;font-style:italic;}}
 details{{margin:4px 0;background:#0a140c;border:1px solid #12331c;border-radius:4px;padding:6px 10px;}}
 summary{{cursor:pointer;}} ul{{margin:6px 0 6px 4px;}} li{{margin:3px 0;list-style:none;}}
</style></head><body>
<h1>eZrecon Reconnaissance Report</h1>
<div class="meta">Target: <b>{esc(session.target or '(none)')}</b> &nbsp;·&nbsp;
 Generated: {esc(session.to_dict()['started_iso'])} &nbsp;·&nbsp;
 {len(session.findings)} findings</div>
<div class="score">Exposure: <b>{band}</b> — {score}/100 &nbsp;
 <span style="color:#ff5555">{counts['high']} high</span> ·
 <span style="color:#ffb000">{counts['medium']} medium</span> ·
 <span style="color:#7dffb0">{counts['low']} low</span> ·
 <span style="color:#8aa0a8">{counts['info']} info</span></div>
<h2>What matters most</h2><ul>{top_html}</ul>
{host_html}
<h2>All findings</h2>
<table><tbody>{rows}</tbody></table>
<p class="meta">Produced with eZrecon. Reconnaissance only — stay within your
 rules of engagement.</p>
</body></html>"""
    path.write_text(doc, encoding="utf-8")
    return path


def save_report(session: Session, path: Path, fmt: str) -> Path:
    fmt = fmt.lower().lstrip(".")
    path = Path(path)
    if path.suffix.lower() != f".{fmt}":
        path = path.with_suffix(f".{fmt}")
    if fmt == "txt":
        path.write_text(render_txt(session))
        return path
    if fmt == "docx":
        return render_docx(session, path)
    if fmt == "pdf":
        return render_pdf(session, path)
    if fmt == "html":
        return render_html(session, path)
    raise ValueError(f"unknown report format: {fmt}")
