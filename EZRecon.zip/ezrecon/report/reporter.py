"""Render a Session to Markdown, HTML, JSON and queries.txt.

The HTML export carries the phosphor look so a delivered report matches the
tool. All exports are deterministic given the same Session.
"""

from __future__ import annotations

import html
import time
from pathlib import Path

from ..models import Session, Severity

SEV_ORDER = {"high": 0, "medium": 1, "low": 2, "info": 3}


def _grouped(session: Session):
    for cat in session.categories():
        items = session.by_category(cat)
        items = [i for i in items if i.key != "error"]
        if items:
            yield cat, items


def to_markdown(session: Session) -> str:
    d = session.to_dict()
    lines = [
        f"# EZRecon OSINT Report — {session.target}",
        "",
        f"*Generated {d['started_iso']} · {d['finding_count']} findings*",
        "",
    ]

    hi = session.highlights()
    if hi:
        lines += ["## Key findings", ""]
        for f in hi:
            lines.append(f"- **[{f.severity.value.upper()}]** "
                         f"`{f.category}/{f.key}` — {f.value}")
        lines.append("")

    for cat, items in _grouped(session):
        lines += [f"## {cat.title()}", ""]
        for f in sorted(items, key=lambda x: SEV_ORDER[x.severity.value]):
            tag = "" if f.severity == Severity.INFO else f"[{f.severity.value}] "
            url = f.meta.get("url", "")
            if url and f.source.startswith("dork-link"):
                lines.append(f"- {tag}**{f.key}**: [{url}]({url})")
            else:
                lines.append(f"- {tag}**{f.key}**: {f.value}")
        lines.append("")

    if session.queries:
        lines += ["## Queries used", "", "```"]
        lines += session.queries
        lines += ["```", ""]

    lines += [
        "---",
        "*Produced with EZRecon 2.0. Passive reconnaissance only — "
        "stay within your rules of engagement.*",
    ]
    return "\n".join(lines)


def to_html(session: Session) -> str:
    d = session.to_dict()
    rows = []
    for cat, items in _grouped(session):
        rows.append(f'<h2>{html.escape(cat.title())}</h2>')
        rows.append('<table>')
        rows.append('<tr><th>Sev</th><th>Key</th><th>Value</th><th>Source</th></tr>')
        for f in sorted(items, key=lambda x: SEV_ORDER[x.severity.value]):
            url = f.meta.get("url", "")
            if url and f.source.startswith("dork-link"):
                cell = f'<a href="{html.escape(url)}">{html.escape(url)}</a>'
            else:
                cell = html.escape(f.value)
            rows.append(
                f'<tr class="sev-{f.severity.value}">'
                f'<td>{f.severity.value}</td>'
                f'<td>{html.escape(f.key)}</td>'
                f'<td>{cell}</td>'
                f'<td>{html.escape(f.source)}</td></tr>'
            )
        rows.append('</table>')

    queries = "\n".join(html.escape(q) for q in session.queries)
    body = "\n".join(rows)
    return f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<title>EZRecon — {html.escape(session.target)}</title>
<style>
  :root {{ --bg:#0a0e0a; --fg:#33ff66; --dim:#1f8a3a; --hi:#b6ffce; --amber:#ffb000; }}
  * {{ box-sizing:border-box; }}
  body {{ background:var(--bg); color:var(--fg); font-family:"DejaVu Sans Mono",
         "Courier New",monospace; margin:0; padding:2rem; line-height:1.5; }}
  h1 {{ color:var(--hi); border-bottom:2px solid var(--dim); padding-bottom:.4rem; }}
  h2 {{ color:var(--amber); margin-top:2rem; text-transform:uppercase;
        letter-spacing:1px; font-size:1rem; }}
  .meta {{ color:var(--dim); margin-bottom:1.5rem; }}
  table {{ width:100%; border-collapse:collapse; margin:.5rem 0 1.5rem; }}
  th,td {{ text-align:left; padding:.35rem .6rem; border-bottom:1px solid #123; }}
  th {{ color:var(--hi); border-bottom:1px solid var(--dim); }}
  td {{ word-break:break-word; }}
  tr.sev-high td:first-child {{ color:#ff5555; font-weight:bold; }}
  tr.sev-medium td:first-child {{ color:var(--amber); }}
  tr.sev-low td:first-child {{ color:var(--fg); }}
  tr.sev-info td:first-child {{ color:var(--dim); }}
  pre {{ background:#04120a; border:1px solid var(--dim); padding:1rem;
         overflow:auto; color:var(--hi); }}
  footer {{ margin-top:2rem; color:var(--dim); border-top:1px solid var(--dim);
            padding-top:.6rem; font-size:.85rem; }}
</style></head><body>
<h1>EZRecon OSINT Report — {html.escape(session.target)}</h1>
<div class="meta">Generated {d['started_iso']} · {d['finding_count']} findings</div>
{body}
<h2>Queries used</h2>
<pre>{queries}</pre>
<footer>Produced with EZRecon 2.0 — passive reconnaissance only.
Stay within your rules of engagement.</footer>
</body></html>"""


def to_queries_txt(session: Session) -> str:
    header = [f"# EZRecon queries — {session.target}",
              f"# {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}", ""]
    return "\n".join(header + session.queries) + "\n"


def write_reports(session: Session, out_dir: Path, stem: str = "") -> dict[str, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = stem or f"ezrecon_{session.target.replace('.', '_')}"
    paths = {
        "md": out_dir / f"{stem}.md",
        "html": out_dir / f"{stem}.html",
        "json": out_dir / f"{stem}.json",
        "queries": out_dir / f"{stem}_queries.txt",
    }
    paths["md"].write_text(to_markdown(session))
    paths["html"].write_text(to_html(session))
    paths["json"].write_text(session.to_json())
    paths["queries"].write_text(to_queries_txt(session))
    return paths
