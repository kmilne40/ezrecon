"""EZRecon command-line interface.

Every engine capability is scriptable here, and running ``ezrecon`` with no
subcommand launches the Textual TUI. Results can be written to md/html/json +
queries.txt with --report.
"""

from __future__ import annotations

import argparse
import asyncio
import sys
from pathlib import Path

from . import __version__, config
from .engine import (
    ai_osint,
    asn,
    crtsh,
    dns_recon,
    email_scraper,
    google_dork,
    pipeline,
    ports,
    shodan_recon,
    subdomains,
    webintel,
    whois_recon,
)
from .models import Finding, Session
from .report import reporter

try:
    from rich.console import Console
    from rich.table import Table
    _console = Console()
except Exception:  # noqa: BLE001
    _console = None


def _print_findings(findings: list[Finding], title: str) -> None:
    if _console is None:
        for f in findings:
            print(f"[{f.severity.value}] {f.category}/{f.key}: {f.value}")
        return
    table = Table(title=title, expand=True, header_style="bold green")
    table.add_column("Sev", style="dim", width=7)
    table.add_column("Key", style="cyan", no_wrap=False)
    table.add_column("Value", overflow="fold")
    colour = {"high": "red", "medium": "yellow", "low": "green", "info": "dim"}
    for f in findings:
        table.add_row(f"[{colour.get(f.severity.value,'')}]{f.severity.value}[/]",
                      f.key, f.value)
    _console.print(table)


def _maybe_report(session: Session, args) -> None:
    if getattr(args, "report", None):
        out = Path(args.report)
        paths = reporter.write_reports(session, out)
        if _console:
            _console.print(f"[green]Reports written to {out}:[/]")
            for k, p in paths.items():
                _console.print(f"  {k:8} {p}")
        else:
            print("Reports:", {k: str(p) for k, p in paths.items()})


async def _run(args) -> int:
    cmd = args.command
    session = Session(getattr(args, "target", "") or getattr(args, "domain", "") or "")

    if cmd == "dns":
        f = await dns_recon.dns_lookup(args.domain, session=session)
        f += await dns_recon.zone_transfer(args.domain, session=session)
        _print_findings(f, f"DNS — {args.domain}")
    elif cmd == "whois":
        f = await whois_recon.whois_lookup(args.domain, session=session)
        _print_findings(f, f"WHOIS — {args.domain}")
    elif cmd == "subdomains":
        wl = subdomains.load_wordlist(args.wordlist) if args.wordlist else None
        f = await subdomains.brute_force(args.domain, wordlist=wl, session=session)
        _print_findings(f, f"Subdomains — {args.domain}")
    elif cmd == "crtsh":
        f = await crtsh.crtsh_lookup(args.domain, session=session)
        _print_findings(f, f"crt.sh — {args.domain}")
    elif cmd == "asn":
        from .engine.base import async_resolver, is_valid_ip
        ips = []
        if is_valid_ip(args.target):
            ips = [args.target]
        else:
            dns_f = await dns_recon.dns_lookup(args.target, session=session)
            ips = [x.value for x in dns_f if x.key == "A"]
        f = await asn.enrich_ips(ips, session=session)
        _print_findings(f or [], f"ASN / netblocks — {args.target}")
    elif cmd == "email":
        f = await email_scraper.scrape(args.url, max_depth=args.depth, session=session)
        _print_findings(f, f"Emails — {args.url}")
    elif cmd == "ports":
        plist = [int(p) for p in args.ports.split(",")] if args.ports else None
        f, _ = await ports.scan(args.target, ports=plist, session=session)
        _print_findings(f, f"Ports — {args.target}")
    elif cmd == "shodan":
        if args.mainframe:
            f = await shodan_recon.mainframe_sweep(args.query or "", session=session)
        else:
            f = await shodan_recon.search(args.query, session=session)
        _print_findings(f, f"Shodan — {args.query or 'mainframe sweep'}")
    elif cmd == "dork":
        cat = google_dork.load_catalogue()
        if args.all:
            for d in cat:
                d.enabled = True
        if args.links:
            f = google_dork.dork_links(args.domain, dorks=cat,
                                       engine=args.engine, session=session)
            _print_findings(f, f"Dork links ({args.engine}) — {args.domain}")
        else:
            f = await google_dork.run_dorks(args.domain, dorks=cat, session=session)
            _print_findings(f, f"Google dorks — {args.domain}")
    elif cmd == "prompt":
        print(ai_osint.build_prompt(args.domain))
        return 0
    elif cmd == "preview":
        results, err = await webintel.get_results(args.query, engine=args.engine)
        if err and not results:
            print(f"no results: {err}")
            return 0
        if _console:
            _console.print(f"[green]{len(results)} results[/] for: {args.query}")
        terms = webintel.terms_from_query(args.query)
        for i, r in enumerate(results[: args.limit], 1):
            print(f"\n[{i}] {r.title}\n    {r.url}")
            if args.pages:
                intel = await webintel.fetch_page(r.url, terms=terms)
                if intel.error:
                    print(f"    ! {intel.error}")
                    continue
                print(f"    HTTP {intel.status} · {intel.content_type} · "
                      f"{intel.size} bytes · {intel.title}")
                for h in intel.contexts[:6]:
                    snip = h["snippet"].replace("❱", "[").replace("❰", "]")
                    print(f"      · {h['term']}: {snip}")
                if args.summary and webintel.has_llm():
                    print("    summary:", webintel.summarise_llm(intel, args.query))
        return 0
    elif cmd == "auto":
        def stage(m):
            if _console:
                _console.print(f"[dim]· {m}[/]")
        session = await pipeline.auto_recon(
            args.domain, do_ports=args.ports, do_shodan=args.shodan, on_stage=stage
        )
        _print_findings(session.highlights() or session.findings,
                        f"Auto-recon — {args.domain}")
    else:
        return 2

    _maybe_report(session, args)
    return 0


def _cmd_config(args) -> int:
    if args.config_action == "set":
        config.set_key(args.name, args.value)
        print(f"Saved {args.name} to {config.config_path()}")
    elif args.config_action == "show":
        cfg = config.load_config()
        print(f"Config: {config.config_path()}")
        for k, v in cfg["keys"].items():
            masked = (v[:4] + "…") if v else "(unset)"
            print(f"  {k}: {masked}")
        print("Settings:")
        for k, v in cfg["settings"].items():
            print(f"  {k}: {v}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="ezrecon",
        description="EZRecon — passive reconnaissance for the mainframe hunter.",
    )
    p.add_argument("--version", action="version", version=f"EZRecon {__version__}")
    sub = p.add_subparsers(dest="command")

    def add_report(sp):
        sp.add_argument("--report", metavar="DIR",
                        help="write md/html/json/queries.txt to DIR")

    sp = sub.add_parser("tui", help="launch the Textual interface")

    sp = sub.add_parser("dns", help="DNS records + zone transfer")
    sp.add_argument("domain"); add_report(sp)

    sp = sub.add_parser("whois", help="WHOIS lookup")
    sp.add_argument("domain"); add_report(sp)

    sp = sub.add_parser("subdomains", help="concurrent subdomain brute force")
    sp.add_argument("domain"); sp.add_argument("--wordlist"); add_report(sp)

    sp = sub.add_parser("crtsh", help="certificate-transparency subdomains")
    sp.add_argument("domain"); add_report(sp)

    sp = sub.add_parser("asn", help="ASN / netblock enrichment (Team Cymru, pure DNS)")
    sp.add_argument("target", help="domain or IPv4 address"); add_report(sp)

    sp = sub.add_parser("email", help="email spider")
    sp.add_argument("url"); sp.add_argument("--depth", type=int, default=2); add_report(sp)

    sp = sub.add_parser("ports", help="native (non-nmap) banner grab")
    sp.add_argument("target"); sp.add_argument("--ports", help="comma list, e.g. 21,23,50000")
    add_report(sp)

    sp = sub.add_parser("shodan", help="Shodan search / mainframe sweep")
    sp.add_argument("query", nargs="?", default="")
    sp.add_argument("--mainframe", action="store_true", help="run the z/OS query library")
    add_report(sp)

    sp = sub.add_parser("dork", help="Google dorks: fetch via API, or --links for no-key browser URLs")
    sp.add_argument("domain")
    sp.add_argument("--all", action="store_true",
                    help="enable every dork in the catalogue")
    sp.add_argument("--links", action="store_true",
                    help="no key needed: output clickable search URLs instead of fetching")
    sp.add_argument("--engine", default="google",
                    choices=["google", "bing", "duckduckgo", "startpage"],
                    help="search engine for --links (default: google)")
    add_report(sp)

    sp = sub.add_parser("prompt", help="print an AI deep-research OSINT prompt")
    sp.add_argument("domain")

    sp = sub.add_parser("preview",
                        help="resolve a dork to real results and (optionally) analyse pages [active]")
    sp.add_argument("query", help="a search/dork query, e.g. 'site:x.com filetype:JCL'")
    sp.add_argument("--engine", default="auto",
                    choices=["auto", "ddg", "api"],
                    help="result source (default: auto = API if keyed, else DDG)")
    sp.add_argument("--limit", type=int, default=10, help="max results to show")
    sp.add_argument("--pages", action="store_true",
                    help="fetch each result page and show terms in context (active)")
    sp.add_argument("--summary", action="store_true",
                    help="add an LLM summary per page (needs an Anthropic key)")

    sp = sub.add_parser("auto", help="one-shot passive sweep + optional report")
    sp.add_argument("domain")
    sp.add_argument("--ports", action="store_true", help="include native banner grab")
    sp.add_argument("--shodan", action="store_true", help="include Shodan mainframe sweep")
    add_report(sp)

    cp = sub.add_parser("config", help="manage API keys / settings")
    csub = cp.add_subparsers(dest="config_action")
    s = csub.add_parser("set"); s.add_argument("name"); s.add_argument("value")
    csub.add_parser("show")

    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command is None or args.command == "tui":
        from .tui.app import run as run_tui
        run_tui()
        return 0
    if args.command == "config":
        return _cmd_config(args)
    return asyncio.run(_run(args))


if __name__ == "__main__":
    sys.exit(main())
