"""EZRecon command-line interface.

Every engine capability is scriptable here, and running ``ezrecon`` with no
subcommand launches the Textual TUI. Results can be written to md/html/json +
queries.txt with --report.
"""

from __future__ import annotations

import argparse
import asyncio
import sys
import json
from pathlib import Path

from . import __version__, config
from .engine import (
    ai_osint,
    asn,
    buckets,
    chaining,
    crtsh,
    dns_recon,
    docmeta,
    email_scraper,
    favicon as favicon_mod,
    github_dork,
    google_dork,
    harvester,
    hibp,
    pipeline,
    ports,
    shodan_recon,
    subdomains,
    takeover,
    wayback,
    webintel,
    whois_recon,
)
from .models import Finding, Session, Severity
from .report import reporter

try:
    from rich.console import Console
    from rich.table import Table
    _console = Console()
except Exception:  # noqa: BLE001
    _console = None


def _print_findings(findings: list[Finding], title: str) -> None:
    if _console is None:
        for f in findings:
            print(f"[{f.severity.value}] {f.category}/{f.key}: {f.value}")
        return
    table = Table(title=title, expand=True, header_style="bold green")
    table.add_column("Sev", style="dim", width=7)
    table.add_column("Key", style="cyan", no_wrap=False)
    table.add_column("Value", overflow="fold")
    colour = {"high": "red", "medium": "yellow", "low": "green", "info": "dim"}
    for f in findings:
        table.add_row(f"[{colour.get(f.severity.value,'')}]{f.severity.value}[/]",
                      f.key, f.value)
    _console.print(table)


def _maybe_report(session: Session, args) -> None:
    if getattr(args, "report", None):
        out = Path(args.report)
        paths = reporter.write_reports(session, out)
        if _console:
            _console.print(f"[green]Reports written to {out}:[/]")
            for k, p in paths.items():
                _console.print(f"  {k:8} {p}")
        else:
            print("Reports:", {k: str(p) for k, p in paths.items()})


async def _run(args) -> int:
    cmd = args.command
    session = Session(getattr(args, "target", "") or getattr(args, "domain", "") or "")

    if cmd == "dns":
        f = await dns_recon.dns_lookup(args.domain, session=session)
        f += await dns_recon.zone_transfer(args.domain, session=session)
        _print_findings(f, f"DNS — {args.domain}")
    elif cmd == "whois":
        f = await whois_recon.whois_lookup(args.domain, session=session)
        _print_findings(f, f"WHOIS — {args.domain}")
    elif cmd == "subdomains":
        wl = subdomains.load_wordlist(args.wordlist) if args.wordlist else None
        f = await subdomains.brute_force(args.domain, wordlist=wl, session=session)
        _print_findings(f, f"Subdomains — {args.domain}")
    elif cmd == "crtsh":
        f = await crtsh.crtsh_lookup(args.domain, session=session)
        _print_findings(f, f"crt.sh — {args.domain}")
    elif cmd == "asn":
        from .engine.base import async_resolver, is_valid_ip
        ips = []
        if is_valid_ip(args.target):
            ips = [args.target]
        else:
            dns_f = await dns_recon.dns_lookup(args.target, session=session)
            ips = [x.value for x in dns_f if x.key == "A"]
        f = await asn.enrich_ips(ips, session=session)
        _print_findings(f or [], f"ASN / netblocks — {args.target}")
    elif cmd == "email":
        f = await email_scraper.scrape(args.url, max_depth=args.depth, session=session)
        _print_findings(f, f"Emails — {args.url}")
    elif cmd == "ports":
        plist = [int(p) for p in args.ports.split(",")] if args.ports else None
        f, _ = await ports.scan(args.target, ports=plist, session=session)
        _print_findings(f, f"Ports — {args.target}")
    elif cmd == "shodan":
        if args.mainframe:
            f = await shodan_recon.mainframe_sweep(args.query or "", session=session)
        else:
            f = await shodan_recon.search(args.query, session=session)
        _print_findings(f, f"Shodan — {args.query or 'mainframe sweep'}")
    elif cmd == "dork":
        cat = google_dork.load_catalogue()
        if args.all:
            for d in cat:
                d.enabled = True
        if args.fetch:
            # keyless: fetch real Title/Link/Snippet results per selected dork
            from .engine import searx as searxmod
            queries = [google_dork.build_query(d, args.domain)
                       for d in cat if d.enabled or d.id == 1]
            # prefer self-hosted SearXNG if configured, else DuckDuckGo
            eng = "searx" if searxmod.has_searx() else "ddg"
            terms = None
            for q in queries:
                session.record_query(q)
                results, err = await webintel.get_results(q, engine=eng, limit=10)
                print(f"\nSearching for: {q}")
                if not results:
                    print(f"  ({err or 'no results'})")
                    continue
                for i, r in enumerate(results, 1):
                    print(f"\n  {i}. Title: {r.title}")
                    print(f"     Link: {r.url}")
                    if r.snippet:
                        print(f"     Snippet: {r.snippet}")
                    session.add(Finding("dork", r.url,
                                        f"{r.title} :: {r.snippet[:160]}",
                                        f"dork-result:{eng}", Severity.LOW,
                                        meta={"url": r.url, "query": q,
                                              "title": r.title,
                                              "snippet": r.snippet}))
        elif args.links:
            f = google_dork.dork_links(args.domain, dorks=cat,
                                       engine=args.engine, session=session)
            _print_findings(f, f"Dork links ({args.engine}) — {args.domain}")
        else:
            f = await google_dork.run_dorks(args.domain, dorks=cat, session=session)
            _print_findings(f, f"Google dorks — {args.domain}")
    elif cmd == "prompt":
        print(ai_osint.build_prompt(args.domain))
        return 0
    elif cmd == "takeover":
        if args.update:
            ok, msg = await takeover.update_fingerprints()
            print(msg)
            if not args.domain:
                return 0 if ok else 1
        # discover subdomains first so we have hosts to check
        await subdomains.brute_force(args.domain, session=session)
        await crtsh.crtsh_lookup(args.domain, session=session)
        findings = await takeover.check_all(session, do_http=args.http,
                                            on_stage=lambda m: None)
        flagged = [f for f in findings]
        _print_findings(flagged or [Finding("takeover", "info",
                        "no dangling / takeover conditions found", "takeover",
                        Severity.INFO)], f"Dangling DNS / takeover — {args.domain}")
    elif cmd == "wayback":
        findings = await wayback.harvest(
            args.domain, limit=args.limit, subdomains=not args.no_subdomains,
            session=session, on_stage=lambda m: None)
        _print_findings(findings, f"Wayback / archived URLs — {args.domain}")
    elif cmd == "github":
        if args.fetch:
            findings = await github_dork.run_dorks(
                args.domain, org=args.org or "", session=session,
                on_stage=lambda m: None)
        else:
            findings = github_dork.dork_links(
                args.domain, org=args.org or "", session=session)
        _print_findings(findings, f"GitHub dorks — {args.org or args.domain}")
    elif cmd == "favicon":
        findings = await favicon_mod.pivot(
            args.target, do_shodan=args.shodan, session=session,
            on_stage=lambda m: None)
        _print_findings(findings, f"Favicon hash — {args.target}")
    elif cmd == "harvest":
        # optionally pull in more sources first
        if args.deep:
            await subdomains.brute_force(args.domain, session=session)
            await crtsh.crtsh_lookup(args.domain, session=session)
            await email_scraper.scrape(args.domain, max_depth=1, session=session)
        names = [n.strip() for n in (args.names or "").split(",") if n.strip()]
        findings = await harvester.harvest(
            args.domain, session=session, do_pgp=not args.no_pgp,
            names=names or None, on_stage=lambda m: None)
        _print_findings(findings, f"People / email harvest — {args.domain}")
    elif cmd == "breach":
        if args.email:
            emails = [e.strip().lower() for e in args.email]
        else:
            if args.harvest:
                await harvester.harvest(args.domain, session=session,
                                        on_stage=lambda m: None)
            emails = hibp.emails_from_session(session)
        if not emails:
            print("no emails to check. Run `harvest`/`email` first, or pass "
                  "--email <addr>.")
            return 0
        findings = await hibp.check_emails(emails, session=session,
                                           on_stage=lambda m: None)
        _print_findings(findings, f"HIBP breach check — {args.domain or 'emails'}")
    elif cmd == "buckets":
        findings = await buckets.check_all(
            args.domain, org=args.org or "", do_azure=args.azure,
            cap=args.cap, session=session, on_stage=lambda m: None)
        _print_findings(findings, f"Cloud buckets — {args.domain}")
    elif cmd == "docmeta":
        if args.url:
            urls = list(args.url)
        else:
            # discover documents via dorks + wayback, then harvest
            await google_dork.run_dorks(args.domain, session=session) \
                if config.has_google() else None
            await wayback.harvest(args.domain, session=session,
                                  on_stage=lambda m: None)
            urls = docmeta.doc_urls_from_session(session)
        if not urls:
            print("no document URLs found (try `dork`/`wayback` first, or pass "
                  "--url <doc-url>).")
            return 0
        findings = await docmeta.harvest(urls, session=session,
                                         on_stage=lambda m: None)
        _print_findings(findings or [Finding("docmeta", "info",
                        "no metadata extracted", "docmeta", Severity.INFO)],
                        f"Document metadata — {args.domain or 'urls'}")
    elif cmd == "preview":
        results, err = await webintel.get_results(args.query, engine=args.engine)
        if err and not results:
            print(f"no results: {err}")
            return 0
        if _console:
            _console.print(f"[green]{len(results)} results[/] for: {args.query}")
        terms = webintel.terms_from_query(args.query)
        for i, r in enumerate(results[: args.limit], 1):
            print(f"\n[{i}] {r.title}\n    {r.url}")
            if args.pages:
                intel = await webintel.fetch_page(r.url, terms=terms)
                if intel.error:
                    print(f"    ! {intel.error}")
                    continue
                print(f"    HTTP {intel.status} · {intel.content_type} · "
                      f"{intel.size} bytes · {intel.title}")
                for h in intel.contexts[:6]:
                    snip = h["snippet"].replace("❱", "[").replace("❰", "]")
                    print(f"      · {h['term']}: {snip}")
                if args.summary and webintel.has_llm():
                    print("    summary:", webintel.summarise_llm(intel, args.query))
        return 0
    elif cmd == "auto":
        def stage(m):
            if _console:
                _console.print(f"[dim]· {m}[/]")
        session = await pipeline.auto_recon(
            args.domain, do_ports=args.ports, do_shodan=args.shodan,
            do_takeover=not args.light, do_wayback=not args.light,
            do_docmeta=not args.light, do_harvest=not args.light,
            on_stage=stage
        )
        if args.chain:
            plan = chaining.build_plan(session, cap=args.chain_cap)
            if plan["hosts"]:
                if _console:
                    _console.print(f"[dim]· chaining {len(plan['hosts'])} "
                                   f"subdomain(s) into links + spider[/]")
                await chaining.run_chain(session, plan, engine="google",
                                         do_links=True, do_spider=True,
                                         on_stage=stage)
        _print_findings(session.highlights() or session.findings,
                        f"Auto-recon — {args.domain}")
    else:
        return 2

    _maybe_report(session, args)
    return 0


def _cmd_rss(args) -> int:
    import asyncio
    from .engine import rss
    terms = [t.strip() for t in (args.highlight or "").split(",") if t.strip()]
    feeds = asyncio.run(rss.fetch_all(highlight_terms=terms))
    only = args.feed.lower() if args.feed else ""
    emailed = []
    for f in feeds:
        if only and only not in f.name.lower():
            continue
        head = f"\n=== {f.name} ===" + (f"  [{f.error}]" if f.error else "")
        print(head)
        for i, it in enumerate(f.items, 1):
            star = "*" if it.relevant else " "
            print(f" {star}{i:>2}. {it.title}")
            print(f"      {it.link}")
            if it.relevant:
                emailed.append(it.link)
    if args.email:
        subj = args.subject or "[CTI] EZRecon relevant items"
        links = emailed or [it.link for f in feeds for it in f.items]
        ok, msg = rss.send_email(subj, links, to_override=args.to or "")
        print(("\n[email] " if ok else "\n[email FAILED] ") + msg)
        return 0 if ok else 1
    return 0


def _cmd_nse(args) -> int:
    from .engine import nse
    action = getattr(args, "nse_action", None)
    if action == "updatedb":
        ok, msg = nse.updatedb()
        print(msg)
        return 0 if ok else 1
    if not nse.have_nmap():
        print("nmap not found. Install it (e.g. `sudo apt install nmap`) and retry.")
        return 1
    if action == "list":
        rows = nse.list_scripts(category=args.category, mainframe=args.mainframe)
        for r in rows:
            print(f"{r['name']:40s} {','.join(r['categories'])}")
        print(f"\n{len(rows)} scripts (nmap {nse.nmap_version()})")
        return 0
    if action == "args":
        for a in nse.script_args(args.script):
            print(f"{a['arg']:35s} {a['desc']}")
        return 0
    if action == "presets":
        for p in nse.load_presets():
            print(f"{p['id']:18s} {p['name']} — {p['description']}")
        return 0
    if action == "build":
        if args.preset:
            cmd = nse.command_from_preset(args.preset, args.target)
            if not cmd:
                print(f"unknown preset: {args.preset}")
                return 1
        else:
            sargs = {}
            for kv in (args.script_arg or []):
                k, _, v = kv.partition("=")
                sargs[k] = v
            cmd = nse.build_command(
                args.target,
                scripts=(args.script.split(",") if args.script else None),
                script_args=sargs or None, ports=args.ports or "",
                timing=(f"-T{args.timing}" if args.timing else ""),
                scan_type=args.scan_type or "", service_version=args.sv,
                no_ping=args.pn)
        print(cmd)
        return 0
    print("usage: ezrecon nse {list,args,presets,build,updatedb} …")
    return 1


def _cmd_searx(args) -> int:
    from . import searx_setup
    action = getattr(args, "searx_action", None) or "status"
    if action == "setup":
        print("Setting up SearXNG (keyless, self-hosted results) …")
        r = searx_setup.setup(port=args.port, assume_yes=args.yes,
                              on_log=lambda m: print(m))
        print(("\n[OK] " if r["ok"] else "\n[FAIL] ") + r["message"])
        return 0 if r["ok"] else 1
    if action == "stop":
        r = searx_setup.stop()
        print(r["message"])
        return 0 if r["ok"] else 1
    # status
    s = searx_setup.status()
    print(f"SearXNG URL:        {s['url']}")
    print(f"Container running:  {s['container_running']}")
    print(f"JSON API working:   {s['json_ok']}  ({s['detail']})")
    if not s["json_ok"]:
        print("Run `ezrecon searx setup` to (re)configure it.")
    return 0 if s["json_ok"] else 1


def _cmd_graph(args) -> int:
    from .engine.graph import build_graph
    from .report.graph_html import graph_to_html
    from .models import Session
    try:
        data = json.loads(Path(args.session).read_text())
    except Exception as e:  # noqa: BLE001
        print(f"could not read session json: {e}")
        return 1
    session = Session.from_dict(data)
    g = build_graph(session)
    out = Path(args.out) if args.out else Path(
        f"ezrecon_{session.target.replace('.', '_')}_graph.html")
    out.write_text(graph_to_html(g, session))
    print(f"graph written: {out}  ({len(g.nodes)} nodes, {len(g.edges)} edges)")
    return 0


def _cmd_config(args) -> int:
    if args.config_action == "set":
        config.set_key(args.name, args.value)
        print(f"Saved {args.name} to {config.config_path()}")
    elif args.config_action == "set-setting":
        config.set_setting(args.name, args.value)
        print(f"Set {args.name} = {args.value}")
    elif args.config_action == "test":
        import asyncio
        from .engine import google_dork
        verdict = asyncio.run(google_dork.check_credentials())
        mark = "OK  " if verdict["ok"] else "FAIL"
        print(f"[{mark}] Google Custom Search")
        print(verdict["message"])
        return 0 if verdict["ok"] else 1
    elif args.config_action == "show":
        cfg = config.load_config()
        print(f"Config: {config.config_path()}")
        for k, v in cfg["keys"].items():
            masked = (v[:4] + "…") if v else "(unset)"
            print(f"  {k}: {masked}")
        print("Settings:")
        for k, v in cfg["settings"].items():
            print(f"  {k}: {v}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="ezrecon",
        description="EZRecon — passive reconnaissance for the mainframe hunter.",
    )
    p.add_argument("--version", action="version", version=f"EZRecon {__version__}")
    sub = p.add_subparsers(dest="command")

    def add_report(sp):
        sp.add_argument("--report", metavar="DIR",
                        help="write md/html/json/queries.txt to DIR")

    sp = sub.add_parser("tui", help="launch the Textual interface")

    sp = sub.add_parser("dns", help="DNS records + zone transfer")
    sp.add_argument("domain"); add_report(sp)

    sp = sub.add_parser("whois", help="WHOIS lookup")
    sp.add_argument("domain"); add_report(sp)

    sp = sub.add_parser("subdomains", help="concurrent subdomain brute force")
    sp.add_argument("domain"); sp.add_argument("--wordlist"); add_report(sp)

    sp = sub.add_parser("crtsh", help="certificate-transparency subdomains")
    sp.add_argument("domain"); add_report(sp)

    sp = sub.add_parser("asn", help="ASN / netblock enrichment (Team Cymru, pure DNS)")
    sp.add_argument("target", help="domain or IPv4 address"); add_report(sp)

    sp = sub.add_parser("email", help="email spider")
    sp.add_argument("url"); sp.add_argument("--depth", type=int, default=2); add_report(sp)

    sp = sub.add_parser("ports", help="native (non-nmap) banner grab")
    sp.add_argument("target"); sp.add_argument("--ports", help="comma list, e.g. 21,23,50000")
    add_report(sp)

    sp = sub.add_parser("shodan", help="Shodan search / mainframe sweep")
    sp.add_argument("query", nargs="?", default="")
    sp.add_argument("--mainframe", action="store_true", help="run the z/OS query library")
    add_report(sp)

    sp = sub.add_parser("dork", help="Google dorks: fetch via API, or --links for no-key browser URLs")
    sp.add_argument("domain")
    sp.add_argument("--all", action="store_true",
                    help="enable every dork in the catalogue")
    sp.add_argument("--links", action="store_true",
                    help="no key needed: output clickable search URLs instead of fetching")
    sp.add_argument("--fetch", action="store_true",
                    help="no key needed: fetch real Title/Link/Snippet results (via DuckDuckGo)")
    sp.add_argument("--engine", default="google",
                    choices=["google", "bing", "duckduckgo", "startpage"],
                    help="search engine for --links (default: google)")
    add_report(sp)

    sp = sub.add_parser("prompt", help="print an AI deep-research OSINT prompt")
    sp.add_argument("domain")

    sp = sub.add_parser("takeover",
                        help="dangling DNS / subdomain-takeover detection")
    sp.add_argument("domain", nargs="?", help="target domain (omit with --update)")
    sp.add_argument("--update", action="store_true",
                    help="refresh provider fingerprints from can-i-take-over-xyz")
    sp.add_argument("--http", action="store_true",
                    help="actively fetch candidates to confirm (active recon)")

    sp = sub.add_parser("wayback",
                        help="harvest archived URLs from the Wayback Machine (CDX)")
    sp.add_argument("domain")
    sp.add_argument("--limit", type=int, default=5000)
    sp.add_argument("--no-subdomains", action="store_true",
                    help="apex only (don't include *.domain)")

    sp = sub.add_parser("github",
                        help="GitHub code-search dorks (links, or --fetch with a token)")
    sp.add_argument("domain")
    sp.add_argument("--org", help="scope to a GitHub org (org:...)")
    sp.add_argument("--fetch", action="store_true",
                    help="run via the code-search API (needs github_token)")

    sp = sub.add_parser("favicon",
                        help="hash a favicon and pivot to co-located hosts (Shodan)")
    sp.add_argument("target", help="host or full favicon URL")
    sp.add_argument("--shodan", action="store_true",
                    help="pivot on Shodan for hosts sharing the hash (needs key)")

    sp = sub.add_parser("docmeta",
                        help="harvest metadata (authors/software) from public documents")
    sp.add_argument("domain", nargs="?", help="discover docs via dorks+wayback for this domain")
    sp.add_argument("--url", action="append", help="specific document URL(s) to inspect")

    sp = sub.add_parser("harvest",
                        help="aggregate people/emails from all sources + PGP + infer naming")
    sp.add_argument("domain")
    sp.add_argument("--deep", action="store_true",
                    help="first run subdomains + crt.sh + email spider to feed the harvest")
    sp.add_argument("--no-pgp", action="store_true", help="skip the PGP keyserver lookup")
    sp.add_argument("--names", help="comma-separated 'First Last' names to expand into addresses")

    sp = sub.add_parser("breach",
                        help="check discovered emails against Have I Been Pwned (needs hibp_api_key)")
    sp.add_argument("domain", nargs="?", help="check emails already found for this domain")
    sp.add_argument("--email", action="append", help="specific email(s) to check")
    sp.add_argument("--harvest", action="store_true",
                    help="run the people harvest first to gather emails")

    sp = sub.add_parser("buckets",
                        help="discover S3/GCS/Azure buckets from the target name")
    sp.add_argument("domain")
    sp.add_argument("--org", help="also derive names from this org name")
    sp.add_argument("--azure", action="store_true", help="also probe Azure Blob")
    sp.add_argument("--cap", type=int, default=300, help="max candidates")

    sp = sub.add_parser("preview",
                        help="resolve a dork to real results and (optionally) analyse pages [active]")
    sp.add_argument("query", help="a search/dork query, e.g. 'site:x.com filetype:JCL'")
    sp.add_argument("--engine", default="auto",
                    choices=["auto", "ddg", "api"],
                    help="result source (default: auto = API if keyed, else DDG)")
    sp.add_argument("--limit", type=int, default=10, help="max results to show")
    sp.add_argument("--pages", action="store_true",
                    help="fetch each result page and show terms in context (active)")
    sp.add_argument("--summary", action="store_true",
                    help="add an LLM summary per page (needs an Anthropic key)")

    sp = sub.add_parser("auto", help="one-shot passive sweep + optional report")
    sp.add_argument("domain")
    sp.add_argument("--ports", action="store_true", help="include native banner grab")
    sp.add_argument("--shodan", action="store_true", help="include Shodan mainframe sweep")
    sp.add_argument("--light", action="store_true",
                    help="core sweep only (skip takeover/wayback/docmeta/harvest)")
    sp.add_argument("--chain", action="store_true",
                    help="chain discovered subdomains into dork links + spider seeds")
    sp.add_argument("--chain-cap", type=int, default=10,
                    help="max subdomains to chain (default 10)")
    add_report(sp)

    cp = sub.add_parser("config", help="manage API keys / settings")
    csub = cp.add_subparsers(dest="config_action")
    s = csub.add_parser("set"); s.add_argument("name"); s.add_argument("value")
    s = csub.add_parser("set-setting"); s.add_argument("name"); s.add_argument("value")
    csub.add_parser("show")
    csub.add_parser("test", help="validate the Google API key + cx with one test query")

    sp = sub.add_parser("graph",
                        help="build an interactive HTML entity graph from a session json")
    sp.add_argument("session", help="path to an ezrecon *.json session file")
    sp.add_argument("--out", help="output HTML path")

    sp = sub.add_parser("searx",
                        help="set up / manage a self-hosted SearXNG for keyless results")
    ssub = sp.add_subparsers(dest="searx_action")
    setup_p = ssub.add_parser("setup", help="one command: run SearXNG (JSON enabled) and point EZRecon at it")
    setup_p.add_argument("--port", type=int, default=8080)
    setup_p.add_argument("--yes", "-y", action="store_true",
                         help="don't prompt — install Docker automatically if missing")
    ssub.add_parser("status", help="check whether SearXNG is running and the JSON API works")
    ssub.add_parser("stop", help="stop the SearXNG container")

    sp = sub.add_parser("rss", help="CTI security RSS reader (list latest items, optional email)")
    sp.add_argument("--feed", help="only show feeds whose name contains this")
    sp.add_argument("--highlight", help="comma-separated terms to star (e.g. mainframe,RACF)")
    sp.add_argument("--email", action="store_true", help="email the items (needs SMTP config)")
    sp.add_argument("--to", help="recipient override")
    sp.add_argument("--subject", help="email subject")

    sp = sub.add_parser("nse", help="build nmap/NSE commands (mainframe scripts, per-script args)")
    nsub = sp.add_subparsers(dest="nse_action")
    lp = nsub.add_parser("list", help="list installed NSE scripts")
    lp.add_argument("--category", help="filter by category (e.g. vuln, safe, discovery)")
    lp.add_argument("--mainframe", action="store_true", help="only mainframe-relevant scripts")
    ap = nsub.add_parser("args", help="show a script's documented --script-args")
    ap.add_argument("script")
    nsub.add_parser("presets", help="list the book NSE presets")
    nsub.add_parser("updatedb", help="rebuild script.db (nmap --script-updatedb)")
    bp = nsub.add_parser("build", help="build an nmap command")
    bp.add_argument("target")
    bp.add_argument("--preset", help="use a book preset (see `nse presets`)")
    bp.add_argument("--script", help="comma-separated script names")
    bp.add_argument("--script-arg", action="append", help="key=value (repeatable)")
    bp.add_argument("--ports")
    bp.add_argument("--timing", type=int, help="0-5")
    bp.add_argument("--scan-type", help="e.g. -sT, -sS")
    bp.add_argument("--sv", action="store_true", help="add -sV")
    bp.add_argument("--pn", action="store_true", help="add -Pn")

    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command is None or args.command == "tui":
        from .tui.app import run as run_tui
        run_tui()
        return 0
    if args.command == "config":
        return _cmd_config(args)
    if args.command == "graph":
        return _cmd_graph(args)
    if args.command == "searx":
        return _cmd_searx(args)
    if args.command == "nse":
        return _cmd_nse(args)
    if args.command == "rss":
        return _cmd_rss(args)
    return asyncio.run(_run(args))


if __name__ == "__main__":
    sys.exit(main())
