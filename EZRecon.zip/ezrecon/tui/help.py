"""Help content for the in-app help facility (Help / Labs on the sidebar, F1).

Each topic has a title and a body in Rich markup. Bodies follow the same shape:
what it is, how to use it, and a short hands-on lab against a domain you own
(sighberbank.com is the training target). Written to be read at the keyboard.
"""

from __future__ import annotations

# ordered: overview first, then the workflow, then tools, then config
HELP_ORDER = [
    "overview", "auto", "dns", "whois", "subdomains", "crtsh", "email",
    "ports", "shodan", "dork", "takeover", "wayback", "github", "docmeta",
    "harvest", "breach", "buckets", "prompt", "graph", "mymap", "rss",
    "keys", "options",
]

HELP: dict[str, dict[str, str]] = {
    "overview": {"title": "Overview & labs", "body": (
        "[#ffb000]What eZrecon is[/]\n"
        "A passive-recon and OSINT tool for the mainframe hunter. It turns a "
        "single domain into a picture of the estate, the people and the "
        "exposures around it, mostly without touching the target. MyMap adds an "
        "active nmap runner when you need it.\n\n"
        "[#ffb000]How to move around[/]\n"
        "Pick a module on the left, type a target up top, press Run (r). Auto (a) "
        "runs the whole passive chain in one go. The keys along the bottom are "
        "the fast paths: g graph, n MyMap, s CTI RSS, o options, k keys, F1 help.\n\n"
        "[#ffb000]Passive vs active[/]\n"
        "Most of eZrecon is passive: the target sees nothing. A few features are "
        "active (port scans, bucket probing, takeover confirmation, MyMap scans) "
        "and are gated behind a confirm. Only run those against targets you are "
        "authorised to test.\n\n"
        "[#ffb000]Lab 0 — first sweep[/]\n"
        "1. Type [b]sighberbank.com[/] in the target box.\n"
        "2. Press [b]a[/] to run Auto-Recon and watch the log fill.\n"
        "3. Press [b]g[/] to open the graph and see how the findings connect.\n"
        "4. Press [b]F1[/] on any module for its own help and lab.")},

    "auto": {"title": "Auto-Recon", "body": (
        "[#ffb000]What it is[/]\n"
        "One command that runs the sensible passive chain: whois, DNS, crt.sh, "
        "the subdomain brute and the email spider together, then ASN enrichment, "
        "then the passive OSINT chain (DNS-only takeover, Wayback, document "
        "metadata, people harvest). Everything lands in one session, table, graph "
        "and report.\n\n"
        "[#ffb000]How to use it[/]\n"
        "Type a target and press [b]a[/]. It stays passive and keyless; active "
        "and keyed features are never fired automatically. On the CLI, "
        "[b]ezrecon auto <domain>[/], with [b]--light[/] for the core map only, "
        "[b]--ports[/] to add banners, [b]--shodan[/] to add Shodan.\n\n"
        "[#ffb000]Lab[/]\n"
        "1. Run Auto against [b]sighberbank.com[/].\n"
        "2. Read the reds first in the results table — those are the leads.\n"
        "3. Open the graph (g) and pivot from a high-value node.")},

    "dns": {"title": "DNS records", "body": (
        "[#ffb000]What it is[/]\n"
        "Resolves the standard record types (A, AAAA, MX, NS, TXT, SOA, CNAME) "
        "and tries a zone transfer against each nameserver.\n\n"
        "[#ffb000]How to use it[/]\n"
        "Select DNS Records, enter the domain, Run. On the CLI: "
        "[b]ezrecon dns <domain>[/].\n\n"
        "[#ffb000]Why[/]\n"
        "MX shows the mail provider, TXT leaks SPF/DKIM third parties, and a "
        "nameserver that allows a zone transfer hands you the whole map at once.\n\n"
        "[#ffb000]Lab[/]\n"
        "Run DNS on [b]sighberbank.com[/] and note the MX and any TXT entries "
        "that name middleware or gateways in front of z/OS.")},

    "whois": {"title": "WHOIS", "body": (
        "[#ffb000]What it is[/]\n"
        "Pulls the domain registration record: registrar, dates, and the "
        "registrant org and contacts where they are not redacted.\n\n"
        "[#ffb000]How to use it[/]\n"
        "Select WHOIS, enter the domain, Run. CLI: [b]ezrecon whois <domain>[/].\n\n"
        "[#ffb000]Lab[/]\n"
        "Run WHOIS on your target; treat a redacted record as normal — the "
        "registrar, creation date and nameservers still confirm ownership.")},

    "subdomains": {"title": "Subdomains", "body": (
        "[#ffb000]What it is[/]\n"
        "Brute-forces subdomains from a wordlist tuned with mainframe names, "
        "resolving each and keeping the ones that answer.\n\n"
        "[#ffb000]How to use it[/]\n"
        "Select Subdomains, Run. Point it at a bigger wordlist in Options (o) "
        "when you want depth. CLI: [b]ezrecon subdomains <domain>[/].\n\n"
        "[#ffb000]Lab[/]\n"
        "Brute [b]sighberbank.com[/], then feed a gateway-looking host into MyMap "
        "(n) for a port scan once you have authorisation.")},

    "crtsh": {"title": "crt.sh (certificate transparency)", "body": (
        "[#ffb000]What it is[/]\n"
        "Reads certificate transparency logs for every hostname ever issued a "
        "certificate under the domain — the richest passive source of subdomains.\n\n"
        "[#ffb000]How to use it[/]\n"
        "Select crt.sh, Run. CLI: [b]ezrecon crtsh <domain>[/]. It costs the "
        "target nothing because you read a public log.\n\n"
        "[#ffb000]Lab[/]\n"
        "Run crt.sh and compare its hosts with the brute-force results — CT often "
        "finds internal-looking names nobody would guess.")},

    "email": {"title": "Email spider", "body": (
        "[#ffb000]What it is[/]\n"
        "Crawls the target's own site to a shallow depth and scrapes the email "
        "addresses it finds — the most reliable source of real addresses.\n\n"
        "[#ffb000]How to use it[/]\n"
        "Runs inside Auto and the harvest chain. CLI: [b]ezrecon email <domain>[/].\n\n"
        "[#ffb000]Lab[/]\n"
        "After an Auto run, look at the emails found — they seed the naming "
        "convention and the breach checks.")},

    "ports": {"title": "Ports (active)", "body": (
        "[#ffb000]What it is[/]\n"
        "Connects to a mainframe-relevant port profile and grabs banners "
        "(TN3270 on 23/992, DRDA/DB2 on 446/50000, common web and admin ports).\n\n"
        "[#ffb000]How to use it[/]\n"
        "This connects to the target, so it is active and gated. Enable active "
        "recon, then Run. CLI: [b]ezrecon ports <host>[/].\n\n"
        "[#ffb000]Lab[/]\n"
        "Against a host you own, confirm whether TN3270 or DRDA is listening — "
        "that is where passive mapping becomes a concrete attack surface.")},

    "shodan": {"title": "Shodan sweep (needs key)", "body": (
        "[#ffb000]What it is[/]\n"
        "A mainframe-flavoured Shodan search that returns exposed hosts and "
        "banners from Shodan's existing scans, without you sending a packet.\n\n"
        "[#ffb000]How to use it[/]\n"
        "Add a Shodan key (k), select Shodan, Run. CLI: [b]ezrecon shodan <domain>[/].\n\n"
        "[#ffb000]Lab[/]\n"
        "With a key set, sweep your target and note any midrange or mainframe "
        "fingerprints Shodan already holds.")},

    "dork": {"title": "Google dorks", "body": (
        "[#ffb000]What it is[/]\n"
        "Builds and (with a key or SearXNG) runs a catalogue of mainframe-focused "
        "dorks: exposed listings, config and log files, error pages, JCL and "
        "COBOL filetypes.\n\n"
        "[#ffb000]How to use it[/]\n"
        "Select Google Dork, Run for links, or Fetch with a Google key / SearXNG. "
        "Stand up SearXNG keyless with [b]ezrecon searx setup[/].\n\n"
        "[#ffb000]Lab[/]\n"
        "Run the dorks against [b]sighberbank.com[/]; open a promising query and "
        "look for a directory listing or a JCL file on a web root.")},

    "takeover": {"title": "Dangling DNS / takeover", "body": (
        "[#ffb000]What it is[/]\n"
        "Checks discovered subdomains for a CNAME pointing at a decommissioned "
        "cloud service you could re-register and take over.\n\n"
        "[#ffb000]How to use it[/]\n"
        "The DNS check is passive. [b]--http[/] confirmation is active and gated. "
        "[b]ezrecon takeover <domain>[/]; [b]--update[/] refreshes fingerprints.\n\n"
        "[#ffb000]Lab[/]\n"
        "Run takeover after subdomain discovery; a HIGH result is a hostname an "
        "attacker could serve content from as the organisation.")},

    "wayback": {"title": "Wayback URLs", "body": (
        "[#ffb000]What it is[/]\n"
        "Pulls every URL ever archived under the domain from the Internet Archive "
        "and flags config/secret files, backups, exposed VCS, and mainframe "
        "artefacts like JCL and COBOL.\n\n"
        "[#ffb000]How to use it[/]\n"
        "Keyless and invisible to the target. CLI: [b]ezrecon wayback <domain>[/].\n\n"
        "[#ffb000]Lab[/]\n"
        "Harvest the archive for your target and look for a deleted file that is "
        "still captured — active scanning cannot see it, the archive can.")},

    "github": {"title": "GitHub dorking", "body": (
        "[#ffb000]What it is[/]\n"
        "Builds GitHub code-search queries scoped to the target (JCL, COBOL, "
        "connection strings, .env and key files) as links, or runs them with a "
        "token.\n\n"
        "[#ffb000]How to use it[/]\n"
        "Link mode is keyless. [b]ezrecon github <domain> --org <org> --fetch[/] "
        "needs a github token (k).\n\n"
        "[#ffb000]Lab[/]\n"
        "Scope a search to your org name and look for a leaked copybook or "
        "connection string.")},

    "docmeta": {"title": "Document metadata", "body": (
        "[#ffb000]What it is[/]\n"
        "Fetches public PDFs and Office documents and extracts their metadata: "
        "author and last-modified-by usernames, software versions, company fields.\n\n"
        "[#ffb000]How to use it[/]\n"
        "Reads documents that dork and Wayback surfaced, or point it at a URL. "
        "CLI: [b]ezrecon docmeta <domain>[/] or [b]--url <doc>[/].\n\n"
        "[#ffb000]Lab[/]\n"
        "Pull metadata from a runbook PDF; the author username is a candidate TSO "
        "or RACF userid.")},

    "harvest": {"title": "People harvest", "body": (
        "[#ffb000]What it is[/]\n"
        "Consolidates every email and name found, dedupes them with their source, "
        "adds a keyless PGP keyserver lookup, infers the naming convention, and "
        "generates likely addresses for names it has not confirmed.\n\n"
        "[#ffb000]How to use it[/]\n"
        "[b]ezrecon harvest <domain> --deep[/] runs discovery first to feed it.\n\n"
        "[#ffb000]Lab[/]\n"
        "Harvest your target; a handful of known addresses plus a few names gives "
        "you a userid list via the inferred pattern.")},

    "breach": {"title": "Breach check (needs key)", "body": (
        "[#ffb000]What it is[/]\n"
        "Checks discovered emails against Have I Been Pwned and reports which "
        "appear in breaches and what was exposed.\n\n"
        "[#ffb000]How to use it[/]\n"
        "Add an HIBP key (k). CLI: [b]ezrecon breach <domain>[/] or [b]--email[/].\n\n"
        "[#ffb000]Lab[/]\n"
        "Check a harvested address; an account in a password-leaking breach is a "
        "direct lead for a pretext or credential test.")},

    "buckets": {"title": "Cloud buckets (active)", "body": (
        "[#ffb000]What it is[/]\n"
        "Generates candidate bucket names from the target plus environment "
        "suffixes and checks them against S3, GCS and optionally Azure.\n\n"
        "[#ffb000]How to use it[/]\n"
        "Probing the providers is active and gated. [b]ezrecon buckets <domain> "
        "--org <org> --azure[/].\n\n"
        "[#ffb000]Lab[/]\n"
        "Against infrastructure you own, look for a backups or db-dumps bucket; a "
        "public one is an immediate data leak.")},

    "prompt": {"title": "AI OSINT prompt", "body": (
        "[#ffb000]What it is[/]\n"
        "Assembles a structured intelligence prompt from the current session, "
        "ready to paste into an assistant for a summary or next steps.\n\n"
        "[#ffb000]How to use it[/]\n"
        "Select AI Prompt, Run. CLI: [b]ezrecon prompt <domain>[/].\n\n"
        "[#ffb000]Lab[/]\n"
        "After a busy Auto run, build the prompt and get a fast second read on "
        "what matters.")},

    "graph": {"title": "Entity graph", "body": (
        "[#ffb000]What it is[/]\n"
        "Everything in the session as a graph: domains, subdomains, IPs, emails, "
        "people, documents, buckets, breaches, joined by typed edges. Findings in "
        "a table are a list; in a graph they are a map.\n\n"
        "[#ffb000]How to use it[/]\n"
        "Press [b]g[/]. Select a node to see detail and pivot to the next step.\n\n"
        "[#ffb000]Lab[/]\n"
        "Open the graph after an Auto run, find a document author, and pivot to a "
        "harvest to turn the name into an address.")},

    "mymap": {"title": "MyMap — nmap script runner", "body": (
        "[#ffb000]What it is[/]\n"
        "A menu-driven nmap runner (a port of Kev's MyMap). Browse NSE scripts by "
        "category — including the MAINFRAME, SSL, SMB and other sub-menus — or "
        "search by keyword. Selecting a script shows its description and its "
        "documented [b]--script-args[/], and builds the command.\n\n"
        "[#ffb000]How to use it[/]\n"
        "Press [b]n[/]. Pick a category (left), a script (middle); the "
        "description and args appear on the right. Fill the target, ports and any "
        "script-args. The [b]$ nmap …[/] line is editable — add ports or switches "
        "there directly. Press Run to scan (this is active, so it asks you to "
        "confirm once). Copy sends the command to the main log to run yourself. "
        "Save dial stores the flags for reuse; Report writes a short summary of "
        "the last output.\n\n"
        "[#ffb000]Tip[/]\n"
        "Put extra switches in the [b]extra flags[/] box or edit the command line "
        "directly — do not put them in the target box, or they become part of the "
        "hostname.\n\n"
        "[#ffb000]Lab[/]\n"
        "1. Open MyMap (n), pick [b]MAINFRAME[/], then [b]tso-enum[/].\n"
        "2. Read the description on the right, and its script-args.\n"
        "3. Set the target and edit the [b]$ nmap[/] line to add [b]-p 23[/].\n"
        "4. Press Run twice to confirm and scan; then press Report.")},

    "rss": {"title": "CTI RSS reader", "body": (
        "[#ffb000]What it is[/]\n"
        "A security-news reader over a set of feeds (Krebs, BleepingComputer, "
        "Planet Mainframe and more) that stars items mentioning your target or "
        "mainframe keywords, and can email a selection.\n\n"
        "[#ffb000]How to use it[/]\n"
        "Press [b]s[/]. Add your own feeds with the name/URL box, or on the CLI "
        "with [b]ezrecon rss --add-feed \"Name\" <url>[/]. Email needs SMTP set in "
        "Options.\n\n"
        "[#ffb000]Lab[/]\n"
        "Add a feed you follow, then refresh and see whether anything tied to "
        "your target is in the news this week.")},

    "keys": {"title": "API keys", "body": (
        "[#ffb000]What it is[/]\n"
        "The vault for secret keys: Google, Shodan, HIBP, GitHub, SMTP. Entered "
        "once, masked, never pasted into a command.\n\n"
        "[#ffb000]How to use it[/]\n"
        "Press [b]k[/] to open the vault; or [b]ezrecon config set <key> <value>[/].\n\n"
        "[#ffb000]Lab[/]\n"
        "Add a Shodan key, then run the Shodan sweep to see keyed results light "
        "up.")},

    "options": {"title": "Options & appearance", "body": (
        "[#ffb000]What it is[/]\n"
        "Runtime settings: wordlist, concurrency, timeouts, chaining, and the "
        "colour theme.\n\n"
        "[#ffb000]How to use it[/]\n"
        "Press [b]o[/]. The Appearance section at the top switches theme "
        "(Phosphor, Amber, Light, Mono) live. CLI: "
        "[b]ezrecon config set-setting <name> <value>[/].\n\n"
        "[#ffb000]Lab[/]\n"
        "Switch to Light for a bright room, then back to Phosphor; note that "
        "high-severity findings stay red in every theme.")},
}

# map a focused widget id (or prefix) to the help topic it belongs to,
# so F1 is contextual to where the cursor actually is
FOCUS_TO_TOPIC = {
    "mymap-target": "mymap", "mymap-port": "mymap", "mymap-extra": "mymap",
    "mymap-cmd": "mymap", "mymap-scripts": "mymap", "mymap-cats": "mymap",
    "mymap-search": "mymap", "mymap-scriptargs": "mymap", "mymap-dialname": "mymap",
    "rss-add-name": "rss", "rss-add-url": "rss", "rss-items": "rss",
    "target": "overview",
}

# a one-line pointer shown at the top of the help when opened via F1 on a
# particular widget, so the help speaks to where the cursor was
FOCUS_HINT = {
    "mymap-cmd": "You're on the command line — it's editable; add ports or "
                 "switches here directly.",
    "mymap-scripts": "You're on the script list — Enter selects; the "
                     "description and args show on the right.",
    "mymap-scriptargs": "You're on script-args — enter arg=value pairs, "
                        "comma-separated.",
    "mymap-target": "You're on the target — put switches in extra flags or the "
                    "command line, not here.",
    "mymap-extra": "You're on extra flags — these are added to every command.",
    "mymap-cats": "You're on categories — pick one to list its scripts; "
                  "★ Speed Dial holds your saved commands.",
}


def topic_for_focus(focus_id: str) -> tuple[str, str]:
    """Return (topic_id, hint) for a focused widget id."""
    topic = FOCUS_TO_TOPIC.get(focus_id or "", "")
    hint = FOCUS_HINT.get(focus_id or "", "")
    return topic, hint
