"""Colour themes for the EZRecon TUI.

Each theme drives the CSS variables the stylesheet references ($background,
$foreground, $primary, $secondary, $accent, $panel, $surface, plus the semantic
$text-error/$text-warning/$text-success used for finding severities). Switching
theme recolours the whole interface.
"""

from __future__ import annotations

from textual.theme import Theme

THEMES = {
    # the original CRT green (default)
    "phosphor": Theme(
        name="phosphor", dark=True,
        background="#060a06", foreground="#33ff66",
        primary="#1f8a3a", secondary="#b6ffce", accent="#ffb000",
        surface="#04120a", panel="#08100a",
        success="#33ff66", warning="#ffb000", error="#ff5555",
    ),
    # amber CRT
    "amber": Theme(
        name="amber", dark=True,
        background="#0a0800", foreground="#ffb000",
        primary="#8a5a00", secondary="#ffd479", accent="#33ff66",
        surface="#140f00", panel="#1a1200",
        success="#c8ff4d", warning="#ffcf4d", error="#ff6b4d",
    ),
    # black text on white (light mode)
    "light": Theme(
        name="light", dark=False,
        background="#ffffff", foreground="#141414",
        primary="#2f7d4f", secondary="#0a4d22", accent="#b25000",
        surface="#f2f2f2", panel="#e9e9e9",
        success="#0b6b2f", warning="#9a5b00", error="#c0271e",
    ),
    # high-contrast monochrome, white on black
    "mono": Theme(
        name="mono", dark=True,
        background="#000000", foreground="#e6e6e6",
        primary="#6a6a6a", secondary="#ffffff", accent="#bdbdbd",
        surface="#141414", panel="#0d0d0d",
        success="#e6e6e6", warning="#cccccc", error="#ff6b6b",
    ),
}

DEFAULT = "phosphor"
ORDER = ["phosphor", "amber", "light", "mono"]
LABELS = {
    "phosphor": "Phosphor green (default)",
    "amber": "Amber CRT",
    "light": "Light — black on white",
    "mono": "Mono — white on black",
}
