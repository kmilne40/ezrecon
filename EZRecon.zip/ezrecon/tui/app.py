"""EZRecon Textual application.

A phosphor-themed TUI: pick a module from the sidebar, type a target, and
results stream into the findings table. Google Dork opens the Listing 6-1
multi-select. Auto-Recon runs the whole passive chain. Reports export to disk.
"""

from __future__ import annotations

import time
from pathlib import Path

from rich.text import Text
from textual import on
from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import (
    Button,
    Checkbox,
    DataTable,
    Footer,
    Header,
    Input,
    Label,
    RichLog,
    Static,
    TextArea,
)


class TickBox(Checkbox):
    """A checkbox that shows a tick (✓) when on instead of an X."""

    BUTTON_INNER = "✓"

from .. import __version__, config
from ..engine import (
    ai_osint,
    buckets,
    chaining,
    crtsh,
    dns_recon,
    docmeta,
    email_scraper,
    fofa,
    github_dork,
    google_dork,
    graph as graphmod,
    harvester,
    hibp,
    passive_subs,
    pipeline,
    pivots as pivotmod,
    ports,
    shodan_recon,
    subdomains,
    takeover,
    wayback,
    webintel,
    whois_recon,
)
from ..models import Finding, Session, Severity
from ..options import Options
from ..report import reporter
from ..report import exporters
from pathlib import Path as _Path

BANNER = r"""
     ____                     eZrecon: Passive and
 ___|_  /_ _ ___ __ ___ _ _   Active Recon
/ -_)/ /| '_/ -_) _/ _ \ ' \  for the mainframe hunter
\___/___|_| \___\__\___/_||_| {v}
""".strip("\n")

SEV_COLOUR = {"high": "red", "medium": "#ffb000", "low": "#33ff66", "info": "#1f8a3a"}

MODULES = [
    ("auto", "Auto-Recon"),
    ("dns", "DNS Records"),
    ("whois", "WHOIS"),
    ("subdomains", "Subdomains"),
    ("crtsh", "crt.sh (CT)"),
    ("email", "Email Spider"),
    ("ports", "Banner Grab"),
    ("shodan", "Shodan Sweep"),
    ("fofa", "FOFA Search"),
    ("dork", "Google Dork"),
    ("takeover", "Dangling DNS"),
    ("wayback", "Wayback URLs"),
    ("github", "GitHub Dorks"),
    ("docmeta", "Doc Metadata"),
    ("harvest", "People Harvest"),
    ("breach", "Breach Check"),
    ("buckets", "Cloud Buckets"),
    ("prompt", "AI Prompt"),
]


class DorkScreen(ModalScreen):
    """The Listing 6-1 multi-select for Google dorks."""

    def __init__(self, domain: str):
        super().__init__()
        self.domain = domain
        self.dorks = google_dork.load_catalogue()

    def compose(self) -> ComposeResult:
        with Vertical(id="modal"):
            yield Static(f"Google Dork selection — site:{self.domain}",
                         classes="modal-title")
            yield Static("[dim]Tick the queries to use and edit any of them. "
                         "'Open as links' needs no API key — it builds clickable "
                         "search URLs. 'Run via API' fetches results (needs a key).[/]")
            with VerticalScroll(id="dork-list"):
                for d in self.dorks:
                    built = google_dork.build_query(d, self.domain)
                    with Horizontal(classes="dork-row"):
                        yield TickBox(value=(d.enabled or d.id == 1),
                                      id=f"dchk-{d.id}")
                        yield Input(value=built, id=f"dq-{d.id}")
            with Horizontal(classes="modal-buttons"):
                yield Button("Cancel", id="dork-cancel")
                yield Button("Open as links", id="dork-links")
                yield Button("Fetch results (no key)", id="dork-fetch",
                             classes="primary")
                yield Button("Via API", id="dork-run")

    def _collect(self) -> list[str]:
        out: list[str] = []
        for d in self.dorks:
            if self.query_one(f"#dchk-{d.id}", TickBox).value:
                val = self.query_one(f"#dq-{d.id}", Input).value.strip()
                if val:
                    out.append(val)
        seen: list[str] = []
        for q in out:
            if q not in seen:
                seen.append(q)
        return seen

    @on(Button.Pressed, "#dork-cancel")
    def _cancel(self):
        self.dismiss(None)

    @on(Button.Pressed, "#dork-links")
    def _links(self):
        self.dismiss({"mode": "links", "queries": self._collect()})

    @on(Button.Pressed, "#dork-fetch")
    def _fetch(self):
        self.dismiss({"mode": "fetch", "queries": self._collect()})

    @on(Button.Pressed, "#dork-run")
    def _run(self):
        self.dismiss({"mode": "api", "queries": self._collect()})


class DorkResultsScreen(ModalScreen):
    """Keyless dork results rendered as a Title / Link / Snippet list."""

    BINDINGS = [
        ("escape", "close", "Close"),
        ("o", "open", "Open selected"),
    ]

    def __init__(self, queries: list[str], engine: str, session, limit: int = 10):
        super().__init__()
        self.queries = queries
        self.engine = engine
        self.session = session
        self.limit = limit
        self._urls: list[str] = []

    def compose(self) -> ComposeResult:
        with Vertical(id="modal-wide"):
            yield Static("Google dork results", classes="modal-title")
            src = {"ddg": "DuckDuckGo (no key)",
                   "searx": "SearXNG (self-hosted, no key)",
                   "api": "Google API"}.get(self.engine, self.engine)
            yield Static(f"[dim]source: {src} · [b]o[/b] open a link's host · "
                         "[b]Esc[/b] close[/]")
            with VerticalScroll(id="dork-results"):
                yield Static("Fetching results…", id="dork-results-body")
            with Horizontal(classes="modal-buttons"):
                yield Button("Close", id="dork-results-close")

    def on_mount(self):
        self.run_worker(self._fetch_all(), exclusive=True)

    async def _fetch_all(self):
        import asyncio
        body = self.query_one("#dork-results-body", Static)
        blocks: list[str] = []
        hits = 0
        blocked = 0
        for i, q in enumerate(self.queries):
            self.session.record_query(q)
            body.update(("\n\n".join(blocks) + f"\n\n[dim]searching {q} …[/]")
                        if blocks else f"[dim]searching {q} …[/]")
            results, err = await webintel.get_results(
                q, engine=self.engine, limit=self.limit)
            hits += len(results)
            if not results and ("202" in err or "429" in err or "rate" in err.lower()):
                blocked += 1
            blocks.append(self._format_block(q, results, err))
            body.update("\n\n".join(blocks))
            # pace requests so upstream engines' anti-bot doesn't trip on a
            # burst. SearXNG rate-limits its own engines (Google/DDG/Brave) when
            # site: dorks arrive too fast, so it needs pacing too, not just DDG.
            if i < len(self.queries) - 1:
                if self.engine == "searx":
                    await asyncio.sleep(float(config.get_setting("searx_pace", 2.0)))
                elif self.engine == "ddg":
                    await asyncio.sleep(1.2)
        if not blocks:
            body.update("[#ffb000]No dorks selected.[/]")
            return
        if hits == 0 and blocked and self.engine == "ddg":
            blocks.append(
                "[#ffb000]Every query was blocked by DuckDuckGo's anti-bot "
                "(HTTP 202).[/] Wait a minute and retry, run fewer dorks at "
                "once, or add a Google API key and use [b]Via API[/b] for "
                "reliable results.")
            body.update("\n\n".join(blocks))
        elif hits == 0 and blocked and self.engine == "searx":
            blocks.append(
                "[#ffb000]SearXNG's upstream engines were rate-limited.[/] "
                "Give it a minute and retry, raise the pace with "
                "[b]config set-setting searx_pace 3[/b], or pin engines that "
                "tolerate bursts (Bing, Google) in the instance settings.yml.")
            body.update("\n\n".join(blocks))

    def _format_block(self, query: str, results, err: str) -> str:
        lines = [f"[#ffb000]Searching for:[/] [b]{_esc(query)}[/b]", ""]
        if not results:
            lines.append(f"  [dim]{_esc(err) or 'no results'}[/]")
            return "\n".join(lines)
        for r in results:
            n = len(self._urls) + 1
            self._urls.append(r.url)
            # record as a finding so it also lands in the table/graph/report
            self.session.add(Finding(
                "dork", r.url, f"{r.title} :: {r.snippet[:160]}",
                f"dork-result:{self.engine}", Severity.LOW,
                meta={"url": r.url, "query": query, "title": r.title,
                      "snippet": r.snippet}))
            lines.append(f"  [#33ff66]{n}.[/] [b]Title:[/b] {_esc(r.title)}")
            lines.append(f"     [b]Link:[/b] [#66d9ff underline]{_esc(r.url)}[/]")
            if r.snippet:
                lines.append(f"     [b]Snippet:[/b] {_esc(r.snippet)}")
            lines.append("")
        return "\n".join(lines)

    def action_open(self):
        if self._urls:
            _open_in_browser(self.app, self._urls[0])

    def action_close(self):
        self.dismiss()

    @on(Button.Pressed, "#dork-results-close")
    def _close(self):
        self.dismiss()


def _esc(s: str) -> str:
    """Escape Rich markup so result text can't break the console markup."""
    return (s or "").replace("[", r"\[")


class ShodanScreen(ModalScreen):
    """Tick-box + editable Shodan query builder.

    Each built-in mainframe query gets a checkbox and an editable field, so you
    can toggle it, tweak the syntax, or type your own in the blank rows. Ticked
    rows with non-empty text are the queries that run.
    """

    CUSTOM_ROWS = 3

    def __init__(self, domain: str):
        super().__init__()
        self.domain = domain
        self.queries = shodan_recon.mainframe_queries()

    def compose(self) -> ComposeResult:
        with Vertical(id="modal"):
            yield Static("Shodan query selection", classes="modal-title")
            yield Static("[dim]Tick the queries to run and edit any of them. "
                         "Blank rows at the bottom are for your own. Use "
                         "hostname: or org: to scope to a target.[/]")
            with VerticalScroll(id="shodan-list"):
                for i, q in enumerate(self.queries):
                    with Horizontal(classes="squery-row"):
                        yield TickBox(value=(i < 3), id=f"schk-{i}")
                        yield Input(value=q["query"], id=f"sq-{i}")
                for c in range(self.CUSTOM_ROWS):
                    with Horizontal(classes="squery-row"):
                        yield TickBox(value=False, id=f"schk-c{c}")
                        yield Input(placeholder="custom Shodan query…",
                                    id=f"sq-c{c}")
            with Horizontal(classes="modal-buttons"):
                yield Button("Cancel", id="shodan-cancel")
                yield Button("Run queries", id="shodan-run", classes="primary")

    def _collect(self) -> list[str]:
        out: list[str] = []
        for i in range(len(self.queries)):
            if self.query_one(f"#schk-{i}", TickBox).value:
                val = self.query_one(f"#sq-{i}", Input).value.strip()
                if val:
                    out.append(val)
        for c in range(self.CUSTOM_ROWS):
            if self.query_one(f"#schk-c{c}", TickBox).value:
                val = self.query_one(f"#sq-c{c}", Input).value.strip()
                if val:
                    out.append(val)
        # de-dupe, preserve order
        seen: list[str] = []
        for q in out:
            if q not in seen:
                seen.append(q)
        return seen

    @on(Button.Pressed, "#shodan-cancel")
    def _cancel(self):
        self.dismiss(None)

    @on(Button.Pressed, "#shodan-run")
    def _run(self):
        self.dismiss(self._collect())


class KeysScreen(ModalScreen):
    """API-key entry."""

    def compose(self) -> ComposeResult:
        with Vertical(id="modal"):
            yield Static("API keys", classes="modal-title")
            yield Label("Google API key")
            yield Input(value=config.get_key("google_api_key"),
                        password=True, id="k-gkey")
            yield Label("Google CSE ID (cx)")
            yield Input(value=config.get_key("google_cse_id"), id="k-gcse")
            yield Static("[dim]No key? Enable the Custom Search API + make a "
                         "Programmable Search Engine (search the whole web), then "
                         "'Save & test'. See the README for the exact steps.[/]")
            yield Label("Shodan API key")
            yield Input(value=config.get_key("shodan_api_key"),
                        password=True, id="k-shodan")
            yield Label("FOFA email (infrastructure search)")
            yield Input(value=config.get_key("fofa_email"), id="k-fofa-email")
            yield Label("FOFA key")
            yield Input(value=config.get_key("fofa_key"),
                        password=True, id="k-fofa-key")
            yield Label("Anthropic API key (optional — for preview summaries)")
            yield Input(value=config.get_key("anthropic_api_key"),
                        password=True, id="k-anthropic")
            yield Label("HIBP API key (optional — breach checks)")
            yield Input(value=config.get_key("hibp_api_key"),
                        password=True, id="k-hibp")
            yield Label("GitHub token (optional — code-search API)")
            yield Input(value=config.get_key("github_token"),
                        password=True, id="k-github")
            yield Static("", id="keys-status")
            with Horizontal(classes="modal-buttons"):
                yield Button("Cancel", id="keys-cancel")
                yield Button("Save & test Google", id="keys-test")
                yield Button("Save", id="keys-save", classes="primary")

    def _persist(self):
        config.set_key("google_api_key", self.query_one("#k-gkey", Input).value)
        config.set_key("google_cse_id", self.query_one("#k-gcse", Input).value)
        config.set_key("shodan_api_key", self.query_one("#k-shodan", Input).value)
        config.set_key("fofa_email", self.query_one("#k-fofa-email", Input).value)
        config.set_key("fofa_key", self.query_one("#k-fofa-key", Input).value)
        config.set_key("anthropic_api_key",
                       self.query_one("#k-anthropic", Input).value)
        config.set_key("hibp_api_key", self.query_one("#k-hibp", Input).value)
        config.set_key("github_token", self.query_one("#k-github", Input).value)

    @on(Button.Pressed, "#keys-cancel")
    def _cancel(self):
        self.dismiss(False)

    @on(Button.Pressed, "#keys-test")
    def _test(self):
        self._persist()
        self.query_one("#keys-status", Static).update(
            "[#ffb000]testing Google Custom Search …[/]")
        self.run_worker(self._do_test(), exclusive=True)

    async def _do_test(self):
        verdict = await google_dork.check_credentials()
        colour = "green" if verdict["ok"] else "#ff5555"
        self.query_one("#keys-status", Static).update(
            f"[{colour}]{verdict['message']}[/]")

    @on(Button.Pressed, "#keys-save")
    def _save(self):
        self._persist()
        self.dismiss(True)


class OptionsScreen(ModalScreen):
    """Editable search options: wordlist, depths, ports, preview, chaining."""

    def __init__(self, opts: Options):
        super().__init__()
        self.opts = opts

    def _row(self, label: str, wid):
        return (Label(label), wid)

    def compose(self) -> ComposeResult:
        o = self.opts
        with Vertical(id="modal"):
            yield Static("Search options", classes="modal-title")
            with VerticalScroll(id="opts-list"):
                yield Static("[#ffb000]Appearance[/]")
                yield Label("Colour theme (applies immediately)")
                with Horizontal(id="opts-theme-row"):
                    from .themes import ORDER, LABELS
                    for tid in ORDER:
                        yield Button(LABELS[tid].split(" —")[0].split(" (")[0],
                                     id=f"theme-{tid}", classes="theme-btn")
                yield Static("", id="opts-theme-note")

                yield Static("[#ffb000]Files[/]")
                yield Label("Wordlist directory (users.txt, passwords.txt, "
                            "subdomains.txt …) — used by MyMap and the Notepad")
                yield Input(value=str(config.wordlist_dir()), id="o-wldir",
                            placeholder="~/.config/ezrecon/wordlists")

                yield Static("[#ffb000]Subdomains[/]")
                yield Label("Wordlist path (blank = built-in list)")
                yield Input(value=o.wordlist_path, id="o-wordlist",
                            placeholder="/path/to/wordlist.txt")
                yield Label("DNS concurrency")
                yield Input(value=str(o.dns_concurrency), id="o-dnsconc")
                yield Label("Brute per-query timeout (s)")
                yield Input(value=str(o.brute_timeout), id="o-bruteto")

                yield Static("[#ffb000]Email spider[/]")
                yield Label("Seed URL/host (blank = target)")
                yield Input(value=o.email_seed, id="o-seed",
                            placeholder="https://sub.target.com")
                yield Label("Crawl depth")
                yield Input(value=str(o.email_depth), id="o-depth")
                yield Label("Max pages")
                yield Input(value=str(o.email_max_pages), id="o-maxpages")
                yield Label("Spider concurrency")
                yield Input(value=str(o.spider_concurrency), id="o-spiderconc")
                yield Label("Known emails (comma-separated, added to the dossier)")
                yield Input(value=", ".join(o.known_emails), id="o-emails",
                            placeholder="a@target.com, b@target.com")

                yield Static("[#ffb000]Ports (banner grab)[/]")
                yield Label("Ports (blank = mainframe profile)")
                yield Input(value=o.ports, id="o-ports",
                            placeholder="21,23,992,175,443,50000")
                yield Label("Port concurrency")
                yield Input(value=str(o.port_concurrency), id="o-portconc")

                yield Static("[#ffb000]Preview[/]")
                yield Label("Engine (auto/ddg/api)")
                yield Input(value=o.preview_engine, id="o-pvengine")
                yield Label("Result limit")
                yield Input(value=str(o.preview_limit), id="o-pvlimit")

                yield Static("[#ffb000]Chaining[/]")
                yield TickBox("Chain discovered subdomains into dorks + spider",
                              value=o.chain_enabled, id="o-chain")
                yield Label("Chain cap (max subdomains)")
                yield Input(value=str(o.chain_cap), id="o-chaincap")
            with Horizontal(classes="modal-buttons"):
                yield Button("Cancel", id="opts-cancel")
                yield Button("Save", id="opts-save", classes="primary")

    def _int(self, wid_id: str, default: int) -> int:
        try:
            return int(self.query_one(wid_id, Input).value.strip())
        except (ValueError, AttributeError):
            return default

    def _float(self, wid_id: str, default: float) -> float:
        try:
            return float(self.query_one(wid_id, Input).value.strip())
        except (ValueError, AttributeError):
            return default

    @on(Button.Pressed, ".theme-btn")
    def _theme(self, ev):
        from .themes import THEMES, LABELS
        tid = ev.button.id.replace("theme-", "")
        if tid in THEMES:
            try:
                self.app.theme = tid
                config.set_setting("theme", tid)
                self.query_one("#opts-theme-note", Static).update(
                    f"[$success]theme set to {LABELS[tid]}[/]")
            except Exception as e:  # noqa: BLE001
                self.query_one("#opts-theme-note", Static).update(
                    f"[red]could not apply theme: {e}[/]")

    @on(Button.Pressed, "#opts-cancel")
    def _cancel(self):
        self.dismiss(None)

    @on(Button.Pressed, "#opts-save")
    def _save(self):
        o = self.opts
        config.set_setting("wordlist_dir",
                           self.query_one("#o-wldir", Input).value.strip())
        o.wordlist_path = self.query_one("#o-wordlist", Input).value.strip()
        o.dns_concurrency = self._int("#o-dnsconc", o.dns_concurrency)
        o.brute_timeout = self._float("#o-bruteto", o.brute_timeout)
        o.email_seed = self.query_one("#o-seed", Input).value.strip()
        o.email_depth = self._int("#o-depth", o.email_depth)
        o.email_max_pages = self._int("#o-maxpages", o.email_max_pages)
        o.spider_concurrency = self._int("#o-spiderconc", o.spider_concurrency)
        o.known_emails = [e.strip() for e in
                          self.query_one("#o-emails", Input).value.split(",")
                          if e.strip()]
        o.ports = self.query_one("#o-ports", Input).value.strip()
        o.port_concurrency = self._int("#o-portconc", o.port_concurrency)
        eng = self.query_one("#o-pvengine", Input).value.strip().lower()
        o.preview_engine = eng if eng in ("auto", "ddg", "api") else "auto"
        o.preview_limit = self._int("#o-pvlimit", o.preview_limit)
        o.chain_enabled = self.query_one("#o-chain", TickBox).value
        o.chain_cap = max(1, self._int("#o-chaincap", o.chain_cap))
        # record known emails into the session-independent dossier note is done by app
        self.dismiss(o)


class ChainConfirmScreen(ModalScreen):
    """Show what chaining will do and let the user confirm."""

    def __init__(self, plan: dict):
        super().__init__()
        self.plan = plan

    def compose(self) -> ComposeResult:
        p = self.plan
        note = (f" (capped from {p['total_hosts']})" if p["capped"] else "")
        lines = [
            f"[#ffb000]Chain {len(p['hosts'])} discovered subdomain(s){note}[/]",
            "",
            "This will, with no API calls:",
            f"  • add [b]{len(p['dork_queries'])}[/b] `site:` dork links",
            f"  • run the email spider on [b]{len(p['spider_seeds'])}[/b] seed(s)",
            "",
            "[dim]Hosts:[/]",
        ]
        lines += [f"  • {h}" for h in p["hosts"]]
        with Vertical(id="modal"):
            yield Static("Chain discoveries?", classes="modal-title")
            with VerticalScroll():
                yield Static("\n".join(lines))
            with Horizontal(classes="modal-buttons"):
                yield Button("Skip", id="chain-skip")
                yield Button("Run chain", id="chain-run", classes="primary")

    @on(Button.Pressed, "#chain-skip")
    def _skip(self):
        self.dismiss(None)

    @on(Button.Pressed, "#chain-run")
    def _run(self):
        self.dismiss({"plan": self.plan})


class PivotMenuScreen(ModalScreen):
    """Choose a pivot to run against a selected graph node."""

    def __init__(self, node):
        super().__init__()
        self.node = node
        self.options = pivotmod.pivots_for(node.kind)

    def compose(self) -> ComposeResult:
        with Vertical(id="modal"):
            yield Static(f"Pivot — {self.node.kind}: {self.node.label}",
                         classes="modal-title")
            if not self.options:
                yield Static("[dim]No pivots available for this node type.[/]")
            with VerticalScroll():
                for pid, label, active in self.options:
                    tag = " [#ffb000][active][/]" if active else " [dim][passive][/]"
                    yield Button(f"{label}{tag}", id=f"pv-{pid}")
            with Horizontal(classes="modal-buttons"):
                yield Button("Cancel", id="pv-cancel")

    @on(Button.Pressed)
    def _pick(self, event: Button.Pressed):
        bid = event.button.id or ""
        if bid == "pv-cancel":
            self.dismiss(None)
        elif bid.startswith("pv-"):
            pid = bid[3:]
            active = next((a for (i, _l, a) in self.options if i == pid), False)
            self.dismiss({"pivot": pid, "active": active, "node": self.node})


class GraphScreen(ModalScreen):
    """Navigable entity graph with live pivots (the Maltego-style view)."""

    BINDINGS = [
        ("escape", "close", "Close"),
        ("enter", "pivot", "Pivot"),
        ("x", "export", "Export HTML"),
    ]

    def __init__(self, app_ref):
        super().__init__()
        self._app = app_ref
        self.graph = None

    def compose(self) -> ComposeResult:
        with Vertical(id="modal-wide"):
            yield Static("Entity graph", classes="modal-title")
            yield Static("[dim]Select a node · [b]Enter[/b] pivot · "
                         "[b]x[/b] export HTML · [b]Esc[/b] close[/]")
            with Horizontal(id="graph-body"):
                with Vertical(id="graph-list-pane"):
                    yield DataTable(id="graph-nodes", cursor_type="row")
                with VerticalScroll(id="graph-detail"):
                    yield Static("Building graph…", id="graph-detail-body")
            with Horizontal(classes="modal-buttons"):
                yield Button("Close", id="graph-close")

    def on_mount(self):
        t = self.query_one("#graph-nodes", DataTable)
        t.add_columns("Kind", "Node")
        self.rebuild()

    def rebuild(self):
        self.graph = graphmod.build_graph(self._app.session)
        t = self.query_one("#graph-nodes", DataTable)
        t.clear()
        self._gnodes = list(self.graph.nodes.values())
        # sort by kind for readability
        order = {"domain": 0, "subdomain": 1, "ip": 2, "asn": 3, "port": 4,
                 "email": 5, "dork": 6}
        self._gnodes.sort(key=lambda n: (order.get(n.kind, 9), n.label))
        for n in self._gnodes:
            t.add_row(Text(n.kind, style=n.colour), Text(n.label[:48]))
        self.query_one("#graph-detail-body", Static).update(
            f"[green]{len(self.graph.nodes)} nodes · "
            f"{len(self.graph.edges)} edges[/]\n\nSelect a node to see its "
            "connections, then press Enter to pivot.")

    def _current(self):
        t = self.query_one("#graph-nodes", DataTable)
        if 0 <= t.cursor_row < len(self._gnodes):
            return self._gnodes[t.cursor_row]
        return None

    @on(DataTable.RowHighlighted, "#graph-nodes")
    def _hl(self, event):
        node = self._current()
        if node:
            self._show(node)

    def _show(self, node):
        lines = [f"[b]{node.kind}[/b]: {node.label}", ""]
        for k in ("asn", "prefix", "as_name", "service", "banner", "hint",
                  "url", "role"):
            v = node.meta.get(k)
            if v:
                lines.append(f"[dim]{k}:[/] {v}")
        nb = self.graph.neighbours(node.id)
        if nb:
            lines += ["", f"[#ffb000]Connections ({len(nb)}):[/]"]
            for other, rel, direction in nb[:30]:
                arrow = "→" if direction == "->" else "←"
                lines.append(f"  {arrow} [{other.colour}]{other.kind}[/] "
                             f"{other.label}  [dim]({rel})[/]")
        piv = pivotmod.pivots_for(node.kind)
        if piv:
            lines += ["", "[dim]Press Enter to pivot: " +
                      ", ".join(p[1] for p in piv) + "[/]"]
        self.query_one("#graph-detail-body", Static).update("\n".join(lines))

    def action_pivot(self):
        node = self._current()
        if not node:
            return
        if not pivotmod.pivots_for(node.kind):
            return
        self.app.push_screen(PivotMenuScreen(node), self._do_pivot)

    def _do_pivot(self, result):
        if not result:
            return
        pid, active, node = result["pivot"], result["active"], result["node"]
        if active and not (self._app._active_ok or
                           config.get_setting("allow_active_fetch", False)):
            def after(res):
                if not res:
                    return
                self._app._active_ok = True
                if res.get("remember"):
                    config.set_setting("allow_active_fetch", True)
                self._launch_pivot(pid, node)
            self.app.push_screen(ActiveConfirmScreen(), after)
        else:
            self._launch_pivot(pid, node)

    def _launch_pivot(self, pid, node):
        self.run_worker(self._pivot_worker(pid, node), exclusive=True)

    async def _pivot_worker(self, pid, node):
        detail = self.query_one("#graph-detail-body", Static)
        detail.update(f"Running pivot [b]{pid}[/] on {node.label} …")
        try:
            findings = await pivotmod.run_pivot(pid, node, self._app.session)
            self._app._add_findings(findings)
            self.rebuild()
            self.query_one("#graph-detail-body", Static).update(
                f"[green]pivot added {len(findings)} finding(s).[/] "
                "Graph updated.")
        except Exception as e:  # noqa: BLE001
            detail.update(f"[#ff5555]pivot error: {e}[/]")

    def action_export(self):
        try:
            from ..report.graph_html import graph_to_html
            out = config.output_dir() / \
                f"ezrecon_{self._app.session.target.replace('.', '_')}_graph.html"
            out.write_text(graph_to_html(self.graph, self._app.session))
            self.query_one("#graph-detail-body", Static).update(
                f"[green]graph exported:[/] {out}")
        except Exception as e:  # noqa: BLE001
            self.query_one("#graph-detail-body", Static).update(
                f"[#ff5555]export failed: {e}[/]")

    def action_close(self):
        self.dismiss()

    @on(Button.Pressed, "#graph-close")
    def _close(self):
        self.dismiss()


class KeywordsScreen(ModalScreen):
    """Collect up to 5 focus keywords to weight the AI OSINT prompt."""

    def __init__(self, target: str):
        super().__init__()
        self._target = target

    def compose(self) -> ComposeResult:
        with Vertical(id="modal"):
            yield Static("Focus the AI prompt", classes="modal-title")
            yield Static(
                f"[dim]Optional: up to 5 keywords or interests to prioritise for "
                f"{_esc(self._target)} — e.g. mainframe, RACF, payroll, VPN, "
                f"Citrix. The prompt will weight the investigation towards "
                f"these. Leave blank for a general report.[/]")
            yield Input(placeholder="comma-separated keywords (max 5)",
                        id="kw-input")
            with Horizontal(classes="modal-buttons"):
                yield Button("Skip", id="kw-skip")
                yield Button("Build prompt", id="kw-ok", classes="primary")

    @on(Button.Pressed, "#kw-skip")
    def _skip(self):
        self.dismiss([])

    @on(Input.Submitted, "#kw-input")
    @on(Button.Pressed, "#kw-ok")
    def _ok(self):
        raw = self.query_one("#kw-input", Input).value
        kws = [k.strip() for k in raw.split(",") if k.strip()][:5]
        self.dismiss(kws)


class TextScreen(ModalScreen):
    """Scrollable read-only text (used for the AI prompt)."""

    def __init__(self, title: str, body: str):
        super().__init__()
        self._title = title
        self._body = body

    def compose(self) -> ComposeResult:
        with Vertical(id="modal"):
            yield Static(self._title, classes="modal-title")
            with VerticalScroll():
                yield Static(self._body)
            with Horizontal(classes="modal-buttons"):
                yield Button("Close", id="text-close", classes="primary")

    @on(Button.Pressed, "#text-close")
    def _close(self):
        self.dismiss()


class ActiveConfirmScreen(ModalScreen):
    """Explicit opt-in before EZRecon reaches out to third-party pages."""

    def compose(self) -> ComposeResult:
        with Vertical(id="modal"):
            yield Static("Active reconnaissance — confirm", classes="modal-title")
            yield Static(
                "[#ffb000]The preview pane fetches third-party search results and "
                "pages.[/] This connects to hosts you may not own, so it is "
                "active recon, not passive. Only proceed against targets you are "
                "authorised to assess.")
            yield TickBox("Don't ask again (remember this choice)", id="ac-remember")
            with Horizontal(classes="modal-buttons"):
                yield Button("Cancel", id="ac-cancel")
                yield Button("Proceed", id="ac-ok", classes="primary")

    @on(Button.Pressed, "#ac-cancel")
    def _cancel(self):
        self.dismiss(None)

    @on(Button.Pressed, "#ac-ok")
    def _ok(self):
        self.dismiss({"remember": self.query_one("#ac-remember", TickBox).value})


class PreviewScreen(ModalScreen):
    """Fetch real results for a dork, inspect pages, summarise in context."""

    BINDINGS = [
        ("escape", "close", "Close"),
        ("o", "open_browser", "Open in browser"),
        ("s", "llm", "LLM summary"),
    ]

    def __init__(self, query: str, engine: str = "auto"):
        super().__init__()
        self.dork_query = query
        self.engine = engine
        self.terms = webintel.terms_from_query(query)
        self.results: list = []
        self.current = None  # PageIntel

    def compose(self) -> ComposeResult:
        with Vertical(id="modal-wide"):
            yield Static(f"Preview — {self.dork_query}", classes="modal-title")
            yield Static("[dim]Enter/click a result to fetch & analyse it · "
                         "[b]o[/b] open in browser · [b]s[/b] LLM summary · "
                         "[b]Esc[/b] close[/]")
            with Horizontal(id="preview-body"):
                with Vertical(id="preview-list-pane"):
                    yield DataTable(id="preview-results", cursor_type="row")
                with VerticalScroll(id="preview-detail"):
                    yield Static("Loading results…", id="preview-detail-body")
            with Horizontal(classes="modal-buttons"):
                yield Button("Close", id="preview-close")

    def on_mount(self):
        t = self.query_one("#preview-results", DataTable)
        t.add_columns("#", "Title", "URL")
        self.run_worker(self._load(), exclusive=True)

    async def _load(self):
        results, err = await webintel.get_results(self.dork_query, engine=self.engine)
        self.results = results
        t = self.query_one("#preview-results", DataTable)
        for i, r in enumerate(results, 1):
            t.add_row(str(i), (r.title or r.url)[:60], r.url[:80])
        detail = self.query_one("#preview-detail-body", Static)
        if not results:
            detail.update(f"[#ff5555]No results.[/] {err or ''}\n\n"
                          "DuckDuckGo can rate-limit; you can still open the "
                          "search in a browser with [b]o[/b].")
        else:
            src = results[0].source
            detail.update(f"[green]{len(results)} results[/] via {src}. "
                          "Select one to fetch and analyse it.")

    @on(DataTable.RowSelected, "#preview-results")
    def _pick(self, event: DataTable.RowSelected):
        idx = event.cursor_row
        if 0 <= idx < len(self.results):
            self.run_worker(self._fetch(idx), exclusive=True)

    async def _fetch(self, idx: int):
        r = self.results[idx]
        detail = self.query_one("#preview-detail-body", Static)
        detail.update(f"Fetching {r.url} …")
        intel = await webintel.fetch_page(r.url, terms=self.terms)
        self.current = intel
        detail.update(self._detail_text(intel))

    def _detail_text(self, intel, llm: str = "") -> str:
        if intel.error:
            return (f"[#ff5555]{intel.error}[/]\n\n{intel.url}\n\n"
                    "Press [b]o[/b] to open it in a browser instead.")
        lines = [
            f"[b]{intel.title or '(no title)'}[/b]",
            f"[dim]{intel.final_url or intel.url}[/]",
            f"[dim]HTTP {intel.status} · {intel.content_type} · "
            f"{intel.size} bytes[/]",
            "",
        ]
        if intel.description:
            lines += [f"[#b6ffce]{intel.description}[/]", ""]
        if intel.contexts:
            lines.append(f"[#ffb000]Terms in context ({len(intel.contexts)}):[/]")
            for h in intel.contexts:
                snip = h["snippet"].replace("❱", "[b #33ff66]").replace("❰", "[/]")
                lines.append(f"  • [b]{h['term']}[/b]: {snip}")
        else:
            lines.append("[dim]No highlighted terms found on the page.[/]")
        if llm:
            lines += ["", "[#ffb000]LLM summary:[/]", llm]
        elif webintel.has_llm():
            lines += ["", "[dim]Press [b]s[/b] for an LLM summary.[/]"]
        return "\n".join(lines)

    def action_llm(self):
        if not webintel.has_llm():
            self.app.bell()
            self.query_one("#preview-detail-body", Static).update(
                "[#ffb000]No Anthropic API key set (press 'k' on the main "
                "screen to add one).[/]")
            return
        if not self.current:
            return
        self.run_worker(self._do_llm(), exclusive=True, thread=True)

    async def _do_llm(self):
        detail = self.query_one("#preview-detail-body", Static)
        detail.update(self._detail_text(self.current) + "\n\n[dim]summarising…[/]")
        import asyncio
        loop = asyncio.get_event_loop()
        summary = await loop.run_in_executor(
            None, webintel.summarise_llm, self.current, self.dork_query)
        detail.update(self._detail_text(self.current, llm=summary))

    def action_open_browser(self):
        url = ""
        if self.current:
            url = self.current.final_url or self.current.url
        else:
            t = self.query_one("#preview-results", DataTable)
            if self.results and 0 <= t.cursor_row < len(self.results):
                url = self.results[t.cursor_row].url
        if not url:
            url = f"https://duckduckgo.com/?q={self.dork_query}"
        _open_in_browser(self.app, url)

    def action_close(self):
        self.dismiss()

    @on(Button.Pressed, "#preview-close")
    def _close(self):
        self.dismiss()


def _open_in_browser(app, url: str) -> None:
    """Open a URL in the system browser, suspending the TUI first."""
    import webbrowser

    try:
        with app.suspend():
            webbrowser.open(url)
    except Exception:  # noqa: BLE001 - headless / no browser
        try:
            webbrowser.open(url)
        except Exception:  # noqa: BLE001
            pass


class MyMapScreen(ModalScreen):
    """MyMap: browse/search NSE scripts, build and run nmap, read the output.

    Ported from Kev's standalone MyMap. Categories (including the mainframe and
    service sub-menus) on the left, scripts in the middle, description and the
    built command on the right, and a large output pane along the bottom. Speed
    dials are saved commands you can reload. Running is active recon, so it is
    gated behind an explicit confirm.
    """

    BINDINGS = [("escape", "close", "Close"), ("f1", "help", "Help")]
    SPEED_DIAL_ROW = "\u2605 Speed Dial"

    def __init__(self, target: str):
        super().__init__()
        self.target = target or ""
        self._cats: dict[str, list[str]] = {}
        self.selected_script = ""
        self._sd_mode = False
        self._dials: dict[str, str] = {}
        self._last_output = ""
        self._armed = False
        self._scan_running = False
        self._script_args: list[str] = []  # e.g. ["tso.user=IBMUSER"]

    def compose(self) -> ComposeResult:
        from ..engine import mymap as mm
        with Vertical(id="modal-wide"):
            yield Static("MyMap — nmap script runner", classes="modal-title")
            if not mm.have_nmap():
                yield Static("[#ff5555]nmap not found. Install it (e.g. "
                             "`sudo apt install nmap`) and reopen.[/]")
                with Horizontal(classes="modal-buttons"):
                    yield Button("Close", id="mymap-close")
                return
            yield Static("[dim]running a scan is active recon — only against "
                         "targets you are authorised to test[/]", id="mymap-hint")
            with Horizontal(id="mymap-io"):
                yield Input(value=self.target, id="mymap-target",
                            placeholder="target IP / CIDR / file")
                yield Input(value="", id="mymap-port",
                            placeholder="port(s): blank, 80, 80,443 or all")
            with Horizontal(id="mymap-opts"):
                yield Static("options:", id="mymap-opts-label")
                yield Checkbox("-sV", id="opt-sv")
                yield Checkbox("-Pn", id="opt-pn")
                yield Checkbox("-n", id="opt-n")
                yield Checkbox("--open", id="opt-open")
                yield Checkbox("+force script", id="opt-force")
            with Horizontal(id="mymap-top"):
                with Vertical(id="mymap-cats-pane"):
                    yield Input(value="", id="mymap-search",
                                placeholder="search scripts…")
                    yield DataTable(id="mymap-cats")
                with Vertical(id="mymap-scripts-pane"):
                    yield DataTable(id="mymap-scripts")
                with Vertical(id="mymap-args-pane"):
                    yield DataTable(id="mymap-args")
                with VerticalScroll(id="mymap-info-pane"):
                    yield Static("[dim]pick a script to see its description[/]",
                                 id="mymap-desc")
            with Horizontal(id="mymap-cmd-row"):
                yield Static("$", id="mymap-cmd-dollar")
                yield Input(value="", id="mymap-cmd",
                            placeholder="nmap command — editable; the columns just fill this in")
                yield Button("Files \u25b8", id="mymap-files")
            with Horizontal(id="mymap-actions"):
                yield Input(value="", id="mymap-dialname",
                            placeholder="speed-dial name")
                yield Button("Run", id="mymap-run", classes="primary")
                yield Button("Copy", id="mymap-copy")
                yield Button("Save dial", id="mymap-savedial")
                yield Button("Report", id="mymap-report")
                yield Button("Output \u2922", id="mymap-popout")
                yield Button("Clear", id="mymap-clearout")
                yield Button("Close", id="mymap-close")
            yield RichLog(id="mymap-output", markup=True, highlight=False, wrap=True)

    def on_mount(self):
        from ..engine import mymap as mm
        if not mm.have_nmap():
            return
        cats = self.query_one("#mymap-cats", DataTable)
        cats.add_columns("Category")
        cats.cursor_type = "row"
        scripts = self.query_one("#mymap-scripts", DataTable)
        scripts.add_columns("Script")
        scripts.cursor_type = "row"
        args = self.query_one("#mymap-args", DataTable)
        args.add_columns("Script-args")
        args.cursor_type = "row"
        self._cats = mm.categorize_scripts()
        self._dials = mm.load_dials()
        cats.add_row(f"{self.SPEED_DIAL_ROW} ({len(self._dials)})",
                     key=self.SPEED_DIAL_ROW)
        for name, items in self._cats.items():
            cats.add_row(f"{name} ({len(items)})", key=name)
        # start on the first real category
        first = next(iter(self._cats), None)
        if first:
            self._load_category(first)
        # seed the editable command line (line-authoritative from here on)
        from ..engine import cmdline as c
        self.query_one("#mymap-cmd", Input).value = c.compose(self.target)

    # ---- population --------------------------------------------------------
    def _load_category(self, name: str):
        self._sd_mode = (name == self.SPEED_DIAL_ROW)
        t = self.query_one("#mymap-scripts", DataTable)
        t.clear()
        if self._sd_mode:
            for title, flags in self._dials.items():
                t.add_row(f"{title}: {flags}", key=title)
        else:
            for s in self._cats.get(name, []):
                t.add_row(s[:-4] if s.endswith(".nse") else s, key=s)

    def _load_search(self, results: list[str]):
        self._sd_mode = False
        t = self.query_one("#mymap-scripts", DataTable)
        t.clear()
        for s in results:
            t.add_row(s[:-4] if s.endswith(".nse") else s, key=s)

    # ---- events ------------------------------------------------------------
    @on(DataTable.RowSelected, "#mymap-cats")
    def _pick_cat(self, ev):
        name = ev.row_key.value
        if name:
            self._load_category(name)

    def _line(self) -> Input:
        return self.query_one("#mymap-cmd", Input)

    def _force(self) -> bool:
        try:
            return bool(self.query_one("#opt-force", Checkbox).value)
        except Exception:  # noqa: BLE001
            return False

    @on(DataTable.RowSelected, "#mymap-scripts")
    def _pick_script(self, ev):
        from ..engine import mymap as mm
        from ..engine import cmdline as c
        key = ev.row_key.value or ""
        args_tbl = self.query_one("#mymap-args", DataTable)
        args_tbl.clear()
        line = self._line()
        if self._sd_mode:
            # a speed dial: rebuild the line as nmap <target> <dial flags>
            self.selected_script = ""
            self.query_one("#mymap-dialname", Input).value = key
            self.query_one("#mymap-desc", Static).update(
                f"[#ffb000]Speed dial:[/] {key}\n[dim]{self._dials.get(key,'')}[/]")
            tgt = self.query_one("#mymap-target", Input).value.strip()
            flags = self._dials.get(key, "")
            line.value = c._collapse(c.compose(tgt) + " " + flags)
        else:
            self.selected_script = key
            desc = mm.describe_script(key) or "[dim]no description in the script.[/]"
            self.query_one("#mymap-desc", Static).update(
                f"[#ffb000]{key}[/]\n\n{_esc(desc)}")
            try:
                args = mm.script_args(key)
            except Exception:  # noqa: BLE001
                args = []
            for a in args[:60]:
                name = a.get("name", "")
                if name:
                    args_tbl.add_row(name, key=name)
            if not args_tbl.row_count:
                args_tbl.add_row("(none documented)", key="")
            # surgical: replace only the --script token
            line.value = c.set_script(line.value, key, force=self._force())

    @on(DataTable.RowSelected, "#mymap-args")
    def _pick_arg(self, ev):
        """Insert one name= placeholder into --script-args (after --script)."""
        from ..engine import cmdline as c
        name = ev.row_key.value or ""
        if not name:
            return
        line = self._line()
        line.value = c.set_script_arg(line.value, name, "")
        try:
            self.set_focus(line)
        except Exception:  # noqa: BLE001
            pass

    @on(Button.Pressed, "#mymap-files")
    def _open_files(self):
        d = str(config.wordlist_dir())
        self.app.push_screen(
            FilePickerScreen(d, "insert its path into the command"),
            self._insert_file)

    def _insert_file(self, path):
        """Fill the last empty --script-args value with the path; else append."""
        if not path:
            return
        from ..engine import cmdline as c
        line = self._line()
        got = c.get_script_args(line.value)
        if got is not None:
            pairs = c._split_args(got[0])
            for i in range(len(pairs) - 1, -1, -1):
                if pairs[i][1] == "":
                    line.value = c.set_script_arg(line.value, pairs[i][0], path)
                    return
        v = line.value
        line.value = (v + " " + path) if v and not v.endswith(" ") else v + path

    @on(Checkbox.Changed, "#opt-sv")
    @on(Checkbox.Changed, "#opt-pn")
    @on(Checkbox.Changed, "#opt-n")
    @on(Checkbox.Changed, "#opt-open")
    def _toggle_flag(self, ev):
        from ..engine import cmdline as c
        flag = {"opt-sv": "-sV", "opt-pn": "-Pn", "opt-n": "-n",
                "opt-open": "--open"}[ev.checkbox.id]
        line = self._line()
        line.value = c.set_flag(line.value, flag, ev.value)

    @on(Checkbox.Changed, "#opt-force")
    def _toggle_force(self, ev):
        from ..engine import cmdline as c
        if self.selected_script:
            line = self._line()
            line.value = c.set_script(line.value, self.selected_script, ev.value)

    def action_help(self):
        from .help import topic_for_focus
        fid = getattr(self.focused, "id", "") or ""
        topic, hint = topic_for_focus(fid)
        self.app.push_screen(HelpScreen(topic or "mymap", hint))

    @on(Input.Submitted, "#mymap-search")
    def _do_search(self, ev):
        from ..engine import mymap as mm
        res = mm.search_scripts(ev.value)
        self._load_search(res)
        note = f"{len(res)} result(s)" if res else "no results"
        self.query_one("#mymap-desc", Static).update(
            f"[#ffb000]Search:[/] {_esc(ev.value.strip()[:8])} — {note}")

    @on(Input.Changed, "#mymap-target")
    def _target_changed(self, ev):
        from ..engine import cmdline as c
        line = self._line()
        line.value = c.set_target(line.value, ev.value)

    @on(Input.Changed, "#mymap-port")
    def _port_changed(self, ev):
        from ..engine import cmdline as c
        line = self._line()
        line.value = c.set_port(line.value, ev.value)

    def _current_argv(self):
        """What Run/Copy use: the (possibly hand-edited) command line."""
        from ..engine import cmdline as c
        raw = self._line().value.strip()
        if not raw:
            return []
        try:
            argv = c.run_argv(raw)
        except ValueError:
            return []
        if argv and argv[0] != "nmap":
            argv = ["nmap"] + argv
        return argv

    # ---- buttons -----------------------------------------------------------
    @on(Button.Pressed, "#mymap-close")
    def _close(self):
        self.dismiss(None)

    def action_close(self):
        self.dismiss(None)

    @on(Button.Pressed, "#mymap-copy")
    def _copy(self):
        from ..engine import mymap as mm
        argv = self._current_argv()
        self.dismiss(mm.command_str(argv) if argv else "")

    @on(Button.Pressed, "#mymap-clearout")
    def _clear(self):
        self.query_one("#mymap-output", RichLog).clear()

    @on(Button.Pressed, "#mymap-savedial")
    def _savedial(self):
        from ..engine import mymap as mm
        from ..engine import cmdline as c
        name = self.query_one("#mymap-dialname", Input).value
        # flags = the current line with 'nmap' and the target removed
        stripped = c.set_target(self._line().value, "").strip()
        if stripped.startswith("nmap"):
            stripped = stripped[4:].strip()
        ok, msg = mm.save_dial(name, stripped)
        out = self.query_one("#mymap-output", RichLog)
        out.write(f"[green]{msg}[/]" if ok else f"[#ff5555]{msg}[/]")
        if ok:
            self._dials = mm.load_dials()
            cats = self.query_one("#mymap-cats", DataTable)
            try:
                cats.update_cell(self.SPEED_DIAL_ROW, "Category",
                                 f"{self.SPEED_DIAL_ROW} ({len(self._dials)})")
            except Exception:  # noqa: BLE001
                pass

    @on(Button.Pressed, "#mymap-popout")
    def _popout(self):
        out = self.query_one("#mymap-output", RichLog)
        text = self._last_output or ""
        if not text.strip():
            out.write("[dim]no scan output yet — run a scan first.[/]")
            return
        cmd = self._line().value.strip()
        self.app.push_screen(OutputScreen(text, title="nmap output", command=cmd,
                                          get_text=lambda: self._last_output))

    @on(Button.Pressed, "#mymap-report")
    def _report(self):
        from ..engine import mymap as mm
        out = self.query_one("#mymap-output", RichLog)
        if not self._last_output:
            out.write("[dim]no scan output yet to report on.[/]")
            return
        target = self.query_one("#mymap-target", Input).value.strip()
        report = mm.generate_report(self._last_output,
                                    self.selected_script or "custom", target)
        out.write("[#ffb000]── report ──[/]")
        for ln in report.split("\n"):
            out.write(_esc(ln))

    @on(Button.Pressed, "#mymap-run")
    def _run(self):
        from ..engine import mymap as mm
        if self._scan_running:
            return
        out = self.query_one("#mymap-output", RichLog)
        argv = self._current_argv()
        if not argv or len(argv) < 2:
            out.write("[#ff5555]build or type a command first (script + target).[/]")
            return
        active_ok = bool(getattr(self.app, "_active_ok", False)) or \
            bool(config.get_setting("allow_active_fetch", False))
        if not active_ok and not self._armed:
            self._armed = True
            out.write("[#ffb000]This runs an active nmap scan against the "
                      "target.[/] Press Run again to confirm and enable active "
                      "recon for this session, or use Copy to run it yourself.")
            return
        self._armed = False
        try:
            self.app._active_ok = True
        except Exception:  # noqa: BLE001
            pass
        self.run_worker(self._do_run(argv), exclusive=True)

    async def _do_run(self, argv):
        from ..engine import mymap as mm
        out = self.query_one("#mymap-output", RichLog)
        self._scan_running = True
        out.write(f"[dim]$ {_esc(mm.command_str(argv))}[/]")

        def on_line(ln: str):
            style = mm.line_style(ln)
            out.write(Text(ln, style=style) if style else ln)

        output, err = await mm.run_argv(argv, on_line=on_line)
        self._last_output = output
        if err:
            out.write(f"[#ff5555]{_esc(err)}[/]")
        else:
            out.write("[green]── scan complete ── press Report for a summary[/]")
        self._scan_running = False


class OutputScreen(ModalScreen):
    """A large, scrollable, copyable pop-out of scan output."""

    BINDINGS = [("escape", "close", "Close")]

    def __init__(self, text: str, title: str = "Output", command: str = "",
                 get_text=None):
        super().__init__()
        self._text = text or ""
        self._title = title
        self._command = command
        self._get_text = get_text

    def compose(self) -> ComposeResult:
        with Vertical(id="modal-wide"):
            yield Static(self._title, classes="modal-title")
            if self._command:
                yield Static(f"[dim]$ {_esc(self._command)}[/]", id="out-cmd")
            yield TextArea(self._text, id="out-text", read_only=True,
                           soft_wrap=False)
            with Horizontal(id="out-namerow"):
                yield Input(value="nmap_output.txt", id="out-name",
                            placeholder="filename to save")
                yield Static("", id="out-status")
            with Horizontal(classes="modal-buttons"):
                yield Button("Copy all", id="out-copy", classes="primary")
                yield Button("Save", id="out-save")
                yield Button("Refresh", id="out-refresh")
                yield Button("Close", id="out-close")

    def _status(self, msg: str):
        self.query_one("#out-status", Static).update(msg)

    @on(Button.Pressed, "#out-copy")
    def _copy(self):
        try:
            self.app.copy_to_clipboard(self.query_one("#out-text", TextArea).text)
            self._status("[green]copied to clipboard[/]")
        except Exception:  # noqa: BLE001
            self._status("[#ffb000]clipboard not available here[/]")

    @on(Button.Pressed, "#out-save")
    def _save(self):
        name = self.query_one("#out-name", Input).value.strip() or "nmap_output.txt"
        try:
            path = config.output_dir() / name
            path.write_text(self.query_one("#out-text", TextArea).text)
            self._status(f"[green]saved[/] {path}")
        except OSError as e:
            self._status(f"[#ff5555]save failed: {e}[/]")

    @on(Button.Pressed, "#out-refresh")
    def _refresh(self):
        if self._get_text:
            try:
                self.query_one("#out-text", TextArea).text = self._get_text() or ""
                self._status("[green]refreshed[/]")
            except Exception:  # noqa: BLE001
                pass

    @on(Button.Pressed, "#out-close")
    def action_close(self):
        self.dismiss(None)


class RssScreen(ModalScreen):
    """CTI RSS reader: fetch security feeds, open items, email a selection.

    Items mentioning the current target (or mainframe keywords) are highlighted.
    """

    BINDINGS = [("escape", "close", "Close"), ("r", "refresh", "Refresh"),
                ("f1", "help", "Help")]

    def __init__(self, terms=None):
        super().__init__()
        self.terms = terms or []
        self.feeds = []
        self.cur = 0

    def compose(self) -> ComposeResult:
        with Vertical(id="modal-wide"):
            yield Static("CTI RSS — security feeds", classes="modal-title")
            yield Static("[dim]loading feeds …[/]", id="rss-status")
            with Horizontal(id="rss-body"):
                with VerticalScroll(id="rss-feeds"):
                    yield Static("", id="rss-feed-list")
                with Vertical(id="rss-right"):
                    yield DataTable(id="rss-items")
            with Horizontal(id="rss-addrow"):
                yield Input(placeholder="Feed name", id="rss-add-name")
                yield Input(placeholder="https://site/feed/", id="rss-add-url")
                yield Button("Add feed", id="rss-add")
            with Horizontal(classes="modal-buttons"):
                yield Button("Close", id="rss-close")
                yield Button("Open selected", id="rss-open", classes="primary")
                yield Button("Email selected", id="rss-email")
                yield Button("Refresh", id="rss-refresh")

    def on_mount(self):
        t = self.query_one("#rss-items", DataTable)
        t.add_columns("#", "Title", "Published")
        t.cursor_type = "row"
        self.run_worker(self._load(), exclusive=True)

    async def _load(self):
        from ..engine import rss
        self.query_one("#rss-status", Static).update("[#ffb000]fetching feeds …[/]")
        self.feeds = await rss.fetch_all(highlight_terms=self.terms)
        self._render_feed_list()
        self._show_feed(0)
        rel = sum(1 for f in self.feeds for it in f.items if it.relevant)
        note = f" · [#33ff66]{rel} match your target[/]" if rel else ""
        self.query_one("#rss-status", Static).update(
            f"[dim]{len(self.feeds)} feeds{note}. ↑↓ select · o open · e email[/]")

    def _render_feed_list(self):
        lines = []
        for i, f in enumerate(self.feeds):
            mark = "›" if i == self.cur else " "
            err = " [red]![/]" if f.error else ""
            rel = sum(1 for it in f.items if it.relevant)
            tag = f" [#33ff66]({rel})[/]" if rel else ""
            style = "bold #b6ffce" if i == self.cur else "#33ff66"
            lines.append(f"[{style}]{mark} {f.name}[/]{tag}{err}")
        self.query_one("#rss-feed-list", Static).update("\n".join(lines))

    def _show_feed(self, idx):
        if not self.feeds:
            return
        self.cur = max(0, min(idx, len(self.feeds) - 1))
        self._render_feed_list()
        f = self.feeds[self.cur]
        t = self.query_one("#rss-items", DataTable)
        t.clear()
        for i, it in enumerate(f.items, 1):
            title = it.title
            if it.relevant:
                title = f"★ {title}"
            t.add_row(str(i), title[:80], (it.published or "")[:24])

    def _current_item(self):
        f = self.feeds[self.cur] if self.feeds else None
        if not f or not f.items:
            return None
        t = self.query_one("#rss-items", DataTable)
        row = t.cursor_row
        if row is None or row < 0 or row >= len(f.items):
            return None
        return f.items[row]

    @on(Button.Pressed, "#rss-close")
    def _c(self):
        self.dismiss(None)

    @on(Button.Pressed, "#rss-refresh")
    def _r(self):
        self.run_worker(self._load(), exclusive=True)

    @on(Button.Pressed, "#rss-add")
    def _add(self):
        from ..engine import rss
        name = self.query_one("#rss-add-name", Input).value
        url = self.query_one("#rss-add-url", Input).value
        ok, msg = rss.add_feed(name, url)
        colour = "green" if ok else "red"
        self.query_one("#rss-status", Static).update(f"[{colour}]{msg}[/]")
        if ok:
            self.query_one("#rss-add-name", Input).value = ""
            self.query_one("#rss-add-url", Input).value = ""
            self.run_worker(self._load(), exclusive=True)

    def action_refresh(self):
        self.run_worker(self._load(), exclusive=True)

    def action_help(self):
        from .help import topic_for_focus
        fid = getattr(self.focused, "id", "") or ""
        topic, hint = topic_for_focus(fid)
        self.app.push_screen(HelpScreen(topic or "rss", hint))

    @on(Button.Pressed, "#rss-open")
    def _open(self):
        it = self._current_item()
        if it and it.link:
            _open_in_browser(self.app, it.link)
            self.query_one("#rss-status", Static).update(
                f"[green]opened:[/] {it.link[:70]}")

    @on(Button.Pressed, "#rss-email")
    def _email(self):
        from ..engine import rss
        it = self._current_item()
        if not it:
            return
        if not rss.smtp_configured():
            self.query_one("#rss-status", Static).update(
                "[#ffb000]SMTP not set. Configure smtp_host/smtp_from/smtp_to "
                "in config to email items.[/]")
            return
        ok, msg = rss.send_email(f"[CTI] {it.title}", [it.link])
        colour = "green" if ok else "#ff5555"
        self.query_one("#rss-status", Static).update(f"[{colour}]{msg}[/]")

    @on(DataTable.RowHighlighted)
    def _hl(self, ev):
        pass

    def on_key(self, ev):
        # left/right (or [ ]) switch feeds
        if ev.key in ("left", "["):
            self._show_feed(self.cur - 1)
        elif ev.key in ("right", "]"):
            self._show_feed(self.cur + 1)

    def action_close(self):
        self.dismiss(None)


class HelpScreen(ModalScreen):
    """In-app help and labs. Topic list on the left, content on the right."""

    BINDINGS = [("escape", "close", "Close"), ("f1", "close", "Close")]

    def __init__(self, topic: str = "overview", hint: str = ""):
        super().__init__()
        self._topic = topic or "overview"
        self._hint = hint

    def compose(self) -> ComposeResult:
        from .help import HELP, HELP_ORDER
        with Vertical(id="modal-wide"):
            yield Static("Help & Labs  [dim](Esc closes · F1 anywhere is "
                         "contextual)[/]", classes="modal-title")
            with Horizontal(id="help-body"):
                with VerticalScroll(id="help-list-pane"):
                    t = DataTable(id="help-topics")
                    yield t
                with VerticalScroll(id="help-content-pane"):
                    yield Static("", id="help-content")
            with Horizontal(classes="modal-buttons"):
                yield Button("Close", id="help-close")

    def on_mount(self):
        from .help import HELP, HELP_ORDER
        t = self.query_one("#help-topics", DataTable)
        t.add_columns("Topic")
        t.cursor_type = "row"
        for tid in HELP_ORDER:
            t.add_row(HELP[tid]["title"], key=tid)
        self._show(self._topic)
        # move the cursor to the opened topic
        try:
            idx = HELP_ORDER.index(self._topic)
            t.move_cursor(row=idx)
        except ValueError:
            pass

    def _show(self, tid: str):
        from .help import HELP
        topic = HELP.get(tid) or HELP["overview"]
        body = topic["body"]
        if self._hint:
            body = f"[#33ff66]➤ {self._hint}[/]\n\n" + body
            self._hint = ""  # only show the pointer the first time
        self.query_one("#help-content", Static).update(
            f"[#ffb000]{topic['title']}[/]\n\n{body}")

    @on(DataTable.RowSelected, "#help-topics")
    def _pick(self, ev):
        if ev.row_key.value:
            self._show(ev.row_key.value)

    @on(Button.Pressed, "#help-close")
    def _close(self):
        self.dismiss(None)

    def action_close(self):
        self.dismiss(None)


class FilePickerScreen(ModalScreen):
    """List files in a directory; selecting one dismisses with its full path."""

    BINDINGS = [("escape", "close", "Close")]

    def __init__(self, directory, purpose: str = "insert its path"):
        super().__init__()
        self._dir = _Path(directory)
        self._purpose = purpose

    def compose(self) -> ComposeResult:
        with Vertical(id="modal"):
            yield Static("Files", classes="modal-title")
            yield Static(f"[dim]{self._dir}\nselect a file to {self._purpose}[/]",
                         id="fp-hint")
            yield DataTable(id="fp-table")
            with Horizontal(classes="modal-buttons"):
                yield Button("Open", id="fp-open", classes="primary")
                yield Button("Refresh", id="fp-refresh")
                yield Button("Close", id="fp-close")

    def on_mount(self):
        t = self.query_one("#fp-table", DataTable)
        t.add_columns("File", "Size")
        t.cursor_type = "row"
        self._load()

    def _load(self):
        t = self.query_one("#fp-table", DataTable)
        t.clear()
        try:
            files = sorted(p for p in self._dir.iterdir() if p.is_file())
        except OSError:
            files = []
        if not files:
            t.add_row("(no files here yet — make one in the Notepad)", "", key="")
            return
        for p in files:
            try:
                size = f"{p.stat().st_size} B"
            except OSError:
                size = ""
            t.add_row(p.name, size, key=str(p))

    def _cursor_key(self):
        t = self.query_one("#fp-table", DataTable)
        try:
            return t.ordered_rows[t.cursor_row].key.value
        except Exception:  # noqa: BLE001
            return None

    @on(DataTable.RowSelected, "#fp-table")
    def _pick(self, ev):
        key = ev.row_key.value
        if key:
            self.dismiss(key)

    @on(Button.Pressed, "#fp-open")
    def _open(self):
        key = self._cursor_key()
        if key:
            self.dismiss(key)

    @on(Button.Pressed, "#fp-refresh")
    def _refresh(self):
        self._load()

    @on(Button.Pressed, "#fp-close")
    def action_close(self):
        self.dismiss(None)


class NotesScreen(ModalScreen):
    """A simple notepad: create, edit, open and save text files anywhere.

    Defaults to the wordlist directory, so files made here (users.txt,
    passwords.txt, subdomains.txt …) are exactly what MyMap's Files button
    offers for nmap script-args.
    """

    BINDINGS = [("escape", "close", "Close")]

    def compose(self) -> ComposeResult:
        with Vertical(id="modal-wide"):
            yield Static("Notepad — create, edit and save text files",
                         classes="modal-title")
            with Horizontal(id="notes-dirrow"):
                yield Input(value=str(config.wordlist_dir()), id="notes-dir",
                            placeholder="directory to list and save into")
                yield Button("Go", id="notes-godir")
            with Horizontal(id="notes-body"):
                with Vertical(id="notes-listpane"):
                    yield Static("[#ffb000]Files[/]")
                    yield DataTable(id="notes-files")
                with Vertical(id="notes-editpane"):
                    yield TextArea("", id="notes-text", soft_wrap=False)
            with Horizontal(id="notes-namerow"):
                yield Input(value="", id="notes-name",
                            placeholder="filename e.g. users.txt")
                yield Static("", id="notes-status")
            with Horizontal(classes="modal-buttons"):
                yield Button("New", id="notes-new")
                yield Button("Open", id="notes-open")
                yield Button("Save", id="notes-save", classes="primary")
                yield Button("Copy all", id="notes-copy")
                yield Button("Close", id="notes-close")

    def on_mount(self):
        t = self.query_one("#notes-files", DataTable)
        t.add_columns("File")
        t.cursor_type = "row"
        self._load_dir()

    def _dir(self) -> _Path:
        return _Path(self.query_one("#notes-dir", Input).value.strip() or ".")\
            .expanduser()

    def _status(self, msg: str):
        self.query_one("#notes-status", Static).update(msg)

    def _load_dir(self):
        d = self._dir()
        try:
            d.mkdir(parents=True, exist_ok=True)
        except OSError:
            pass
        t = self.query_one("#notes-files", DataTable)
        t.clear()
        try:
            files = sorted(p for p in d.iterdir() if p.is_file())
        except OSError:
            files = []
        if not files:
            t.add_row("(empty)", key="")
        for p in files:
            t.add_row(p.name, key=str(p))

    @on(Button.Pressed, "#notes-godir")
    def _go(self):
        self._load_dir()
        config.set_setting("wordlist_dir", str(self._dir()))
        self._status(f"[dim]listing {self._dir()}[/]")

    @on(DataTable.RowSelected, "#notes-files")
    def _open_file(self, ev):
        key = ev.row_key.value
        if not key:
            return
        p = _Path(key)
        try:
            self.query_one("#notes-text", TextArea).text = p.read_text(
                errors="replace")
            self.query_one("#notes-name", Input).value = p.name
            self._status(f"[green]opened[/] {p.name}")
        except OSError as e:
            self._status(f"[#ff5555]open failed: {e}[/]")

    @on(Button.Pressed, "#notes-open")
    def _open_btn(self):
        t = self.query_one("#notes-files", DataTable)
        try:
            key = t.ordered_rows[t.cursor_row].key.value
        except Exception:  # noqa: BLE001
            key = None
        if key:
            self._open_file(type("E", (), {"row_key": type(
                "K", (), {"value": key})()})())

    @on(Button.Pressed, "#notes-new")
    def _new(self):
        self.query_one("#notes-text", TextArea).text = ""
        self.query_one("#notes-name", Input).value = ""
        self._status("[dim]new file[/]")

    @on(Button.Pressed, "#notes-save")
    def _save(self):
        name = self.query_one("#notes-name", Input).value.strip()
        if not name:
            self._status("[#ffb000]enter a filename first[/]")
            return
        p = self._dir() / name
        try:
            p.write_text(self.query_one("#notes-text", TextArea).text)
            self._load_dir()
            self._status(f"[green]saved[/] {p}")
        except OSError as e:
            self._status(f"[#ff5555]save failed: {e}[/]")

    @on(Button.Pressed, "#notes-copy")
    def _copy(self):
        text = self.query_one("#notes-text", TextArea).text
        try:
            self.app.copy_to_clipboard(text)
            self._status("[green]copied to clipboard[/]")
        except Exception:  # noqa: BLE001
            self._status("[#ffb000]clipboard not available here[/]")

    @on(Button.Pressed, "#notes-close")
    def action_close(self):
        self.dismiss(None)


class ReportScreen(ModalScreen):
    """Structured report with a preview and save as TXT, DOCX or PDF."""

    BINDINGS = [("escape", "close", "Close")]

    def __init__(self, session):
        super().__init__()
        self._session = session

    def compose(self) -> ComposeResult:
        stem = f"ezrecon_{(self._session.target or 'report').replace('.', '_')}"
        with Vertical(id="modal-wide"):
            yield Static("Report — structured, save as TXT / DOCX / PDF",
                         classes="modal-title")
            with VerticalScroll(id="report-preview"):
                yield Static(_esc(exporters.render_txt(self._session)),
                             id="report-body")
            with Horizontal(id="report-namerow"):
                yield Input(value=stem, id="report-name",
                            placeholder="filename (no extension)")
                yield Static("", id="report-status")
            with Horizontal(classes="modal-buttons"):
                yield Button("Save TXT", id="report-txt")
                yield Button("Save DOCX", id="report-docx")
                yield Button("Save PDF", id="report-pdf", classes="primary")
                yield Button("Also MD/HTML/JSON", id="report-all")
                yield Button("Copy", id="report-copy")
                yield Button("Close", id="report-close")

    def _stem(self) -> str:
        return self.query_one("#report-name", Input).value.strip() or "ezrecon_report"

    def _status(self, msg: str):
        self.query_one("#report-status", Static).update(msg)

    def _save(self, fmt: str):
        try:
            out = config.output_dir() / self._stem()
            path = exporters.save_report(self._session, out, fmt)
            self._status(f"[green]saved[/] {path}")
        except Exception as e:  # noqa: BLE001
            self._status(f"[#ff5555]save failed: {e}[/]")

    @on(Button.Pressed, "#report-txt")
    def _txt(self):
        self._save("txt")

    @on(Button.Pressed, "#report-docx")
    def _docx(self):
        self._save("docx")

    @on(Button.Pressed, "#report-pdf")
    def _pdf(self):
        self._save("pdf")

    @on(Button.Pressed, "#report-all")
    def _all(self):
        try:
            paths = reporter.write_reports(self._session, config.output_dir(),
                                           stem=self._stem())
            self._status(f"[green]wrote[/] {', '.join(paths.keys())}")
        except Exception as e:  # noqa: BLE001
            self._status(f"[#ff5555]export failed: {e}[/]")

    @on(Button.Pressed, "#report-copy")
    def _copy(self):
        try:
            self.app.copy_to_clipboard(exporters.render_txt(self._session))
            self._status("[green]copied to clipboard[/]")
        except Exception:  # noqa: BLE001
            self._status("[#ffb000]clipboard not available here[/]")

    @on(Button.Pressed, "#report-close")
    def action_close(self):
        self.dismiss(None)


class EZReconApp(App):
    CSS_PATH = "app.tcss"
    TITLE = "eZrecon: Passive and Active Recon"
    SUB_TITLE = "by Kev Milne · offensivesec.org"

    BINDINGS = [
        ("q", "quit", "Quit"),
        ("r", "run", "Run module"),
        ("a", "auto", "Auto-recon"),
        ("e", "export", "Export report"),
        ("k", "keys", "API keys"),
        ("p", "preview", "Preview link"),
        ("g", "graph", "Graph"),
        ("o", "options", "Options"),
        ("n", "nse", "MyMap (nmap)"),
        ("s", "rss", "CTI RSS"),
        ("t", "notes", "Notepad"),
        ("c", "clear", "Clear"),
        ("f1", "help", "Help"),
    ]

    def __init__(self, **kw):
        super().__init__(**kw)
        self.active_module = "auto"
        self.session = Session("")
        self._busy = False
        self._row_findings: list[Finding] = []
        self._active_ok = False
        self.opts = Options.from_config()
        self._chained_hosts: set[str] = set()

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with Horizontal(id="body"):
            with Vertical(id="sidebar"):
                yield Static("MODULES", classes="side-title")
                for mid, label in MODULES:
                    yield Button(label, id=f"mod-{mid}")
                yield Static("", classes="side-title")
                yield Button("Graph", id="mod-graph")
                yield Button("Notepad", id="mod-notes")
                yield Button("Options", id="mod-options")
                yield Button("API keys", id="mod-keys")
                yield Button("Help / Labs", id="mod-help")
                yield Static("code by Kev Milne\nhttps://offensivesec.org",
                             id="attrib")
            with Vertical(id="main"):
                yield Static(BANNER.format(v=f"v{__version__}"), classes="banner")
                with Horizontal(id="target-row"):
                    yield Input(placeholder="target domain or URL (e.g. sighberbank.com)",
                                id="target")
                    yield Button("Run", id="run-btn", classes="primary")
                yield RichLog(id="status", markup=True, wrap=True, highlight=False)
                yield DataTable(id="results", zebra_stripes=True)
        yield Footer()

    def on_mount(self):
        # register custom themes and apply the saved choice
        from .themes import THEMES, DEFAULT
        for theme in THEMES.values():
            try:
                self.register_theme(theme)
            except Exception:  # noqa: BLE001
                pass
        saved = config.get_setting("theme", DEFAULT)
        if saved not in THEMES:
            saved = DEFAULT
        try:
            self.theme = saved
        except Exception:  # noqa: BLE001
            pass
        table = self.query_one("#results", DataTable)
        table.add_columns("Sev", "Category", "Key", "Value")
        self._set_active("auto")
        self._log(f"[#ffb000]EZRecon {__version__} ready.[/] "
                  "Pick a module, enter a target, press Run.")
        if not config.has_google():
            self._log("[dim]No Google API key set — press 'k' to add one for dorks.[/]")

    # -- helpers -----------------------------------------------------------
    def _log(self, msg: str):
        self.query_one("#status", RichLog).write(msg)

    def _set_active(self, mid: str):
        self.active_module = mid
        for m, _ in MODULES:
            try:
                btn = self.query_one(f"#mod-{m}", Button)
                btn.set_class(m == mid, "-active")
            except Exception:  # noqa: BLE001
                pass

    def _sev_colours(self):
        """Resolve severity colours from the active theme so they stay readable."""
        try:
            t = self.current_theme
            return {"critical": t.error, "high": t.error, "medium": t.warning,
                    "low": t.success, "info": t.primary}
        except Exception:  # noqa: BLE001
            return SEV_COLOUR

    def _add_findings(self, findings: list[Finding]):
        table = self.query_one("#results", DataTable)
        sev_col = self._sev_colours()
        for f in findings:
            sev = f.severity.value
            colour = sev_col.get(sev, sev_col.get("low", "#33ff66"))
            high = sev in ("high", "critical")
            url = f.meta.get("url", "")
            if url and f.source.startswith("dork-link"):
                # clickable in terminals that support OSC-8 hyperlinks
                value = Text(url[:200], style=f"underline {colour} link {url}"
                             if high else f"underline #7dffb0 link {url}")
            else:
                value = Text(f.value[:200], style=f"bold {colour}" if high else "")
            sev_style = f"bold {colour}" if high else colour
            cat_style = f"bold {colour}" if high else "#7dffb0"
            key_style = f"bold {colour}" if high else ""
            table.add_row(
                Text(sev.upper() if high else sev, style=sev_style),
                Text(f.category, style=cat_style),
                Text(f.key[:40], style=key_style),
                value,
            )
            self._row_findings.append(f)

    def _clear_table(self):
        self.query_one("#results", DataTable).clear()
        self._row_findings = []

    def _progress(self, done: int, total: int):
        if total and done % max(1, total // 5) == 0:
            self._log(f"[dim]  … {done}/{total}[/]")

    # -- events ------------------------------------------------------------
    @on(Button.Pressed)
    def _button(self, event: Button.Pressed):
        bid = event.button.id or ""
        if bid.startswith("mod-"):
            mid = bid[4:]
            if mid == "keys":
                self.action_keys()
            elif mid == "options":
                self.action_options()
            elif mid == "graph":
                self.action_graph()
            elif mid == "notes":
                self.action_notes()
            elif mid == "help":
                self.action_help()
            else:
                self._set_active(mid)
                self._log(f"[#b6ffce]Module:[/] {mid}")
        elif bid == "run-btn":
            self.action_run()

    @on(Input.Submitted, "#target")
    def _submit(self, event: Input.Submitted):
        self.action_run()

    # -- actions -----------------------------------------------------------
    def _target(self) -> str:
        return self.query_one("#target", Input).value.strip()

    def action_clear(self):
        self._clear_table()
        self.session = Session(self._target())
        self._log("[dim]cleared.[/]")

    def action_help(self):
        # contextual: if a topic exists for the active module, open there
        from .help import HELP
        topic = self.active_module if self.active_module in HELP else "overview"
        self.push_screen(HelpScreen(topic))

    def action_preview(self):
        table = self.query_one("#results", DataTable)
        if table.row_count == 0:
            self._log("[#ffb000]no results to preview — run a dork first.[/]")
            return
        idx = table.cursor_row
        if idx is None or not (0 <= idx < len(self._row_findings)):
            self._log("[#ffb000]select a result row first.[/]")
            return
        f = self._row_findings[idx]
        query = f.meta.get("query", "")
        if not query and f.category == "dork":
            query = f.key
        if not query:
            self._log("[#ffb000]preview works on dork rows (link or result).[/]")
            return
        self._open_preview(query)

    def _open_preview(self, query: str):
        if self._active_ok or config.get_setting("allow_active_fetch", False):
            self.push_screen(PreviewScreen(query))
            return

        def after(res):
            if not res:
                self._log("[dim]preview cancelled.[/]")
                return
            self._active_ok = True
            if res.get("remember"):
                config.set_setting("allow_active_fetch", True)
            self.push_screen(PreviewScreen(query))

        self.push_screen(ActiveConfirmScreen(), after)

    def action_keys(self):
        self.push_screen(KeysScreen(), lambda saved: self._log(
            "[green]keys saved.[/]" if saved else "[dim]keys unchanged.[/]"))

    def action_options(self):
        def apply(opts):
            if opts is not None:
                self.opts = opts
                self._log("[green]options updated.[/]")
        self.push_screen(OptionsScreen(self.opts), apply)

    def action_nse(self):
        target = self.query_one("#target", Input).value.strip() or \
            (self.session.target or "")

        def done(cmd):
            if cmd:
                self._log(f"[green]nmap command:[/] [#33ff66]{cmd}[/]")
                self._log("[dim]  (copied to the log — paste into your shell; "
                          "SYN scans need sudo).[/]")
        self.push_screen(MyMapScreen(target), done)

    def action_rss(self):
        target = self.query_one("#target", Input).value.strip() or \
            (self.session.target or "")
        terms = ["mainframe", "z/OS", "RACF", "COBOL", "CICS", "IMS", "LPAR"]
        if target:
            terms.append(target)
            name = target.split(".")[0]
            if name and name != target:
                terms.append(name)
        self.push_screen(RssScreen(terms))

    def action_graph(self):
        if not self.session.findings:
            self._log("[#ffb000]nothing to graph yet — run a scan first.[/]")
            return
        self.push_screen(GraphScreen(self))

    def action_export(self):
        if not self.session.findings:
            self._log("[#ffb000]nothing to export yet.[/]")
            return
        self.push_screen(ReportScreen(self.session))

    def action_notes(self):
        self.push_screen(NotesScreen())

    def action_auto(self):
        self._set_active("auto")
        self.action_run()

    def action_run(self):
        if self._busy:
            self._log("[#ffb000]busy — let the current run finish.[/]")
            return
        target = self._target()
        if not target:
            self._log("[#ff5555]enter a target first.[/]")
            return
        self.session = self.session if self.session.target == target else Session(target)
        self.run_worker(self._dispatch(target, self.active_module), exclusive=True)

    async def _dispatch(self, target: str, module: str):
        self._busy = True
        self._log(f"[#ffb000]▶ {module}[/] on [#b6ffce]{target}[/] …")
        t0 = time.time()
        try:
            findings: list[Finding] = []
            if module == "auto":
                self.session = await pipeline.auto_recon(
                    target, do_ports=True,
                    do_shodan=config.has_shodan(),
                    on_stage=lambda m: self._log(f"[dim]  · {m}[/]"),
                )
                self._clear_table()
                self._add_findings(self.session.findings)
                self._done(t0, len(self.session.findings))
                self._maybe_offer_chain("auto", self.session.findings)
                return
            elif module == "dns":
                findings = await dns_recon.dns_lookup(target, session=self.session)
                findings += await dns_recon.zone_transfer(target, session=self.session)
            elif module == "whois":
                findings = await whois_recon.whois_lookup(target, session=self.session)
            elif module == "subdomains":
                wl = subdomains.load_wordlist(self.opts.wordlist_path) \
                    if self.opts.wordlist_path else None
                findings = []
                if not getattr(self.opts, "subs_no_brute", False):
                    findings += await subdomains.brute_force(
                        target, wordlist=wl, concurrency=self.opts.dns_concurrency,
                        timeout=self.opts.brute_timeout, session=self.session,
                        on_progress=self._progress)
                self._log("[dim]  · querying passive sources "
                          "(HackerTarget, OTX, CertSpotter, JLDC)[/]")
                findings += await passive_subs.passive_lookup(
                    target, session=self.session)
            elif module == "crtsh":
                findings = await crtsh.crtsh_lookup(target, session=self.session)
            elif module == "email":
                seed = self.opts.email_seed or target
                findings = await email_scraper.scrape(
                    seed, max_depth=self.opts.email_depth,
                    max_pages=self.opts.email_max_pages,
                    concurrency=self.opts.spider_concurrency,
                    session=self.session, on_progress=self._progress)
            elif module == "ports":
                findings, _ = await ports.scan(
                    target, ports=self.opts.port_list(),
                    concurrency=self.opts.port_concurrency,
                    session=self.session, on_progress=self._progress)
            elif module == "shodan":
                self._busy = False
                self.push_screen(ShodanScreen(target), self._run_shodan)
                return
            elif module == "fofa":
                if not fofa.have_fofa():
                    findings = [Finding("fofa", "info",
                        "no FOFA credentials — add fofa_email and fofa_key on the "
                        "API keys screen (k) to enable infrastructure search",
                        "fofa", Severity.INFO)]
                else:
                    self._log("[dim]  · FOFA domain search[/]")
                    findings = await fofa.domain_search(target, session=self.session)
            elif module == "dork":
                self._busy = False
                self.push_screen(DorkScreen(target), self._run_dorks)
                return
            elif module == "takeover":
                # discover hosts first if we don't have any yet
                if not self.session.by_category("subdomain"):
                    self._log("[dim]  · enumerating subdomains first[/]")
                    await subdomains.brute_force(
                        target, concurrency=self.opts.dns_concurrency,
                        timeout=self.opts.brute_timeout, session=self.session,
                        on_progress=self._progress)
                    await crtsh.crtsh_lookup(target, session=self.session)
                do_http = bool(self._active_ok)
                if not do_http:
                    self._log("[#ffb000]  · passive mode (DNS only). Enable "
                              "active recon (toggle) to HTTP-confirm candidates.[/]")
                findings = await takeover.check_all(
                    self.session, do_http=do_http,
                    on_stage=lambda m: self._log(f"[dim]  · {m}[/]"))
                if not findings:
                    findings = [Finding("takeover", "info",
                                "no dangling / takeover conditions found",
                                "takeover", Severity.INFO)]
            elif module == "wayback":
                findings = await wayback.harvest(
                    target, session=self.session,
                    on_stage=lambda m: self._log(f"[dim]  · {m}[/]"))
            elif module == "github":
                findings = github_dork.dork_links(target, session=self.session)
                self._log("[dim]  · GitHub search links (no key). Click a URL, "
                          "or set github_token + use the CLI --fetch for results.[/]")
            elif module == "docmeta":
                urls = docmeta.doc_urls_from_session(self.session)
                if not urls:
                    findings = [Finding("docmeta", "info",
                                "no document URLs yet — run Google Dork or "
                                "Wayback URLs first to discover PDFs/Office docs",
                                "docmeta", Severity.INFO)]
                else:
                    self._log(f"[dim]  · harvesting {len(urls)} documents[/]")
                    findings = await docmeta.harvest(
                        urls, session=self.session,
                        on_stage=lambda m: self._log(f"[dim]  · {m}[/]"))
                    if not findings:
                        findings = [Finding("docmeta", "info",
                                    "no metadata extracted from the documents",
                                    "docmeta", Severity.INFO)]
            elif module == "harvest":
                findings = await harvester.harvest(
                    target, session=self.session, do_pgp=True,
                    on_stage=lambda m: self._log(f"[dim]  · {m}[/]"))
            elif module == "breach":
                if not hibp.has_key():
                    findings = [Finding("breach", "error",
                                "no HIBP key — add one via API keys ('k'): "
                                "hibp_api_key", "hibp", Severity.INFO)]
                else:
                    emails = hibp.emails_from_session(self.session)
                    if not emails:
                        self._log("[dim]  · no emails yet — running people "
                                  "harvest first[/]")
                        await harvester.harvest(
                            target, session=self.session,
                            on_stage=lambda m: self._log(f"[dim]  · {m}[/]"))
                        emails = hibp.emails_from_session(self.session)
                    if not emails:
                        findings = [Finding("breach", "info",
                                    "no emails found to check", "hibp",
                                    Severity.INFO)]
                    else:
                        self._log(f"[dim]  · checking {len(emails)} emails "
                                  "(paced for HIBP rate limits)[/]")
                        findings = await hibp.check_emails(
                            emails, session=self.session,
                            on_stage=lambda m: self._log(f"[dim]  · {m}[/]"))
            elif module == "buckets":
                if not self._active_ok:
                    findings = [Finding("bucket", "info",
                                "bucket discovery probes cloud providers — "
                                "enable active recon (toggle) to run it",
                                "buckets", Severity.INFO)]
                else:
                    findings = await buckets.check_all(
                        target, session=self.session,
                        on_stage=lambda m: self._log(f"[dim]  · {m}[/]"))
            elif module == "prompt":
                self._busy = False
                self.push_screen(
                    KeywordsScreen(target),
                    lambda kws: self._show_prompt(target, kws))
                return
            self._add_findings(findings)
            self._done(t0, len(findings))
            self._maybe_offer_chain(module, findings)
        except Exception as e:  # noqa: BLE001
            self._log(f"[#ff5555]error: {e}[/]")
        finally:
            self._busy = False

    def _show_prompt(self, target: str, keywords):
        kws = keywords or None
        prompt = ai_osint.build_prompt(target, self.session, focus=kws)
        self.push_screen(TextScreen("AI deep-research OSINT prompt", prompt))
        if kws:
            self._log(f"[green]prompt generated, focused on: "
                      f"{', '.join(kws)} (copy from the panel).[/]")
        else:
            self._log("[green]prompt generated (copy from the panel).[/]")

    def _maybe_offer_chain(self, module: str, findings: list[Finding]):
        """If a run produced new subdomains, propose chaining them."""
        if not self.opts.chain_enabled:
            return
        if module not in ("subdomains", "crtsh", "auto"):
            return
        if not any(f.category == "subdomain" and
                   f.key not in ("wildcard", "crt.sh", "error") for f in findings):
            return
        plan = chaining.build_plan(self.session, cap=self.opts.chain_cap,
                                   already_seeded=self._chained_hosts)
        if not plan["hosts"]:
            return
        self.push_screen(ChainConfirmScreen(plan), self._run_chain)

    def _run_chain(self, result):
        if not result:
            self._log("[dim]chaining skipped.[/]")
            return
        plan = result["plan"]
        self.run_worker(self._chain_worker(plan), exclusive=True)

    async def _chain_worker(self, plan):
        self._busy = True
        self._log(f"[#ffb000]▶ chaining[/] {len(plan['hosts'])} subdomain(s) …")
        t0 = time.time()
        try:
            eng = self.opts.preview_engine if self.opts.preview_engine in (
                "google", "bing", "duckduckgo") else "google"
            findings = await chaining.run_chain(
                self.session, plan, engine=eng,
                do_links=True, do_spider=True, spider_depth=1,
                spider_concurrency=self.opts.spider_concurrency,
                on_stage=lambda m: self._log(f"[dim]  · {m}[/]"))
            for h in plan["hosts"]:
                self._chained_hosts.add(h)
            self._add_findings(findings)
            self._done(t0, len(findings))
        except Exception as e:  # noqa: BLE001
            self._log(f"[#ff5555]chain error: {e}[/]")
        finally:
            self._busy = False

    def _run_dorks(self, result):
        if not result:
            self._log("[dim]dork run cancelled.[/]")
            return
        mode = result.get("mode", "api")
        queries = result.get("queries", [])
        if not queries:
            self._log("[#ffb000]no dorks ticked.[/]")
            return
        if mode == "links":
            findings = google_dork.links_for_queries(queries, session=self.session)
            self._add_findings(findings)
            self._log(f"[green]✓ {len(findings)} dork links[/] "
                      "[dim](no key used — click a URL, or press 'p' on a row to "
                      "preview; 'e' to export).[/]")
            return
        if mode == "fetch":
            # prefer a self-hosted SearXNG if configured (reliable, keyless),
            # otherwise fall back to DuckDuckGo scraping
            from ..engine import searx as searxmod
            self._fetch_dorks(queries,
                              engine="searx" if searxmod.has_searx() else "ddg")
            return
        # "api" mode: same Title/Link/Snippet renderer, via the Google API
        self._fetch_dorks(queries, engine="api")

    def _fetch_dorks(self, queries, engine="ddg"):
        """Fetch real Title/Link/Snippet results into the results screen.

        engine="ddg" is keyless (DuckDuckGo); engine="api" uses Google Custom
        Search if a key is configured. Both are active recon, so gated once.
        """
        def go():
            self.push_screen(DorkResultsScreen(
                queries, engine=engine, session=self.session,
                limit=self.opts.preview_limit))
        if self._active_ok or config.get_setting("allow_active_fetch", False):
            go()
            return

        def after(res):
            if not res:
                self._log("[dim]dork fetch cancelled.[/]")
                return
            self._active_ok = True
            if res.get("remember"):
                config.set_setting("allow_active_fetch", True)
            go()
        self.push_screen(ActiveConfirmScreen(), after)

    def _run_shodan(self, queries):
        if not queries:
            self._log("[dim]shodan run cancelled (nothing selected).[/]")
            return
        if not config.has_shodan():
            self._log("[#ffb000]no Shodan key set — press 'k' to add one.[/]")
        self.run_worker(self._shodan_worker(queries), exclusive=True)

    async def _shodan_worker(self, queries):
        self._busy = True
        self._log(f"[#ffb000]▶ shodan[/] — {len(queries)} query(ies) …")
        t0 = time.time()
        total = 0
        try:
            for q in queries:
                self._log(f"[dim]  · {q}[/]")
                findings = await shodan_recon.search(q, session=self.session)
                self._add_findings(findings)
                total += len([f for f in findings if f.key not in ("error", "shodan")])
            self._done(t0, total)
        except Exception as e:  # noqa: BLE001
            self._log(f"[#ff5555]error: {e}[/]")
        finally:
            self._busy = False

    def _done(self, t0: float, n: int):
        self._log(f"[green]✓ {n} findings[/] [dim]({time.time()-t0:.1f}s) — "
                  f"press 'e' to export.[/]")


def run():
    EZReconApp().run()


if __name__ == "__main__":
    run()
