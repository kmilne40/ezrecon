"""EZRecon Textual application.

A phosphor-themed TUI: pick a module from the sidebar, type a target, and
results stream into the findings table. Google Dork opens the Listing 6-1
multi-select. Auto-Recon runs the whole passive chain. Reports export to disk.
"""

from __future__ import annotations

import time
from pathlib import Path

from rich.text import Text
from textual import on
from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import (
    Button,
    Checkbox,
    DataTable,
    Footer,
    Header,
    Input,
    Label,
    RichLog,
    Static,
)


class TickBox(Checkbox):
    """A checkbox that shows a tick (✓) when on instead of an X."""

    BUTTON_INNER = "✓"

from .. import __version__, config
from ..engine import (
    ai_osint,
    buckets,
    chaining,
    crtsh,
    dns_recon,
    docmeta,
    email_scraper,
    github_dork,
    google_dork,
    graph as graphmod,
    harvester,
    hibp,
    pipeline,
    pivots as pivotmod,
    ports,
    shodan_recon,
    subdomains,
    takeover,
    wayback,
    webintel,
    whois_recon,
)
from ..models import Finding, Session, Severity
from ..options import Options
from ..report import reporter

BANNER = r"""
     ____                     eZrecon
 ___|_  /_ _ ___ __ ___ _ _   passive recon for the
/ -_)/ /| '_/ -_) _/ _ \ ' \  mainframe hunter
\___/___|_| \___\__\___/_||_| {v}
""".strip("\n")

SEV_COLOUR = {"high": "red", "medium": "#ffb000", "low": "#33ff66", "info": "#1f8a3a"}

MODULES = [
    ("auto", "Auto-Recon"),
    ("dns", "DNS Records"),
    ("whois", "WHOIS"),
    ("subdomains", "Subdomains"),
    ("crtsh", "crt.sh (CT)"),
    ("email", "Email Spider"),
    ("ports", "Banner Grab"),
    ("shodan", "Shodan Sweep"),
    ("dork", "Google Dork"),
    ("takeover", "Dangling DNS"),
    ("wayback", "Wayback URLs"),
    ("github", "GitHub Dorks"),
    ("docmeta", "Doc Metadata"),
    ("harvest", "People Harvest"),
    ("breach", "Breach Check"),
    ("buckets", "Cloud Buckets"),
    ("prompt", "AI Prompt"),
]


class DorkScreen(ModalScreen):
    """The Listing 6-1 multi-select for Google dorks."""

    def __init__(self, domain: str):
        super().__init__()
        self.domain = domain
        self.dorks = google_dork.load_catalogue()

    def compose(self) -> ComposeResult:
        with Vertical(id="modal"):
            yield Static(f"Google Dork selection — site:{self.domain}",
                         classes="modal-title")
            yield Static("[dim]Tick the queries to use and edit any of them. "
                         "'Open as links' needs no API key — it builds clickable "
                         "search URLs. 'Run via API' fetches results (needs a key).[/]")
            with VerticalScroll(id="dork-list"):
                for d in self.dorks:
                    built = google_dork.build_query(d, self.domain)
                    with Horizontal(classes="dork-row"):
                        yield TickBox(value=(d.enabled or d.id == 1),
                                      id=f"dchk-{d.id}")
                        yield Input(value=built, id=f"dq-{d.id}")
            with Horizontal(classes="modal-buttons"):
                yield Button("Cancel", id="dork-cancel")
                yield Button("Open as links", id="dork-links")
                yield Button("Fetch results (no key)", id="dork-fetch",
                             classes="primary")
                yield Button("Via API", id="dork-run")

    def _collect(self) -> list[str]:
        out: list[str] = []
        for d in self.dorks:
            if self.query_one(f"#dchk-{d.id}", TickBox).value:
                val = self.query_one(f"#dq-{d.id}", Input).value.strip()
                if val:
                    out.append(val)
        seen: list[str] = []
        for q in out:
            if q not in seen:
                seen.append(q)
        return seen

    @on(Button.Pressed, "#dork-cancel")
    def _cancel(self):
        self.dismiss(None)

    @on(Button.Pressed, "#dork-links")
    def _links(self):
        self.dismiss({"mode": "links", "queries": self._collect()})

    @on(Button.Pressed, "#dork-fetch")
    def _fetch(self):
        self.dismiss({"mode": "fetch", "queries": self._collect()})

    @on(Button.Pressed, "#dork-run")
    def _run(self):
        self.dismiss({"mode": "api", "queries": self._collect()})


class DorkResultsScreen(ModalScreen):
    """Keyless dork results rendered as a Title / Link / Snippet list."""

    BINDINGS = [
        ("escape", "close", "Close"),
        ("o", "open", "Open selected"),
    ]

    def __init__(self, queries: list[str], engine: str, session, limit: int = 10):
        super().__init__()
        self.queries = queries
        self.engine = engine
        self.session = session
        self.limit = limit
        self._urls: list[str] = []

    def compose(self) -> ComposeResult:
        with Vertical(id="modal-wide"):
            yield Static("Google dork results", classes="modal-title")
            src = {"ddg": "DuckDuckGo (no key)",
                   "searx": "SearXNG (self-hosted, no key)",
                   "api": "Google API"}.get(self.engine, self.engine)
            yield Static(f"[dim]source: {src} · [b]o[/b] open a link's host · "
                         "[b]Esc[/b] close[/]")
            with VerticalScroll(id="dork-results"):
                yield Static("Fetching results…", id="dork-results-body")
            with Horizontal(classes="modal-buttons"):
                yield Button("Close", id="dork-results-close")

    def on_mount(self):
        self.run_worker(self._fetch_all(), exclusive=True)

    async def _fetch_all(self):
        import asyncio
        body = self.query_one("#dork-results-body", Static)
        blocks: list[str] = []
        hits = 0
        blocked = 0
        for i, q in enumerate(self.queries):
            self.session.record_query(q)
            body.update(("\n\n".join(blocks) + f"\n\n[dim]searching {q} …[/]")
                        if blocks else f"[dim]searching {q} …[/]")
            results, err = await webintel.get_results(
                q, engine=self.engine, limit=self.limit)
            hits += len(results)
            if not results and ("202" in err or "429" in err or "rate" in err.lower()):
                blocked += 1
            blocks.append(self._format_block(q, results, err))
            body.update("\n\n".join(blocks))
            # pace requests so upstream engines' anti-bot doesn't trip on a
            # burst. SearXNG rate-limits its own engines (Google/DDG/Brave) when
            # site: dorks arrive too fast, so it needs pacing too, not just DDG.
            if i < len(self.queries) - 1:
                if self.engine == "searx":
                    await asyncio.sleep(float(config.get_setting("searx_pace", 2.0)))
                elif self.engine == "ddg":
                    await asyncio.sleep(1.2)
        if not blocks:
            body.update("[#ffb000]No dorks selected.[/]")
            return
        if hits == 0 and blocked and self.engine == "ddg":
            blocks.append(
                "[#ffb000]Every query was blocked by DuckDuckGo's anti-bot "
                "(HTTP 202).[/] Wait a minute and retry, run fewer dorks at "
                "once, or add a Google API key and use [b]Via API[/b] for "
                "reliable results.")
            body.update("\n\n".join(blocks))
        elif hits == 0 and blocked and self.engine == "searx":
            blocks.append(
                "[#ffb000]SearXNG's upstream engines were rate-limited.[/] "
                "Give it a minute and retry, raise the pace with "
                "[b]config set-setting searx_pace 3[/b], or pin engines that "
                "tolerate bursts (Bing, Google) in the instance settings.yml.")
            body.update("\n\n".join(blocks))

    def _format_block(self, query: str, results, err: str) -> str:
        lines = [f"[#ffb000]Searching for:[/] [b]{_esc(query)}[/b]", ""]
        if not results:
            lines.append(f"  [dim]{_esc(err) or 'no results'}[/]")
            return "\n".join(lines)
        for r in results:
            n = len(self._urls) + 1
            self._urls.append(r.url)
            # record as a finding so it also lands in the table/graph/report
            self.session.add(Finding(
                "dork", r.url, f"{r.title} :: {r.snippet[:160]}",
                f"dork-result:{self.engine}", Severity.LOW,
                meta={"url": r.url, "query": query, "title": r.title,
                      "snippet": r.snippet}))
            lines.append(f"  [#33ff66]{n}.[/] [b]Title:[/b] {_esc(r.title)}")
            lines.append(f"     [b]Link:[/b] [#66d9ff underline]{_esc(r.url)}[/]")
            if r.snippet:
                lines.append(f"     [b]Snippet:[/b] {_esc(r.snippet)}")
            lines.append("")
        return "\n".join(lines)

    def action_open(self):
        if self._urls:
            _open_in_browser(self.app, self._urls[0])

    def action_close(self):
        self.dismiss()

    @on(Button.Pressed, "#dork-results-close")
    def _close(self):
        self.dismiss()


def _esc(s: str) -> str:
    """Escape Rich markup so result text can't break the console markup."""
    return (s or "").replace("[", r"\[")


class ShodanScreen(ModalScreen):
    """Tick-box + editable Shodan query builder.

    Each built-in mainframe query gets a checkbox and an editable field, so you
    can toggle it, tweak the syntax, or type your own in the blank rows. Ticked
    rows with non-empty text are the queries that run.
    """

    CUSTOM_ROWS = 3

    def __init__(self, domain: str):
        super().__init__()
        self.domain = domain
        self.queries = shodan_recon.mainframe_queries()

    def compose(self) -> ComposeResult:
        with Vertical(id="modal"):
            yield Static("Shodan query selection", classes="modal-title")
            yield Static("[dim]Tick the queries to run and edit any of them. "
                         "Blank rows at the bottom are for your own. Use "
                         "hostname: or org: to scope to a target.[/]")
            with VerticalScroll(id="shodan-list"):
                for i, q in enumerate(self.queries):
                    with Horizontal(classes="squery-row"):
                        yield TickBox(value=(i < 3), id=f"schk-{i}")
                        yield Input(value=q["query"], id=f"sq-{i}")
                for c in range(self.CUSTOM_ROWS):
                    with Horizontal(classes="squery-row"):
                        yield TickBox(value=False, id=f"schk-c{c}")
                        yield Input(placeholder="custom Shodan query…",
                                    id=f"sq-c{c}")
            with Horizontal(classes="modal-buttons"):
                yield Button("Cancel", id="shodan-cancel")
                yield Button("Run queries", id="shodan-run", classes="primary")

    def _collect(self) -> list[str]:
        out: list[str] = []
        for i in range(len(self.queries)):
            if self.query_one(f"#schk-{i}", TickBox).value:
                val = self.query_one(f"#sq-{i}", Input).value.strip()
                if val:
                    out.append(val)
        for c in range(self.CUSTOM_ROWS):
            if self.query_one(f"#schk-c{c}", TickBox).value:
                val = self.query_one(f"#sq-c{c}", Input).value.strip()
                if val:
                    out.append(val)
        # de-dupe, preserve order
        seen: list[str] = []
        for q in out:
            if q not in seen:
                seen.append(q)
        return seen

    @on(Button.Pressed, "#shodan-cancel")
    def _cancel(self):
        self.dismiss(None)

    @on(Button.Pressed, "#shodan-run")
    def _run(self):
        self.dismiss(self._collect())


class KeysScreen(ModalScreen):
    """API-key entry."""

    def compose(self) -> ComposeResult:
        with Vertical(id="modal"):
            yield Static("API keys", classes="modal-title")
            yield Label("Google API key")
            yield Input(value=config.get_key("google_api_key"),
                        password=True, id="k-gkey")
            yield Label("Google CSE ID (cx)")
            yield Input(value=config.get_key("google_cse_id"), id="k-gcse")
            yield Static("[dim]No key? Enable the Custom Search API + make a "
                         "Programmable Search Engine (search the whole web), then "
                         "'Save & test'. See the README for the exact steps.[/]")
            yield Label("Shodan API key")
            yield Input(value=config.get_key("shodan_api_key"),
                        password=True, id="k-shodan")
            yield Label("Anthropic API key (optional — for preview summaries)")
            yield Input(value=config.get_key("anthropic_api_key"),
                        password=True, id="k-anthropic")
            yield Label("HIBP API key (optional — breach checks)")
            yield Input(value=config.get_key("hibp_api_key"),
                        password=True, id="k-hibp")
            yield Label("GitHub token (optional — code-search API)")
            yield Input(value=config.get_key("github_token"),
                        password=True, id="k-github")
            yield Static("", id="keys-status")
            with Horizontal(classes="modal-buttons"):
                yield Button("Cancel", id="keys-cancel")
                yield Button("Save & test Google", id="keys-test")
                yield Button("Save", id="keys-save", classes="primary")

    def _persist(self):
        config.set_key("google_api_key", self.query_one("#k-gkey", Input).value)
        config.set_key("google_cse_id", self.query_one("#k-gcse", Input).value)
        config.set_key("shodan_api_key", self.query_one("#k-shodan", Input).value)
        config.set_key("anthropic_api_key",
                       self.query_one("#k-anthropic", Input).value)
        config.set_key("hibp_api_key", self.query_one("#k-hibp", Input).value)
        config.set_key("github_token", self.query_one("#k-github", Input).value)

    @on(Button.Pressed, "#keys-cancel")
    def _cancel(self):
        self.dismiss(False)

    @on(Button.Pressed, "#keys-test")
    def _test(self):
        self._persist()
        self.query_one("#keys-status", Static).update(
            "[#ffb000]testing Google Custom Search …[/]")
        self.run_worker(self._do_test(), exclusive=True)

    async def _do_test(self):
        verdict = await google_dork.check_credentials()
        colour = "green" if verdict["ok"] else "#ff5555"
        self.query_one("#keys-status", Static).update(
            f"[{colour}]{verdict['message']}[/]")

    @on(Button.Pressed, "#keys-save")
    def _save(self):
        self._persist()
        self.dismiss(True)


class OptionsScreen(ModalScreen):
    """Editable search options: wordlist, depths, ports, preview, chaining."""

    def __init__(self, opts: Options):
        super().__init__()
        self.opts = opts

    def _row(self, label: str, wid):
        return (Label(label), wid)

    def compose(self) -> ComposeResult:
        o = self.opts
        with Vertical(id="modal"):
            yield Static("Search options", classes="modal-title")
            with VerticalScroll(id="opts-list"):
                yield Static("[#ffb000]Appearance[/]")
                yield Label("Colour theme (applies immediately)")
                with Horizontal(id="opts-theme-row"):
                    from .themes import ORDER, LABELS
                    for tid in ORDER:
                        yield Button(LABELS[tid].split(" —")[0].split(" (")[0],
                                     id=f"theme-{tid}", classes="theme-btn")
                yield Static("", id="opts-theme-note")

                yield Static("[#ffb000]Subdomains[/]")
                yield Label("Wordlist path (blank = built-in list)")
                yield Input(value=o.wordlist_path, id="o-wordlist",
                            placeholder="/path/to/wordlist.txt")
                yield Label("DNS concurrency")
                yield Input(value=str(o.dns_concurrency), id="o-dnsconc")
                yield Label("Brute per-query timeout (s)")
                yield Input(value=str(o.brute_timeout), id="o-bruteto")

                yield Static("[#ffb000]Email spider[/]")
                yield Label("Seed URL/host (blank = target)")
                yield Input(value=o.email_seed, id="o-seed",
                            placeholder="https://sub.target.com")
                yield Label("Crawl depth")
                yield Input(value=str(o.email_depth), id="o-depth")
                yield Label("Max pages")
                yield Input(value=str(o.email_max_pages), id="o-maxpages")
                yield Label("Spider concurrency")
                yield Input(value=str(o.spider_concurrency), id="o-spiderconc")
                yield Label("Known emails (comma-separated, added to the dossier)")
                yield Input(value=", ".join(o.known_emails), id="o-emails",
                            placeholder="a@target.com, b@target.com")

                yield Static("[#ffb000]Ports (banner grab)[/]")
                yield Label("Ports (blank = mainframe profile)")
                yield Input(value=o.ports, id="o-ports",
                            placeholder="21,23,992,175,443,50000")
                yield Label("Port concurrency")
                yield Input(value=str(o.port_concurrency), id="o-portconc")

                yield Static("[#ffb000]Preview[/]")
                yield Label("Engine (auto/ddg/api)")
                yield Input(value=o.preview_engine, id="o-pvengine")
                yield Label("Result limit")
                yield Input(value=str(o.preview_limit), id="o-pvlimit")

                yield Static("[#ffb000]Chaining[/]")
                yield TickBox("Chain discovered subdomains into dorks + spider",
                              value=o.chain_enabled, id="o-chain")
                yield Label("Chain cap (max subdomains)")
                yield Input(value=str(o.chain_cap), id="o-chaincap")
            with Horizontal(classes="modal-buttons"):
                yield Button("Cancel", id="opts-cancel")
                yield Button("Save", id="opts-save", classes="primary")

    def _int(self, wid_id: str, default: int) -> int:
        try:
            return int(self.query_one(wid_id, Input).value.strip())
        except (ValueError, AttributeError):
            return default

    def _float(self, wid_id: str, default: float) -> float:
        try:
            return float(self.query_one(wid_id, Input).value.strip())
        except (ValueError, AttributeError):
            return default

    @on(Button.Pressed, ".theme-btn")
    def _theme(self, ev):
        from .themes import THEMES, LABELS
        tid = ev.button.id.replace("theme-", "")
        if tid in THEMES:
            try:
                self.app.theme = tid
                config.set_setting("theme", tid)
                self.query_one("#opts-theme-note", Static).update(
                    f"[$success]theme set to {LABELS[tid]}[/]")
            except Exception as e:  # noqa: BLE001
                self.query_one("#opts-theme-note", Static).update(
                    f"[red]could not apply theme: {e}[/]")

    @on(Button.Pressed, "#opts-cancel")
    def _cancel(self):
        self.dismiss(None)

    @on(Button.Pressed, "#opts-save")
    def _save(self):
        o = self.opts
        o.wordlist_path = self.query_one("#o-wordlist", Input).value.strip()
        o.dns_concurrency = self._int("#o-dnsconc", o.dns_concurrency)
        o.brute_timeout = self._float("#o-bruteto", o.brute_timeout)
        o.email_seed = self.query_one("#o-seed", Input).value.strip()
        o.email_depth = self._int("#o-depth", o.email_depth)
        o.email_max_pages = self._int("#o-maxpages", o.email_max_pages)
        o.spider_concurrency = self._int("#o-spiderconc", o.spider_concurrency)
        o.known_emails = [e.strip() for e in
                          self.query_one("#o-emails", Input).value.split(",")
                          if e.strip()]
        o.ports = self.query_one("#o-ports", Input).value.strip()
        o.port_concurrency = self._int("#o-portconc", o.port_concurrency)
        eng = self.query_one("#o-pvengine", Input).value.strip().lower()
        o.preview_engine = eng if eng in ("auto", "ddg", "api") else "auto"
        o.preview_limit = self._int("#o-pvlimit", o.preview_limit)
        o.chain_enabled = self.query_one("#o-chain", TickBox).value
        o.chain_cap = max(1, self._int("#o-chaincap", o.chain_cap))
        # record known emails into the session-independent dossier note is done by app
        self.dismiss(o)


class ChainConfirmScreen(ModalScreen):
    """Show what chaining will do and let the user confirm."""

    def __init__(self, plan: dict):
        super().__init__()
        self.plan = plan

    def compose(self) -> ComposeResult:
        p = self.plan
        note = (f" (capped from {p['total_hosts']})" if p["capped"] else "")
        lines = [
            f"[#ffb000]Chain {len(p['hosts'])} discovered subdomain(s){note}[/]",
            "",
            "This will, with no API calls:",
            f"  • add [b]{len(p['dork_queries'])}[/b] `site:` dork links",
            f"  • run the email spider on [b]{len(p['spider_seeds'])}[/b] seed(s)",
            "",
            "[dim]Hosts:[/]",
        ]
        lines += [f"  • {h}" for h in p["hosts"]]
        with Vertical(id="modal"):
            yield Static("Chain discoveries?", classes="modal-title")
            with VerticalScroll():
                yield Static("\n".join(lines))
            with Horizontal(classes="modal-buttons"):
                yield Button("Skip", id="chain-skip")
                yield Button("Run chain", id="chain-run", classes="primary")

    @on(Button.Pressed, "#chain-skip")
    def _skip(self):
        self.dismiss(None)

    @on(Button.Pressed, "#chain-run")
    def _run(self):
        self.dismiss({"plan": self.plan})


class PivotMenuScreen(ModalScreen):
    """Choose a pivot to run against a selected graph node."""

    def __init__(self, node):
        super().__init__()
        self.node = node
        self.options = pivotmod.pivots_for(node.kind)

    def compose(self) -> ComposeResult:
        with Vertical(id="modal"):
            yield Static(f"Pivot — {self.node.kind}: {self.node.label}",
                         classes="modal-title")
            if not self.options:
                yield Static("[dim]No pivots available for this node type.[/]")
            with VerticalScroll():
                for pid, label, active in self.options:
                    tag = " [#ffb000][active][/]" if active else " [dim][passive][/]"
                    yield Button(f"{label}{tag}", id=f"pv-{pid}")
            with Horizontal(classes="modal-buttons"):
                yield Button("Cancel", id="pv-cancel")

    @on(Button.Pressed)
    def _pick(self, event: Button.Pressed):
        bid = event.button.id or ""
        if bid == "pv-cancel":
            self.dismiss(None)
        elif bid.startswith("pv-"):
            pid = bid[3:]
            active = next((a for (i, _l, a) in self.options if i == pid), False)
            self.dismiss({"pivot": pid, "active": active, "node": self.node})


class GraphScreen(ModalScreen):
    """Navigable entity graph with live pivots (the Maltego-style view)."""

    BINDINGS = [
        ("escape", "close", "Close"),
        ("enter", "pivot", "Pivot"),
        ("x", "export", "Export HTML"),
    ]

    def __init__(self, app_ref):
        super().__init__()
        self._app = app_ref
        self.graph = None

    def compose(self) -> ComposeResult:
        with Vertical(id="modal-wide"):
            yield Static("Entity graph", classes="modal-title")
            yield Static("[dim]Select a node · [b]Enter[/b] pivot · "
                         "[b]x[/b] export HTML · [b]Esc[/b] close[/]")
            with Horizontal(id="graph-body"):
                with Vertical(id="graph-list-pane"):
                    yield DataTable(id="graph-nodes", cursor_type="row")
                with VerticalScroll(id="graph-detail"):
                    yield Static("Building graph…", id="graph-detail-body")
            with Horizontal(classes="modal-buttons"):
                yield Button("Close", id="graph-close")

    def on_mount(self):
        t = self.query_one("#graph-nodes", DataTable)
        t.add_columns("Kind", "Node")
        self.rebuild()

    def rebuild(self):
        self.graph = graphmod.build_graph(self._app.session)
        t = self.query_one("#graph-nodes", DataTable)
        t.clear()
        self._gnodes = list(self.graph.nodes.values())
        # sort by kind for readability
        order = {"domain": 0, "subdomain": 1, "ip": 2, "asn": 3, "port": 4,
                 "email": 5, "dork": 6}
        self._gnodes.sort(key=lambda n: (order.get(n.kind, 9), n.label))
        for n in self._gnodes:
            t.add_row(Text(n.kind, style=n.colour), Text(n.label[:48]))
        self.query_one("#graph-detail-body", Static).update(
            f"[green]{len(self.graph.nodes)} nodes · "
            f"{len(self.graph.edges)} edges[/]\n\nSelect a node to see its "
            "connections, then press Enter to pivot.")

    def _current(self):
        t = self.query_one("#graph-nodes", DataTable)
        if 0 <= t.cursor_row < len(self._gnodes):
            return self._gnodes[t.cursor_row]
        return None

    @on(DataTable.RowHighlighted, "#graph-nodes")
    def _hl(self, event):
        node = self._current()
        if node:
            self._show(node)

    def _show(self, node):
        lines = [f"[b]{node.kind}[/b]: {node.label}", ""]
        for k in ("asn", "prefix", "as_name", "service", "banner", "hint",
                  "url", "role"):
            v = node.meta.get(k)
            if v:
                lines.append(f"[dim]{k}:[/] {v}")
        nb = self.graph.neighbours(node.id)
        if nb:
            lines += ["", f"[#ffb000]Connections ({len(nb)}):[/]"]
            for other, rel, direction in nb[:30]:
                arrow = "→" if direction == "->" else "←"
                lines.append(f"  {arrow} [{other.colour}]{other.kind}[/] "
                             f"{other.label}  [dim]({rel})[/]")
        piv = pivotmod.pivots_for(node.kind)
        if piv:
            lines += ["", "[dim]Press Enter to pivot: " +
                      ", ".join(p[1] for p in piv) + "[/]"]
        self.query_one("#graph-detail-body", Static).update("\n".join(lines))

    def action_pivot(self):
        node = self._current()
        if not node:
            return
        if not pivotmod.pivots_for(node.kind):
            return
        self.app.push_screen(PivotMenuScreen(node), self._do_pivot)

    def _do_pivot(self, result):
        if not result:
            return
        pid, active, node = result["pivot"], result["active"], result["node"]
        if active and not (self._app._active_ok or
                           config.get_setting("allow_active_fetch", False)):
            def after(res):
                if not res:
                    return
                self._app._active_ok = True
                if res.get("remember"):
                    config.set_setting("allow_active_fetch", True)
                self._launch_pivot(pid, node)
            self.app.push_screen(ActiveConfirmScreen(), after)
        else:
            self._launch_pivot(pid, node)

    def _launch_pivot(self, pid, node):
        self.run_worker(self._pivot_worker(pid, node), exclusive=True)

    async def _pivot_worker(self, pid, node):
        detail = self.query_one("#graph-detail-body", Static)
        detail.update(f"Running pivot [b]{pid}[/] on {node.label} …")
        try:
            findings = await pivotmod.run_pivot(pid, node, self._app.session)
            self._app._add_findings(findings)
            self.rebuild()
            self.query_one("#graph-detail-body", Static).update(
                f"[green]pivot added {len(findings)} finding(s).[/] "
                "Graph updated.")
        except Exception as e:  # noqa: BLE001
            detail.update(f"[#ff5555]pivot error: {e}[/]")

    def action_export(self):
        try:
            from ..report.graph_html import graph_to_html
            out = config.output_dir() / \
                f"ezrecon_{self._app.session.target.replace('.', '_')}_graph.html"
            out.write_text(graph_to_html(self.graph, self._app.session))
            self.query_one("#graph-detail-body", Static).update(
                f"[green]graph exported:[/] {out}")
        except Exception as e:  # noqa: BLE001
            self.query_one("#graph-detail-body", Static).update(
                f"[#ff5555]export failed: {e}[/]")

    def action_close(self):
        self.dismiss()

    @on(Button.Pressed, "#graph-close")
    def _close(self):
        self.dismiss()


class TextScreen(ModalScreen):
    """Scrollable read-only text (used for the AI prompt)."""

    def __init__(self, title: str, body: str):
        super().__init__()
        self._title = title
        self._body = body

    def compose(self) -> ComposeResult:
        with Vertical(id="modal"):
            yield Static(self._title, classes="modal-title")
            with VerticalScroll():
                yield Static(self._body)
            with Horizontal(classes="modal-buttons"):
                yield Button("Close", id="text-close", classes="primary")

    @on(Button.Pressed, "#text-close")
    def _close(self):
        self.dismiss()


class ActiveConfirmScreen(ModalScreen):
    """Explicit opt-in before EZRecon reaches out to third-party pages."""

    def compose(self) -> ComposeResult:
        with Vertical(id="modal"):
            yield Static("Active reconnaissance — confirm", classes="modal-title")
            yield Static(
                "[#ffb000]The preview pane fetches third-party search results and "
                "pages.[/] This connects to hosts you may not own, so it is "
                "active recon, not passive. Only proceed against targets you are "
                "authorised to assess.")
            yield TickBox("Don't ask again (remember this choice)", id="ac-remember")
            with Horizontal(classes="modal-buttons"):
                yield Button("Cancel", id="ac-cancel")
                yield Button("Proceed", id="ac-ok", classes="primary")

    @on(Button.Pressed, "#ac-cancel")
    def _cancel(self):
        self.dismiss(None)

    @on(Button.Pressed, "#ac-ok")
    def _ok(self):
        self.dismiss({"remember": self.query_one("#ac-remember", TickBox).value})


class PreviewScreen(ModalScreen):
    """Fetch real results for a dork, inspect pages, summarise in context."""

    BINDINGS = [
        ("escape", "close", "Close"),
        ("o", "open_browser", "Open in browser"),
        ("s", "llm", "LLM summary"),
    ]

    def __init__(self, query: str, engine: str = "auto"):
        super().__init__()
        self.dork_query = query
        self.engine = engine
        self.terms = webintel.terms_from_query(query)
        self.results: list = []
        self.current = None  # PageIntel

    def compose(self) -> ComposeResult:
        with Vertical(id="modal-wide"):
            yield Static(f"Preview — {self.dork_query}", classes="modal-title")
            yield Static("[dim]Enter/click a result to fetch & analyse it · "
                         "[b]o[/b] open in browser · [b]s[/b] LLM summary · "
                         "[b]Esc[/b] close[/]")
            with Horizontal(id="preview-body"):
                with Vertical(id="preview-list-pane"):
                    yield DataTable(id="preview-results", cursor_type="row")
                with VerticalScroll(id="preview-detail"):
                    yield Static("Loading results…", id="preview-detail-body")
            with Horizontal(classes="modal-buttons"):
                yield Button("Close", id="preview-close")

    def on_mount(self):
        t = self.query_one("#preview-results", DataTable)
        t.add_columns("#", "Title", "URL")
        self.run_worker(self._load(), exclusive=True)

    async def _load(self):
        results, err = await webintel.get_results(self.dork_query, engine=self.engine)
        self.results = results
        t = self.query_one("#preview-results", DataTable)
        for i, r in enumerate(results, 1):
            t.add_row(str(i), (r.title or r.url)[:60], r.url[:80])
        detail = self.query_one("#preview-detail-body", Static)
        if not results:
            detail.update(f"[#ff5555]No results.[/] {err or ''}\n\n"
                          "DuckDuckGo can rate-limit; you can still open the "
                          "search in a browser with [b]o[/b].")
        else:
            src = results[0].source
            detail.update(f"[green]{len(results)} results[/] via {src}. "
                          "Select one to fetch and analyse it.")

    @on(DataTable.RowSelected, "#preview-results")
    def _pick(self, event: DataTable.RowSelected):
        idx = event.cursor_row
        if 0 <= idx < len(self.results):
            self.run_worker(self._fetch(idx), exclusive=True)

    async def _fetch(self, idx: int):
        r = self.results[idx]
        detail = self.query_one("#preview-detail-body", Static)
        detail.update(f"Fetching {r.url} …")
        intel = await webintel.fetch_page(r.url, terms=self.terms)
        self.current = intel
        detail.update(self._detail_text(intel))

    def _detail_text(self, intel, llm: str = "") -> str:
        if intel.error:
            return (f"[#ff5555]{intel.error}[/]\n\n{intel.url}\n\n"
                    "Press [b]o[/b] to open it in a browser instead.")
        lines = [
            f"[b]{intel.title or '(no title)'}[/b]",
            f"[dim]{intel.final_url or intel.url}[/]",
            f"[dim]HTTP {intel.status} · {intel.content_type} · "
            f"{intel.size} bytes[/]",
            "",
        ]
        if intel.description:
            lines += [f"[#b6ffce]{intel.description}[/]", ""]
        if intel.contexts:
            lines.append(f"[#ffb000]Terms in context ({len(intel.contexts)}):[/]")
            for h in intel.contexts:
                snip = h["snippet"].replace("❱", "[b #33ff66]").replace("❰", "[/]")
                lines.append(f"  • [b]{h['term']}[/b]: {snip}")
        else:
            lines.append("[dim]No highlighted terms found on the page.[/]")
        if llm:
            lines += ["", "[#ffb000]LLM summary:[/]", llm]
        elif webintel.has_llm():
            lines += ["", "[dim]Press [b]s[/b] for an LLM summary.[/]"]
        return "\n".join(lines)

    def action_llm(self):
        if not webintel.has_llm():
            self.app.bell()
            self.query_one("#preview-detail-body", Static).update(
                "[#ffb000]No Anthropic API key set (press 'k' on the main "
                "screen to add one).[/]")
            return
        if not self.current:
            return
        self.run_worker(self._do_llm(), exclusive=True, thread=True)

    async def _do_llm(self):
        detail = self.query_one("#preview-detail-body", Static)
        detail.update(self._detail_text(self.current) + "\n\n[dim]summarising…[/]")
        import asyncio
        loop = asyncio.get_event_loop()
        summary = await loop.run_in_executor(
            None, webintel.summarise_llm, self.current, self.dork_query)
        detail.update(self._detail_text(self.current, llm=summary))

    def action_open_browser(self):
        url = ""
        if self.current:
            url = self.current.final_url or self.current.url
        else:
            t = self.query_one("#preview-results", DataTable)
            if self.results and 0 <= t.cursor_row < len(self.results):
                url = self.results[t.cursor_row].url
        if not url:
            url = f"https://duckduckgo.com/?q={self.dork_query}"
        _open_in_browser(self.app, url)

    def action_close(self):
        self.dismiss()

    @on(Button.Pressed, "#preview-close")
    def _close(self):
        self.dismiss()


def _open_in_browser(app, url: str) -> None:
    """Open a URL in the system browser, suspending the TUI first."""
    import webbrowser

    try:
        with app.suspend():
            webbrowser.open(url)
    except Exception:  # noqa: BLE001 - headless / no browser
        try:
            webbrowser.open(url)
        except Exception:  # noqa: BLE001
            pass


class NseScreen(ModalScreen):
    """Interactive nmap/NSE command builder.

    Reads the installed nmap: script list from script.db, per-script args from
    each .nse source. Tick scripts, fill in only that script's args, get a live
    command. Mainframe filter + book presets included.
    """

    BINDINGS = [("escape", "close", "Close")]

    def __init__(self, target: str):
        super().__init__()
        self.target = target or "TARGET"
        self.selected: set[str] = set()
        self.arg_values: dict[str, str] = {}
        self._all = []
        self._filter_mainframe = True
        self._gen = 0
        self._argen = 0
        self._id_to_script: dict[str, str] = {}
        self._id_to_arg: dict[str, str] = {}

    def compose(self) -> ComposeResult:
        from ..engine import nse
        with Vertical(id="modal"):
            yield Static("nmap / NSE builder", classes="modal-title")
            if not nse.have_nmap():
                yield Static("[#ff5555]nmap not found. Install it (e.g. "
                             "`sudo apt install nmap`) and reopen.[/]")
                with Horizontal(classes="modal-buttons"):
                    yield Button("Close", id="nse-cancel")
                return
            yield Static(f"[dim]nmap {nse.nmap_version()} · target [/]"
                         f"[#b6ffce]{self.target}[/]")
            with Horizontal():
                yield Input(value=self.target, id="nse-target",
                            placeholder="target host/CIDR")
                yield Input(value="", id="nse-ports", placeholder="ports e.g. 23,992,446")
            with Horizontal():
                yield TickBox("-sV", value=True, id="nse-sv")
                yield TickBox("-Pn", value=True, id="nse-pn")
                yield Input(value="4", id="nse-timing", placeholder="T0-5")
                yield Input(value="-sT", id="nse-scantype", placeholder="-sT/-sS")
            yield Static("[#ffb000]Presets[/]")
            with Horizontal():
                for p in nse.load_presets():
                    yield Button(p["name"], id=f"nse-preset-{p['id']}")
            with Horizontal():
                yield TickBox("Mainframe only", value=True, id="nse-mf")
                yield Input(value="", id="nse-search", placeholder="filter scripts…")
                yield Button("Refresh DB", id="nse-refresh")
            yield Static("[#ffb000]Scripts[/] [dim](tick to include)[/]")
            with VerticalScroll(id="nse-scripts"):
                yield Static("", id="nse-script-list-placeholder")
            yield Static("[#ffb000]Script args[/] [dim](only for ticked scripts)[/]")
            with VerticalScroll(id="nse-args"):
                yield Static("[dim]tick a script to see its args[/]", id="nse-args-empty")
            yield Static("[#ffb000]Command[/]")
            yield Static("", id="nse-preview")
            with Horizontal(classes="modal-buttons"):
                yield Button("Close", id="nse-cancel")
                yield Button("Copy command", id="nse-copy", classes="primary")

    def on_mount(self):
        from ..engine import nse
        if nse.have_nmap():
            self._reload_scripts()
            self._refresh_preview()

    # ---- script list ----
    def _reload_scripts(self):
        from ..engine import nse
        try:
            search = self.query_one("#nse-search", Input).value.strip().lower()
        except Exception:  # noqa: BLE001
            search = ""
        self._all = nse.list_scripts(mainframe=self._filter_mainframe)
        box = self.query_one("#nse-scripts", VerticalScroll)
        box.remove_children()
        self._gen += 1
        self._id_to_script = {}
        shown = 0
        for r in self._all:
            if search and search not in r["name"]:
                continue
            if shown > 200:
                break
            wid = f"nsescript-{self._gen}-{shown}"
            self._id_to_script[wid] = r["name"]
            shown += 1
            box.mount(TickBox(f"{r['name']}  [{','.join(r['categories'])}]",
                              value=(r["name"] in self.selected), id=wid))
        if shown == 0:
            box.mount(Static("[dim]no scripts match[/]"))

    # ---- args panel ----
    def _rebuild_args(self):
        from ..engine import nse
        box = self.query_one("#nse-args", VerticalScroll)
        box.remove_children()
        self._argen += 1
        self._id_to_arg = {}
        any_arg = False
        idx = 0
        for sname in sorted(self.selected):
            args = nse.script_args(sname)
            if not args:
                continue
            box.mount(Static(f"[#7dffb0]{sname}[/]"))
            for a in args:
                any_arg = True
                key = a["arg"]
                wid = f"nsearg-{self._argen}-{idx}"
                idx += 1
                self._id_to_arg[wid] = key
                box.mount(Label(f"{key} — {a['desc'][:70]}"))
                box.mount(Input(value=self.arg_values.get(key, ""), id=wid,
                                placeholder="value (blank = skip)"))
        if not any_arg:
            box.mount(Static("[dim]selected scripts document no args (free-text "
                             "allowed via --script-args)[/]"))

    # ---- preview ----
    def _collect_args(self):
        for inp in self.query("Input"):
            if inp.id in self._id_to_arg:
                self.arg_values[self._id_to_arg[inp.id]] = inp.value.strip()

    def _refresh_preview(self):
        from ..engine import nse
        self._collect_args()
        target = self.query_one("#nse-target", Input).value.strip() or self.target
        ports = self.query_one("#nse-ports", Input).value.strip()
        timing = self.query_one("#nse-timing", Input).value.strip()
        scantype = self.query_one("#nse-scantype", Input).value.strip()
        sv = self.query_one("#nse-sv", TickBox).value
        pn = self.query_one("#nse-pn", TickBox).value
        sargs = {k: v for k, v in self.arg_values.items() if v != ""}
        cmd = nse.build_command(
            target, scripts=sorted(self.selected) or None,
            script_args=sargs or None, ports=ports,
            timing=(f"-T{timing}" if timing else ""), scan_type=scantype,
            service_version=sv, no_ping=pn)
        self._cmd = cmd
        self.query_one("#nse-preview", Static).update(f"[#33ff66]{cmd}[/]")

    # ---- events ----
    @on(Checkbox.Changed)
    def _tick(self, ev: Checkbox.Changed):
        wid = ev.checkbox.id or ""
        if wid in self._id_to_script:
            name = self._id_to_script[wid]
            if ev.value:
                self.selected.add(name)
            else:
                self.selected.discard(name)
            self._rebuild_args()
            self._refresh_preview()
        elif wid == "nse-mf":
            self._filter_mainframe = ev.value
            self._reload_scripts()
        elif wid in ("nse-sv", "nse-pn"):
            self._refresh_preview()

    @on(Input.Changed, "#nse-search")
    def _search(self, ev):
        self._reload_scripts()

    @on(Input.Changed)
    def _any_input(self, ev):
        wid = ev.input.id or ""
        if wid in ("nse-target", "nse-ports", "nse-timing",
                   "nse-scantype") or wid in self._id_to_arg:
            self._refresh_preview()

    @on(Button.Pressed)
    def _btn(self, ev: Button.Pressed):
        bid = ev.button.id or ""
        if bid == "nse-cancel":
            self.dismiss(None)
        elif bid == "nse-copy":
            self._refresh_preview()
            self.dismiss(getattr(self, "_cmd", ""))
        elif bid == "nse-refresh":
            from ..engine import nse
            ok, msg = nse.updatedb()
            self.app.bell()
            self._reload_scripts()
        elif bid.startswith("nse-preset-"):
            self._apply_preset(bid.replace("nse-preset-", ""))

    def _apply_preset(self, pid: str):
        from ..engine import nse
        p = nse.preset(pid)
        if not p:
            return
        have = set(nse.parse_script_db().keys())
        self.selected = set(s for s in p.get("scripts", []) if s in have) or \
            set(p.get("scripts", []))
        self.arg_values.update(p.get("script_args", {}) or {})
        # push preset scan flags into the inputs
        if p.get("ports"):
            self.query_one("#nse-ports", Input).value = p["ports"]
        if p.get("scan_type"):
            self.query_one("#nse-scantype", Input).value = p["scan_type"]
        if p.get("timing"):
            self.query_one("#nse-timing", Input).value = p["timing"].replace("-T", "")
        self.query_one("#nse-sv", TickBox).value = p.get("service_version", False)
        self.query_one("#nse-pn", TickBox).value = p.get("no_ping", False)
        self._filter_mainframe = True
        self.query_one("#nse-mf", TickBox).value = True
        self._reload_scripts()
        self._rebuild_args()
        self._refresh_preview()

    def action_close(self):
        self.dismiss(None)


class RssScreen(ModalScreen):
    """CTI RSS reader: fetch security feeds, open items, email a selection.

    Items mentioning the current target (or mainframe keywords) are highlighted.
    """

    BINDINGS = [("escape", "close", "Close"), ("r", "refresh", "Refresh")]

    def __init__(self, terms=None):
        super().__init__()
        self.terms = terms or []
        self.feeds = []
        self.cur = 0

    def compose(self) -> ComposeResult:
        with Vertical(id="modal"):
            yield Static("CTI RSS — security feeds", classes="modal-title")
            yield Static("[dim]loading feeds …[/]", id="rss-status")
            with Horizontal():
                with VerticalScroll(id="rss-feeds"):
                    yield Static("", id="rss-feed-list")
                with Vertical(id="rss-right"):
                    yield DataTable(id="rss-items")
            with Horizontal(classes="modal-buttons"):
                yield Button("Close", id="rss-close")
                yield Button("Open selected", id="rss-open", classes="primary")
                yield Button("Email selected", id="rss-email")
                yield Button("Refresh", id="rss-refresh")

    def on_mount(self):
        t = self.query_one("#rss-items", DataTable)
        t.add_columns("#", "Title", "Published")
        t.cursor_type = "row"
        self.run_worker(self._load(), exclusive=True)

    async def _load(self):
        from ..engine import rss
        self.query_one("#rss-status", Static).update("[#ffb000]fetching feeds …[/]")
        self.feeds = await rss.fetch_all(highlight_terms=self.terms)
        self._render_feed_list()
        self._show_feed(0)
        rel = sum(1 for f in self.feeds for it in f.items if it.relevant)
        note = f" · [#33ff66]{rel} match your target[/]" if rel else ""
        self.query_one("#rss-status", Static).update(
            f"[dim]{len(self.feeds)} feeds{note}. ↑↓ select · o open · e email[/]")

    def _render_feed_list(self):
        lines = []
        for i, f in enumerate(self.feeds):
            mark = "›" if i == self.cur else " "
            err = " [red]![/]" if f.error else ""
            rel = sum(1 for it in f.items if it.relevant)
            tag = f" [#33ff66]({rel})[/]" if rel else ""
            style = "bold #b6ffce" if i == self.cur else "#33ff66"
            lines.append(f"[{style}]{mark} {f.name}[/]{tag}{err}")
        self.query_one("#rss-feed-list", Static).update("\n".join(lines))

    def _show_feed(self, idx):
        if not self.feeds:
            return
        self.cur = max(0, min(idx, len(self.feeds) - 1))
        self._render_feed_list()
        f = self.feeds[self.cur]
        t = self.query_one("#rss-items", DataTable)
        t.clear()
        for i, it in enumerate(f.items, 1):
            title = it.title
            if it.relevant:
                title = f"★ {title}"
            t.add_row(str(i), title[:80], (it.published or "")[:24])

    def _current_item(self):
        f = self.feeds[self.cur] if self.feeds else None
        if not f or not f.items:
            return None
        t = self.query_one("#rss-items", DataTable)
        row = t.cursor_row
        if row is None or row < 0 or row >= len(f.items):
            return None
        return f.items[row]

    @on(Button.Pressed, "#rss-close")
    def _c(self):
        self.dismiss(None)

    @on(Button.Pressed, "#rss-refresh")
    def _r(self):
        self.run_worker(self._load(), exclusive=True)

    def action_refresh(self):
        self.run_worker(self._load(), exclusive=True)

    @on(Button.Pressed, "#rss-open")
    def _open(self):
        it = self._current_item()
        if it and it.link:
            _open_in_browser(self.app, it.link)
            self.query_one("#rss-status", Static).update(
                f"[green]opened:[/] {it.link[:70]}")

    @on(Button.Pressed, "#rss-email")
    def _email(self):
        from ..engine import rss
        it = self._current_item()
        if not it:
            return
        if not rss.smtp_configured():
            self.query_one("#rss-status", Static).update(
                "[#ffb000]SMTP not set. Configure smtp_host/smtp_from/smtp_to "
                "in config to email items.[/]")
            return
        ok, msg = rss.send_email(f"[CTI] {it.title}", [it.link])
        colour = "green" if ok else "#ff5555"
        self.query_one("#rss-status", Static).update(f"[{colour}]{msg}[/]")

    @on(DataTable.RowHighlighted)
    def _hl(self, ev):
        pass

    def on_key(self, ev):
        # left/right (or [ ]) switch feeds
        if ev.key in ("left", "["):
            self._show_feed(self.cur - 1)
        elif ev.key in ("right", "]"):
            self._show_feed(self.cur + 1)

    def action_close(self):
        self.dismiss(None)


class EZReconApp(App):
    CSS_PATH = "app.tcss"
    TITLE = "EZRecon"
    SUB_TITLE = "mainframe passive recon"

    BINDINGS = [
        ("q", "quit", "Quit"),
        ("r", "run", "Run module"),
        ("a", "auto", "Auto-recon"),
        ("e", "export", "Export report"),
        ("k", "keys", "API keys"),
        ("p", "preview", "Preview link"),
        ("g", "graph", "Graph"),
        ("o", "options", "Options"),
        ("n", "nse", "NSE builder"),
        ("s", "rss", "CTI RSS"),
        ("c", "clear", "Clear"),
    ]

    def __init__(self, **kw):
        super().__init__(**kw)
        self.active_module = "auto"
        self.session = Session("")
        self._busy = False
        self._row_findings: list[Finding] = []
        self._active_ok = False
        self.opts = Options.from_config()
        self._chained_hosts: set[str] = set()

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with Horizontal(id="body"):
            with Vertical(id="sidebar"):
                yield Static("MODULES", classes="side-title")
                for mid, label in MODULES:
                    yield Button(label, id=f"mod-{mid}")
                yield Static("", classes="side-title")
                yield Button("Graph", id="mod-graph")
                yield Button("Options", id="mod-options")
                yield Button("API keys", id="mod-keys")
            with Vertical(id="main"):
                yield Static(BANNER.format(v=f"v{__version__}"), classes="banner")
                with Horizontal(id="target-row"):
                    yield Input(placeholder="target domain or URL (e.g. sighberbank.com)",
                                id="target")
                    yield Button("Run", id="run-btn", classes="primary")
                yield RichLog(id="status", markup=True, wrap=True, highlight=False)
                yield DataTable(id="results", zebra_stripes=True)
        yield Footer()

    def on_mount(self):
        # register custom themes and apply the saved choice
        from .themes import THEMES, DEFAULT
        for theme in THEMES.values():
            try:
                self.register_theme(theme)
            except Exception:  # noqa: BLE001
                pass
        saved = config.get_setting("theme", DEFAULT)
        if saved not in THEMES:
            saved = DEFAULT
        try:
            self.theme = saved
        except Exception:  # noqa: BLE001
            pass
        table = self.query_one("#results", DataTable)
        table.add_columns("Sev", "Category", "Key", "Value")
        self._set_active("auto")
        self._log(f"[#ffb000]EZRecon {__version__} ready.[/] "
                  "Pick a module, enter a target, press Run.")
        if not config.has_google():
            self._log("[dim]No Google API key set — press 'k' to add one for dorks.[/]")

    # -- helpers -----------------------------------------------------------
    def _log(self, msg: str):
        self.query_one("#status", RichLog).write(msg)

    def _set_active(self, mid: str):
        self.active_module = mid
        for m, _ in MODULES:
            try:
                btn = self.query_one(f"#mod-{m}", Button)
                btn.set_class(m == mid, "-active")
            except Exception:  # noqa: BLE001
                pass

    def _sev_colours(self):
        """Resolve severity colours from the active theme so they stay readable."""
        try:
            t = self.current_theme
            return {"critical": t.error, "high": t.error, "medium": t.warning,
                    "low": t.success, "info": t.primary}
        except Exception:  # noqa: BLE001
            return SEV_COLOUR

    def _add_findings(self, findings: list[Finding]):
        table = self.query_one("#results", DataTable)
        sev_col = self._sev_colours()
        for f in findings:
            sev = f.severity.value
            colour = sev_col.get(sev, sev_col.get("low", "#33ff66"))
            high = sev in ("high", "critical")
            url = f.meta.get("url", "")
            if url and f.source.startswith("dork-link"):
                # clickable in terminals that support OSC-8 hyperlinks
                value = Text(url[:200], style=f"underline {colour} link {url}"
                             if high else f"underline #7dffb0 link {url}")
            else:
                value = Text(f.value[:200], style=f"bold {colour}" if high else "")
            sev_style = f"bold {colour}" if high else colour
            cat_style = f"bold {colour}" if high else "#7dffb0"
            key_style = f"bold {colour}" if high else ""
            table.add_row(
                Text(sev.upper() if high else sev, style=sev_style),
                Text(f.category, style=cat_style),
                Text(f.key[:40], style=key_style),
                value,
            )
            self._row_findings.append(f)

    def _clear_table(self):
        self.query_one("#results", DataTable).clear()
        self._row_findings = []

    def _progress(self, done: int, total: int):
        if total and done % max(1, total // 5) == 0:
            self._log(f"[dim]  … {done}/{total}[/]")

    # -- events ------------------------------------------------------------
    @on(Button.Pressed)
    def _button(self, event: Button.Pressed):
        bid = event.button.id or ""
        if bid.startswith("mod-"):
            mid = bid[4:]
            if mid == "keys":
                self.action_keys()
            elif mid == "options":
                self.action_options()
            elif mid == "graph":
                self.action_graph()
            else:
                self._set_active(mid)
                self._log(f"[#b6ffce]Module:[/] {mid}")
        elif bid == "run-btn":
            self.action_run()

    @on(Input.Submitted, "#target")
    def _submit(self, event: Input.Submitted):
        self.action_run()

    # -- actions -----------------------------------------------------------
    def _target(self) -> str:
        return self.query_one("#target", Input).value.strip()

    def action_clear(self):
        self._clear_table()
        self.session = Session(self._target())
        self._log("[dim]cleared.[/]")

    def action_preview(self):
        table = self.query_one("#results", DataTable)
        if table.row_count == 0:
            self._log("[#ffb000]no results to preview — run a dork first.[/]")
            return
        idx = table.cursor_row
        if idx is None or not (0 <= idx < len(self._row_findings)):
            self._log("[#ffb000]select a result row first.[/]")
            return
        f = self._row_findings[idx]
        query = f.meta.get("query", "")
        if not query and f.category == "dork":
            query = f.key
        if not query:
            self._log("[#ffb000]preview works on dork rows (link or result).[/]")
            return
        self._open_preview(query)

    def _open_preview(self, query: str):
        if self._active_ok or config.get_setting("allow_active_fetch", False):
            self.push_screen(PreviewScreen(query))
            return

        def after(res):
            if not res:
                self._log("[dim]preview cancelled.[/]")
                return
            self._active_ok = True
            if res.get("remember"):
                config.set_setting("allow_active_fetch", True)
            self.push_screen(PreviewScreen(query))

        self.push_screen(ActiveConfirmScreen(), after)

    def action_keys(self):
        self.push_screen(KeysScreen(), lambda saved: self._log(
            "[green]keys saved.[/]" if saved else "[dim]keys unchanged.[/]"))

    def action_options(self):
        def apply(opts):
            if opts is not None:
                self.opts = opts
                self._log("[green]options updated.[/]")
        self.push_screen(OptionsScreen(self.opts), apply)

    def action_nse(self):
        target = self.query_one("#target", Input).value.strip() or \
            (self.session.target or "")

        def done(cmd):
            if cmd:
                self._log(f"[green]nmap command built:[/] [#33ff66]{cmd}[/]")
                self._log("[dim]  (copied to the log — paste into your shell; "
                          "SYN scans need sudo).[/]")
        self.push_screen(NseScreen(target), done)

    def action_rss(self):
        target = self.query_one("#target", Input).value.strip() or \
            (self.session.target or "")
        terms = ["mainframe", "z/OS", "RACF", "COBOL", "CICS", "IMS", "LPAR"]
        if target:
            terms.append(target)
            name = target.split(".")[0]
            if name and name != target:
                terms.append(name)
        self.push_screen(RssScreen(terms))

    def action_graph(self):
        if not self.session.findings:
            self._log("[#ffb000]nothing to graph yet — run a scan first.[/]")
            return
        self.push_screen(GraphScreen(self))

    def action_export(self):
        if not self.session.findings:
            self._log("[#ffb000]nothing to export yet.[/]")
            return
        out = config.output_dir()
        paths = reporter.write_reports(self.session, out)
        self._log(f"[green]report written:[/] {paths['md']}")
        for k, p in paths.items():
            self._log(f"[dim]  {k}: {p}[/]")

    def action_auto(self):
        self._set_active("auto")
        self.action_run()

    def action_run(self):
        if self._busy:
            self._log("[#ffb000]busy — let the current run finish.[/]")
            return
        target = self._target()
        if not target:
            self._log("[#ff5555]enter a target first.[/]")
            return
        self.session = self.session if self.session.target == target else Session(target)
        self.run_worker(self._dispatch(target, self.active_module), exclusive=True)

    async def _dispatch(self, target: str, module: str):
        self._busy = True
        self._log(f"[#ffb000]▶ {module}[/] on [#b6ffce]{target}[/] …")
        t0 = time.time()
        try:
            findings: list[Finding] = []
            if module == "auto":
                self.session = await pipeline.auto_recon(
                    target, do_ports=True,
                    do_shodan=config.has_shodan(),
                    on_stage=lambda m: self._log(f"[dim]  · {m}[/]"),
                )
                self._clear_table()
                self._add_findings(self.session.findings)
                self._done(t0, len(self.session.findings))
                self._maybe_offer_chain("auto", self.session.findings)
                return
            elif module == "dns":
                findings = await dns_recon.dns_lookup(target, session=self.session)
                findings += await dns_recon.zone_transfer(target, session=self.session)
            elif module == "whois":
                findings = await whois_recon.whois_lookup(target, session=self.session)
            elif module == "subdomains":
                wl = subdomains.load_wordlist(self.opts.wordlist_path) \
                    if self.opts.wordlist_path else None
                findings = await subdomains.brute_force(
                    target, wordlist=wl, concurrency=self.opts.dns_concurrency,
                    timeout=self.opts.brute_timeout, session=self.session,
                    on_progress=self._progress)
            elif module == "crtsh":
                findings = await crtsh.crtsh_lookup(target, session=self.session)
            elif module == "email":
                seed = self.opts.email_seed or target
                findings = await email_scraper.scrape(
                    seed, max_depth=self.opts.email_depth,
                    max_pages=self.opts.email_max_pages,
                    concurrency=self.opts.spider_concurrency,
                    session=self.session, on_progress=self._progress)
            elif module == "ports":
                findings, _ = await ports.scan(
                    target, ports=self.opts.port_list(),
                    concurrency=self.opts.port_concurrency,
                    session=self.session, on_progress=self._progress)
            elif module == "shodan":
                self._busy = False
                self.push_screen(ShodanScreen(target), self._run_shodan)
                return
            elif module == "dork":
                self._busy = False
                self.push_screen(DorkScreen(target), self._run_dorks)
                return
            elif module == "takeover":
                # discover hosts first if we don't have any yet
                if not self.session.by_category("subdomain"):
                    self._log("[dim]  · enumerating subdomains first[/]")
                    await subdomains.brute_force(
                        target, concurrency=self.opts.dns_concurrency,
                        timeout=self.opts.brute_timeout, session=self.session,
                        on_progress=self._progress)
                    await crtsh.crtsh_lookup(target, session=self.session)
                do_http = bool(self._active_ok)
                if not do_http:
                    self._log("[#ffb000]  · passive mode (DNS only). Enable "
                              "active recon (toggle) to HTTP-confirm candidates.[/]")
                findings = await takeover.check_all(
                    self.session, do_http=do_http,
                    on_stage=lambda m: self._log(f"[dim]  · {m}[/]"))
                if not findings:
                    findings = [Finding("takeover", "info",
                                "no dangling / takeover conditions found",
                                "takeover", Severity.INFO)]
            elif module == "wayback":
                findings = await wayback.harvest(
                    target, session=self.session,
                    on_stage=lambda m: self._log(f"[dim]  · {m}[/]"))
            elif module == "github":
                findings = github_dork.dork_links(target, session=self.session)
                self._log("[dim]  · GitHub search links (no key). Click a URL, "
                          "or set github_token + use the CLI --fetch for results.[/]")
            elif module == "docmeta":
                urls = docmeta.doc_urls_from_session(self.session)
                if not urls:
                    findings = [Finding("docmeta", "info",
                                "no document URLs yet — run Google Dork or "
                                "Wayback URLs first to discover PDFs/Office docs",
                                "docmeta", Severity.INFO)]
                else:
                    self._log(f"[dim]  · harvesting {len(urls)} documents[/]")
                    findings = await docmeta.harvest(
                        urls, session=self.session,
                        on_stage=lambda m: self._log(f"[dim]  · {m}[/]"))
                    if not findings:
                        findings = [Finding("docmeta", "info",
                                    "no metadata extracted from the documents",
                                    "docmeta", Severity.INFO)]
            elif module == "harvest":
                findings = await harvester.harvest(
                    target, session=self.session, do_pgp=True,
                    on_stage=lambda m: self._log(f"[dim]  · {m}[/]"))
            elif module == "breach":
                if not hibp.has_key():
                    findings = [Finding("breach", "error",
                                "no HIBP key — add one via API keys ('k'): "
                                "hibp_api_key", "hibp", Severity.INFO)]
                else:
                    emails = hibp.emails_from_session(self.session)
                    if not emails:
                        self._log("[dim]  · no emails yet — running people "
                                  "harvest first[/]")
                        await harvester.harvest(
                            target, session=self.session,
                            on_stage=lambda m: self._log(f"[dim]  · {m}[/]"))
                        emails = hibp.emails_from_session(self.session)
                    if not emails:
                        findings = [Finding("breach", "info",
                                    "no emails found to check", "hibp",
                                    Severity.INFO)]
                    else:
                        self._log(f"[dim]  · checking {len(emails)} emails "
                                  "(paced for HIBP rate limits)[/]")
                        findings = await hibp.check_emails(
                            emails, session=self.session,
                            on_stage=lambda m: self._log(f"[dim]  · {m}[/]"))
            elif module == "buckets":
                if not self._active_ok:
                    findings = [Finding("bucket", "info",
                                "bucket discovery probes cloud providers — "
                                "enable active recon (toggle) to run it",
                                "buckets", Severity.INFO)]
                else:
                    findings = await buckets.check_all(
                        target, session=self.session,
                        on_stage=lambda m: self._log(f"[dim]  · {m}[/]"))
            elif module == "prompt":
                prompt = ai_osint.build_prompt(target, self.session)
                self._busy = False
                self.push_screen(TextScreen("AI deep-research OSINT prompt", prompt))
                self._log("[green]prompt generated (copy from the panel).[/]")
                return
            self._add_findings(findings)
            self._done(t0, len(findings))
            self._maybe_offer_chain(module, findings)
        except Exception as e:  # noqa: BLE001
            self._log(f"[#ff5555]error: {e}[/]")
        finally:
            self._busy = False

    def _maybe_offer_chain(self, module: str, findings: list[Finding]):
        """If a run produced new subdomains, propose chaining them."""
        if not self.opts.chain_enabled:
            return
        if module not in ("subdomains", "crtsh", "auto"):
            return
        if not any(f.category == "subdomain" and
                   f.key not in ("wildcard", "crt.sh", "error") for f in findings):
            return
        plan = chaining.build_plan(self.session, cap=self.opts.chain_cap,
                                   already_seeded=self._chained_hosts)
        if not plan["hosts"]:
            return
        self.push_screen(ChainConfirmScreen(plan), self._run_chain)

    def _run_chain(self, result):
        if not result:
            self._log("[dim]chaining skipped.[/]")
            return
        plan = result["plan"]
        self.run_worker(self._chain_worker(plan), exclusive=True)

    async def _chain_worker(self, plan):
        self._busy = True
        self._log(f"[#ffb000]▶ chaining[/] {len(plan['hosts'])} subdomain(s) …")
        t0 = time.time()
        try:
            eng = self.opts.preview_engine if self.opts.preview_engine in (
                "google", "bing", "duckduckgo") else "google"
            findings = await chaining.run_chain(
                self.session, plan, engine=eng,
                do_links=True, do_spider=True, spider_depth=1,
                spider_concurrency=self.opts.spider_concurrency,
                on_stage=lambda m: self._log(f"[dim]  · {m}[/]"))
            for h in plan["hosts"]:
                self._chained_hosts.add(h)
            self._add_findings(findings)
            self._done(t0, len(findings))
        except Exception as e:  # noqa: BLE001
            self._log(f"[#ff5555]chain error: {e}[/]")
        finally:
            self._busy = False

    def _run_dorks(self, result):
        if not result:
            self._log("[dim]dork run cancelled.[/]")
            return
        mode = result.get("mode", "api")
        queries = result.get("queries", [])
        if not queries:
            self._log("[#ffb000]no dorks ticked.[/]")
            return
        if mode == "links":
            findings = google_dork.links_for_queries(queries, session=self.session)
            self._add_findings(findings)
            self._log(f"[green]✓ {len(findings)} dork links[/] "
                      "[dim](no key used — click a URL, or press 'p' on a row to "
                      "preview; 'e' to export).[/]")
            return
        if mode == "fetch":
            # prefer a self-hosted SearXNG if configured (reliable, keyless),
            # otherwise fall back to DuckDuckGo scraping
            from ..engine import searx as searxmod
            self._fetch_dorks(queries,
                              engine="searx" if searxmod.has_searx() else "ddg")
            return
        # "api" mode: same Title/Link/Snippet renderer, via the Google API
        self._fetch_dorks(queries, engine="api")

    def _fetch_dorks(self, queries, engine="ddg"):
        """Fetch real Title/Link/Snippet results into the results screen.

        engine="ddg" is keyless (DuckDuckGo); engine="api" uses Google Custom
        Search if a key is configured. Both are active recon, so gated once.
        """
        def go():
            self.push_screen(DorkResultsScreen(
                queries, engine=engine, session=self.session,
                limit=self.opts.preview_limit))
        if self._active_ok or config.get_setting("allow_active_fetch", False):
            go()
            return

        def after(res):
            if not res:
                self._log("[dim]dork fetch cancelled.[/]")
                return
            self._active_ok = True
            if res.get("remember"):
                config.set_setting("allow_active_fetch", True)
            go()
        self.push_screen(ActiveConfirmScreen(), after)

    def _run_shodan(self, queries):
        if not queries:
            self._log("[dim]shodan run cancelled (nothing selected).[/]")
            return
        if not config.has_shodan():
            self._log("[#ffb000]no Shodan key set — press 'k' to add one.[/]")
        self.run_worker(self._shodan_worker(queries), exclusive=True)

    async def _shodan_worker(self, queries):
        self._busy = True
        self._log(f"[#ffb000]▶ shodan[/] — {len(queries)} query(ies) …")
        t0 = time.time()
        total = 0
        try:
            for q in queries:
                self._log(f"[dim]  · {q}[/]")
                findings = await shodan_recon.search(q, session=self.session)
                self._add_findings(findings)
                total += len([f for f in findings if f.key not in ("error", "shodan")])
            self._done(t0, total)
        except Exception as e:  # noqa: BLE001
            self._log(f"[#ff5555]error: {e}[/]")
        finally:
            self._busy = False

    def _done(self, t0: float, n: int):
        self._log(f"[green]✓ {n} findings[/] [dim]({time.time()-t0:.1f}s) — "
                  f"press 'e' to export.[/]")


def run():
    EZReconApp().run()


if __name__ == "__main__":
    run()
