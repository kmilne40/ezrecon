"""EZRecon Textual application.

A phosphor-themed TUI: pick a module from the sidebar, type a target, and
results stream into the findings table. Google Dork opens the Listing 6-1
multi-select. Auto-Recon runs the whole passive chain. Reports export to disk.
"""

from __future__ import annotations

import time
from pathlib import Path

from rich.text import Text
from textual import on
from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import (
    Button,
    Checkbox,
    DataTable,
    Footer,
    Header,
    Input,
    Label,
    RichLog,
    Static,
)


class TickBox(Checkbox):
    """A checkbox that shows a tick (✓) when on instead of an X."""

    BUTTON_INNER = "✓"

from .. import __version__, config
from ..engine import (
    ai_osint,
    crtsh,
    dns_recon,
    email_scraper,
    google_dork,
    pipeline,
    ports,
    shodan_recon,
    subdomains,
    webintel,
    whois_recon,
)
from ..models import Finding, Session
from ..report import reporter

BANNER = r"""
 ______ ___________
 |  ___/___  /  __ \   EZRecon
 | |__    / /| /  \/   passive recon for the mainframe hunter
 |  __|  / / | |
 | |___./ /__| \__/\   {v}
 \____/\_____/\____/
""".strip("\n")

SEV_COLOUR = {"high": "red", "medium": "#ffb000", "low": "#33ff66", "info": "#1f8a3a"}

MODULES = [
    ("auto", "Auto-Recon"),
    ("dns", "DNS Records"),
    ("whois", "WHOIS"),
    ("subdomains", "Subdomains"),
    ("crtsh", "crt.sh (CT)"),
    ("email", "Email Spider"),
    ("ports", "Banner Grab"),
    ("shodan", "Shodan Sweep"),
    ("dork", "Google Dork"),
    ("prompt", "AI Prompt"),
]


class DorkScreen(ModalScreen):
    """The Listing 6-1 multi-select for Google dorks."""

    def __init__(self, domain: str):
        super().__init__()
        self.domain = domain
        self.dorks = google_dork.load_catalogue()

    def compose(self) -> ComposeResult:
        with Vertical(id="modal"):
            yield Static(f"Google Dork selection — site:{self.domain}",
                         classes="modal-title")
            yield Static("[dim]Tick the queries to use and edit any of them. "
                         "'Open as links' needs no API key — it builds clickable "
                         "search URLs. 'Run via API' fetches results (needs a key).[/]")
            with VerticalScroll(id="dork-list"):
                for d in self.dorks:
                    built = google_dork.build_query(d, self.domain)
                    with Horizontal(classes="dork-row"):
                        yield TickBox(value=(d.enabled or d.id == 1),
                                      id=f"dchk-{d.id}")
                        yield Input(value=built, id=f"dq-{d.id}")
            with Horizontal(classes="modal-buttons"):
                yield Button("Cancel", id="dork-cancel")
                yield Button("Open as links", id="dork-links")
                yield Button("Run via API", id="dork-run", classes="primary")

    def _collect(self) -> list[str]:
        out: list[str] = []
        for d in self.dorks:
            if self.query_one(f"#dchk-{d.id}", TickBox).value:
                val = self.query_one(f"#dq-{d.id}", Input).value.strip()
                if val:
                    out.append(val)
        seen: list[str] = []
        for q in out:
            if q not in seen:
                seen.append(q)
        return seen

    @on(Button.Pressed, "#dork-cancel")
    def _cancel(self):
        self.dismiss(None)

    @on(Button.Pressed, "#dork-links")
    def _links(self):
        self.dismiss({"mode": "links", "queries": self._collect()})

    @on(Button.Pressed, "#dork-run")
    def _run(self):
        self.dismiss({"mode": "api", "queries": self._collect()})


class ShodanScreen(ModalScreen):
    """Tick-box + editable Shodan query builder.

    Each built-in mainframe query gets a checkbox and an editable field, so you
    can toggle it, tweak the syntax, or type your own in the blank rows. Ticked
    rows with non-empty text are the queries that run.
    """

    CUSTOM_ROWS = 3

    def __init__(self, domain: str):
        super().__init__()
        self.domain = domain
        self.queries = shodan_recon.mainframe_queries()

    def compose(self) -> ComposeResult:
        with Vertical(id="modal"):
            yield Static("Shodan query selection", classes="modal-title")
            yield Static("[dim]Tick the queries to run and edit any of them. "
                         "Blank rows at the bottom are for your own. Use "
                         "hostname: or org: to scope to a target.[/]")
            with VerticalScroll(id="shodan-list"):
                for i, q in enumerate(self.queries):
                    with Horizontal(classes="squery-row"):
                        yield TickBox(value=(i < 3), id=f"schk-{i}")
                        yield Input(value=q["query"], id=f"sq-{i}")
                for c in range(self.CUSTOM_ROWS):
                    with Horizontal(classes="squery-row"):
                        yield TickBox(value=False, id=f"schk-c{c}")
                        yield Input(placeholder="custom Shodan query…",
                                    id=f"sq-c{c}")
            with Horizontal(classes="modal-buttons"):
                yield Button("Cancel", id="shodan-cancel")
                yield Button("Run queries", id="shodan-run", classes="primary")

    def _collect(self) -> list[str]:
        out: list[str] = []
        for i in range(len(self.queries)):
            if self.query_one(f"#schk-{i}", TickBox).value:
                val = self.query_one(f"#sq-{i}", Input).value.strip()
                if val:
                    out.append(val)
        for c in range(self.CUSTOM_ROWS):
            if self.query_one(f"#schk-c{c}", TickBox).value:
                val = self.query_one(f"#sq-c{c}", Input).value.strip()
                if val:
                    out.append(val)
        # de-dupe, preserve order
        seen: list[str] = []
        for q in out:
            if q not in seen:
                seen.append(q)
        return seen

    @on(Button.Pressed, "#shodan-cancel")
    def _cancel(self):
        self.dismiss(None)

    @on(Button.Pressed, "#shodan-run")
    def _run(self):
        self.dismiss(self._collect())


class KeysScreen(ModalScreen):
    """API-key entry."""

    def compose(self) -> ComposeResult:
        with Vertical(id="modal"):
            yield Static("API keys", classes="modal-title")
            yield Label("Google API key")
            yield Input(value=config.get_key("google_api_key"),
                        password=True, id="k-gkey")
            yield Label("Google CSE ID")
            yield Input(value=config.get_key("google_cse_id"), id="k-gcse")
            yield Label("Shodan API key")
            yield Input(value=config.get_key("shodan_api_key"),
                        password=True, id="k-shodan")
            yield Label("Anthropic API key (optional — for preview summaries)")
            yield Input(value=config.get_key("anthropic_api_key"),
                        password=True, id="k-anthropic")
            with Horizontal(classes="modal-buttons"):
                yield Button("Cancel", id="keys-cancel")
                yield Button("Save", id="keys-save", classes="primary")

    @on(Button.Pressed, "#keys-cancel")
    def _cancel(self):
        self.dismiss(False)

    @on(Button.Pressed, "#keys-save")
    def _save(self):
        config.set_key("google_api_key", self.query_one("#k-gkey", Input).value)
        config.set_key("google_cse_id", self.query_one("#k-gcse", Input).value)
        config.set_key("shodan_api_key", self.query_one("#k-shodan", Input).value)
        config.set_key("anthropic_api_key",
                       self.query_one("#k-anthropic", Input).value)
        self.dismiss(True)


class TextScreen(ModalScreen):
    """Scrollable read-only text (used for the AI prompt)."""

    def __init__(self, title: str, body: str):
        super().__init__()
        self._title = title
        self._body = body

    def compose(self) -> ComposeResult:
        with Vertical(id="modal"):
            yield Static(self._title, classes="modal-title")
            with VerticalScroll():
                yield Static(self._body)
            with Horizontal(classes="modal-buttons"):
                yield Button("Close", id="text-close", classes="primary")

    @on(Button.Pressed, "#text-close")
    def _close(self):
        self.dismiss()


class ActiveConfirmScreen(ModalScreen):
    """Explicit opt-in before EZRecon reaches out to third-party pages."""

    def compose(self) -> ComposeResult:
        with Vertical(id="modal"):
            yield Static("Active reconnaissance — confirm", classes="modal-title")
            yield Static(
                "[#ffb000]The preview pane fetches third-party search results and "
                "pages.[/] This connects to hosts you may not own, so it is "
                "active recon, not passive. Only proceed against targets you are "
                "authorised to assess.")
            yield TickBox("Don't ask again (remember this choice)", id="ac-remember")
            with Horizontal(classes="modal-buttons"):
                yield Button("Cancel", id="ac-cancel")
                yield Button("Proceed", id="ac-ok", classes="primary")

    @on(Button.Pressed, "#ac-cancel")
    def _cancel(self):
        self.dismiss(None)

    @on(Button.Pressed, "#ac-ok")
    def _ok(self):
        self.dismiss({"remember": self.query_one("#ac-remember", TickBox).value})


class PreviewScreen(ModalScreen):
    """Fetch real results for a dork, inspect pages, summarise in context."""

    BINDINGS = [
        ("escape", "close", "Close"),
        ("o", "open_browser", "Open in browser"),
        ("s", "llm", "LLM summary"),
    ]

    def __init__(self, query: str, engine: str = "auto"):
        super().__init__()
        self.dork_query = query
        self.engine = engine
        self.terms = webintel.terms_from_query(query)
        self.results: list = []
        self.current = None  # PageIntel

    def compose(self) -> ComposeResult:
        with Vertical(id="modal-wide"):
            yield Static(f"Preview — {self.dork_query}", classes="modal-title")
            yield Static("[dim]Enter/click a result to fetch & analyse it · "
                         "[b]o[/b] open in browser · [b]s[/b] LLM summary · "
                         "[b]Esc[/b] close[/]")
            with Horizontal(id="preview-body"):
                with Vertical(id="preview-list-pane"):
                    yield DataTable(id="preview-results", cursor_type="row")
                with VerticalScroll(id="preview-detail"):
                    yield Static("Loading results…", id="preview-detail-body")
            with Horizontal(classes="modal-buttons"):
                yield Button("Close", id="preview-close")

    def on_mount(self):
        t = self.query_one("#preview-results", DataTable)
        t.add_columns("#", "Title", "URL")
        self.run_worker(self._load(), exclusive=True)

    async def _load(self):
        results, err = await webintel.get_results(self.dork_query, engine=self.engine)
        self.results = results
        t = self.query_one("#preview-results", DataTable)
        for i, r in enumerate(results, 1):
            t.add_row(str(i), (r.title or r.url)[:60], r.url[:80])
        detail = self.query_one("#preview-detail-body", Static)
        if not results:
            detail.update(f"[#ff5555]No results.[/] {err or ''}\n\n"
                          "DuckDuckGo can rate-limit; you can still open the "
                          "search in a browser with [b]o[/b].")
        else:
            src = results[0].source
            detail.update(f"[green]{len(results)} results[/] via {src}. "
                          "Select one to fetch and analyse it.")

    @on(DataTable.RowSelected, "#preview-results")
    def _pick(self, event: DataTable.RowSelected):
        idx = event.cursor_row
        if 0 <= idx < len(self.results):
            self.run_worker(self._fetch(idx), exclusive=True)

    async def _fetch(self, idx: int):
        r = self.results[idx]
        detail = self.query_one("#preview-detail-body", Static)
        detail.update(f"Fetching {r.url} …")
        intel = await webintel.fetch_page(r.url, terms=self.terms)
        self.current = intel
        detail.update(self._detail_text(intel))

    def _detail_text(self, intel, llm: str = "") -> str:
        if intel.error:
            return (f"[#ff5555]{intel.error}[/]\n\n{intel.url}\n\n"
                    "Press [b]o[/b] to open it in a browser instead.")
        lines = [
            f"[b]{intel.title or '(no title)'}[/b]",
            f"[dim]{intel.final_url or intel.url}[/]",
            f"[dim]HTTP {intel.status} · {intel.content_type} · "
            f"{intel.size} bytes[/]",
            "",
        ]
        if intel.description:
            lines += [f"[#b6ffce]{intel.description}[/]", ""]
        if intel.contexts:
            lines.append(f"[#ffb000]Terms in context ({len(intel.contexts)}):[/]")
            for h in intel.contexts:
                snip = h["snippet"].replace("❱", "[b #33ff66]").replace("❰", "[/]")
                lines.append(f"  • [b]{h['term']}[/b]: {snip}")
        else:
            lines.append("[dim]No highlighted terms found on the page.[/]")
        if llm:
            lines += ["", "[#ffb000]LLM summary:[/]", llm]
        elif webintel.has_llm():
            lines += ["", "[dim]Press [b]s[/b] for an LLM summary.[/]"]
        return "\n".join(lines)

    def action_llm(self):
        if not webintel.has_llm():
            self.app.bell()
            self.query_one("#preview-detail-body", Static).update(
                "[#ffb000]No Anthropic API key set (press 'k' on the main "
                "screen to add one).[/]")
            return
        if not self.current:
            return
        self.run_worker(self._do_llm(), exclusive=True, thread=True)

    async def _do_llm(self):
        detail = self.query_one("#preview-detail-body", Static)
        detail.update(self._detail_text(self.current) + "\n\n[dim]summarising…[/]")
        import asyncio
        loop = asyncio.get_event_loop()
        summary = await loop.run_in_executor(
            None, webintel.summarise_llm, self.current, self.dork_query)
        detail.update(self._detail_text(self.current, llm=summary))

    def action_open_browser(self):
        url = ""
        if self.current:
            url = self.current.final_url or self.current.url
        else:
            t = self.query_one("#preview-results", DataTable)
            if self.results and 0 <= t.cursor_row < len(self.results):
                url = self.results[t.cursor_row].url
        if not url:
            url = f"https://duckduckgo.com/?q={self.dork_query}"
        _open_in_browser(self.app, url)

    def action_close(self):
        self.dismiss()

    @on(Button.Pressed, "#preview-close")
    def _close(self):
        self.dismiss()


def _open_in_browser(app, url: str) -> None:
    """Open a URL in the system browser, suspending the TUI first."""
    import webbrowser

    try:
        with app.suspend():
            webbrowser.open(url)
    except Exception:  # noqa: BLE001 - headless / no browser
        try:
            webbrowser.open(url)
        except Exception:  # noqa: BLE001
            pass


class EZReconApp(App):
    CSS_PATH = "app.tcss"
    TITLE = "EZRecon"
    SUB_TITLE = "mainframe passive recon"

    BINDINGS = [
        ("q", "quit", "Quit"),
        ("r", "run", "Run module"),
        ("a", "auto", "Auto-recon"),
        ("e", "export", "Export report"),
        ("k", "keys", "API keys"),
        ("p", "preview", "Preview link"),
        ("c", "clear", "Clear"),
    ]

    def __init__(self, **kw):
        super().__init__(**kw)
        self.active_module = "auto"
        self.session = Session("")
        self._busy = False
        self._row_findings: list[Finding] = []
        self._active_ok = False

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with Horizontal(id="body"):
            with Vertical(id="sidebar"):
                yield Static("MODULES", classes="side-title")
                for mid, label in MODULES:
                    yield Button(label, id=f"mod-{mid}")
                yield Static("", classes="side-title")
                yield Button("API keys", id="mod-keys")
            with Vertical(id="main"):
                yield Static(BANNER.format(v=f"v{__version__}"), classes="banner")
                with Horizontal(id="target-row"):
                    yield Input(placeholder="target domain or URL (e.g. sighberbank.com)",
                                id="target")
                    yield Button("Run", id="run-btn", classes="primary")
                yield RichLog(id="status", markup=True, wrap=True, highlight=False)
                yield DataTable(id="results", zebra_stripes=True)
        yield Footer()

    def on_mount(self):
        table = self.query_one("#results", DataTable)
        table.add_columns("Sev", "Category", "Key", "Value")
        self._set_active("auto")
        self._log(f"[#ffb000]EZRecon {__version__} ready.[/] "
                  "Pick a module, enter a target, press Run.")
        if not config.has_google():
            self._log("[dim]No Google API key set — press 'k' to add one for dorks.[/]")

    # -- helpers -----------------------------------------------------------
    def _log(self, msg: str):
        self.query_one("#status", RichLog).write(msg)

    def _set_active(self, mid: str):
        self.active_module = mid
        for m, _ in MODULES:
            try:
                btn = self.query_one(f"#mod-{m}", Button)
                btn.set_class(m == mid, "-active")
            except Exception:  # noqa: BLE001
                pass

    def _add_findings(self, findings: list[Finding]):
        table = self.query_one("#results", DataTable)
        for f in findings:
            colour = SEV_COLOUR.get(f.severity.value, "#33ff66")
            url = f.meta.get("url", "")
            if url and f.source.startswith("dork-link"):
                # clickable in terminals that support OSC-8 hyperlinks
                value = Text(url[:200], style=f"underline #7dffb0 link {url}")
            else:
                value = Text(f.value[:200])
            table.add_row(
                Text(f.severity.value, style=colour),
                Text(f.category, style="#7dffb0"),
                Text(f.key[:40]),
                value,
            )
            self._row_findings.append(f)

    def _clear_table(self):
        self.query_one("#results", DataTable).clear()
        self._row_findings = []

    def _progress(self, done: int, total: int):
        if total and done % max(1, total // 5) == 0:
            self._log(f"[dim]  … {done}/{total}[/]")

    # -- events ------------------------------------------------------------
    @on(Button.Pressed)
    def _button(self, event: Button.Pressed):
        bid = event.button.id or ""
        if bid.startswith("mod-"):
            mid = bid[4:]
            if mid == "keys":
                self.action_keys()
            else:
                self._set_active(mid)
                self._log(f"[#b6ffce]Module:[/] {mid}")
        elif bid == "run-btn":
            self.action_run()

    @on(Input.Submitted, "#target")
    def _submit(self, event: Input.Submitted):
        self.action_run()

    # -- actions -----------------------------------------------------------
    def _target(self) -> str:
        return self.query_one("#target", Input).value.strip()

    def action_clear(self):
        self._clear_table()
        self.session = Session(self._target())
        self._log("[dim]cleared.[/]")

    def action_preview(self):
        table = self.query_one("#results", DataTable)
        if table.row_count == 0:
            self._log("[#ffb000]no results to preview — run a dork first.[/]")
            return
        idx = table.cursor_row
        if idx is None or not (0 <= idx < len(self._row_findings)):
            self._log("[#ffb000]select a result row first.[/]")
            return
        f = self._row_findings[idx]
        query = f.meta.get("query", "")
        if not query and f.category == "dork":
            query = f.key
        if not query:
            self._log("[#ffb000]preview works on dork rows (link or result).[/]")
            return
        self._open_preview(query)

    def _open_preview(self, query: str):
        if self._active_ok or config.get_setting("allow_active_fetch", False):
            self.push_screen(PreviewScreen(query))
            return

        def after(res):
            if not res:
                self._log("[dim]preview cancelled.[/]")
                return
            self._active_ok = True
            if res.get("remember"):
                config.set_setting("allow_active_fetch", True)
            self.push_screen(PreviewScreen(query))

        self.push_screen(ActiveConfirmScreen(), after)

    def action_keys(self):
        self.push_screen(KeysScreen(), lambda saved: self._log(
            "[green]keys saved.[/]" if saved else "[dim]keys unchanged.[/]"))

    def action_export(self):
        if not self.session.findings:
            self._log("[#ffb000]nothing to export yet.[/]")
            return
        out = config.output_dir()
        paths = reporter.write_reports(self.session, out)
        self._log(f"[green]report written:[/] {paths['md']}")
        for k, p in paths.items():
            self._log(f"[dim]  {k}: {p}[/]")

    def action_auto(self):
        self._set_active("auto")
        self.action_run()

    def action_run(self):
        if self._busy:
            self._log("[#ffb000]busy — let the current run finish.[/]")
            return
        target = self._target()
        if not target:
            self._log("[#ff5555]enter a target first.[/]")
            return
        self.session = self.session if self.session.target == target else Session(target)
        self.run_worker(self._dispatch(target, self.active_module), exclusive=True)

    async def _dispatch(self, target: str, module: str):
        self._busy = True
        self._log(f"[#ffb000]▶ {module}[/] on [#b6ffce]{target}[/] …")
        t0 = time.time()
        try:
            findings: list[Finding] = []
            if module == "auto":
                self.session = await pipeline.auto_recon(
                    target, do_ports=True,
                    do_shodan=config.has_shodan(),
                    on_stage=lambda m: self._log(f"[dim]  · {m}[/]"),
                )
                self._clear_table()
                self._add_findings(self.session.findings)
                self._done(t0, len(self.session.findings))
                return
            elif module == "dns":
                findings = await dns_recon.dns_lookup(target, session=self.session)
                findings += await dns_recon.zone_transfer(target, session=self.session)
            elif module == "whois":
                findings = await whois_recon.whois_lookup(target, session=self.session)
            elif module == "subdomains":
                findings = await subdomains.brute_force(
                    target, session=self.session, on_progress=self._progress)
            elif module == "crtsh":
                findings = await crtsh.crtsh_lookup(target, session=self.session)
            elif module == "email":
                findings = await email_scraper.scrape(
                    target, session=self.session, on_progress=self._progress)
            elif module == "ports":
                findings, _ = await ports.scan(
                    target, session=self.session, on_progress=self._progress)
            elif module == "shodan":
                self._busy = False
                self.push_screen(ShodanScreen(target), self._run_shodan)
                return
            elif module == "dork":
                self._busy = False
                self.push_screen(DorkScreen(target), self._run_dorks)
                return
            elif module == "prompt":
                prompt = ai_osint.build_prompt(target, self.session)
                self._busy = False
                self.push_screen(TextScreen("AI deep-research OSINT prompt", prompt))
                self._log("[green]prompt generated (copy from the panel).[/]")
                return
            self._add_findings(findings)
            self._done(t0, len(findings))
        except Exception as e:  # noqa: BLE001
            self._log(f"[#ff5555]error: {e}[/]")
        finally:
            self._busy = False

    def _run_dorks(self, result):
        if not result:
            self._log("[dim]dork run cancelled.[/]")
            return
        mode = result.get("mode", "api")
        queries = result.get("queries", [])
        if not queries:
            self._log("[#ffb000]no dorks ticked.[/]")
            return
        if mode == "links":
            findings = google_dork.links_for_queries(queries, session=self.session)
            self._add_findings(findings)
            self._log(f"[green]✓ {len(findings)} dork links[/] "
                      "[dim](no key used — click a URL, or press 'p' on a row to "
                      "preview; 'e' to export).[/]")
            return
        self.run_worker(self._dork_worker(queries), exclusive=True)

    def _run_shodan(self, queries):
        if not queries:
            self._log("[dim]shodan run cancelled (nothing selected).[/]")
            return
        if not config.has_shodan():
            self._log("[#ffb000]no Shodan key set — press 'k' to add one.[/]")
        self.run_worker(self._shodan_worker(queries), exclusive=True)

    async def _shodan_worker(self, queries):
        self._busy = True
        self._log(f"[#ffb000]▶ shodan[/] — {len(queries)} query(ies) …")
        t0 = time.time()
        total = 0
        try:
            for q in queries:
                self._log(f"[dim]  · {q}[/]")
                findings = await shodan_recon.search(q, session=self.session)
                self._add_findings(findings)
                total += len([f for f in findings if f.key not in ("error", "shodan")])
            self._done(t0, total)
        except Exception as e:  # noqa: BLE001
            self._log(f"[#ff5555]error: {e}[/]")
        finally:
            self._busy = False

    async def _dork_worker(self, queries):
        self._busy = True
        self._log(f"[#ffb000]▶ google dork[/] — {len(queries)} query(ies) …")
        t0 = time.time()
        try:
            findings = await google_dork.run_queries(queries, session=self.session)
            self._add_findings(findings)
            self._done(t0, len(findings))
        except Exception as e:  # noqa: BLE001
            self._log(f"[#ff5555]error: {e}[/]")
        finally:
            self._busy = False

    def _done(self, t0: float, n: int):
        self._log(f"[green]✓ {n} findings[/] [dim]({time.time()-t0:.1f}s) — "
                  f"press 'e' to export.[/]")


def run():
    EZReconApp().run()


if __name__ == "__main__":
    run()
