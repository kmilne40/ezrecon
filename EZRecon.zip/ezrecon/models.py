"""Typed result and session models shared across the engine.

Everything the engine discovers is expressed as a ``Finding`` and collected
into a ``Session``. The report layer and the TUI both consume the same
``Session`` object, so there is a single source of truth for what we found.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any


class Severity(str, Enum):
    """Rough triage weight for a finding. Purely informational."""

    INFO = "info"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"

    @property
    def rank(self) -> int:
        return {"info": 0, "low": 1, "medium": 2, "high": 3}[self.value]


@dataclass
class Finding:
    """A single discrete piece of intelligence.

    category : logical bucket ("dns", "subdomain", "email", "shodan"...)
    key      : short label ("A", "MX", "banner"...)
    value    : the actual data point
    source   : which module / query produced it
    severity : triage weight
    meta     : anything extra (ip, port, url, timestamp...)
    """

    category: str
    key: str
    value: str
    source: str = ""
    severity: Severity = Severity.INFO
    meta: dict[str, Any] = field(default_factory=dict)
    ts: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["severity"] = self.severity.value
        return d


@dataclass
class PortResult:
    port: int
    state: str  # "open" | "closed" | "filtered"
    service: str = ""
    banner: str = ""
    mainframe_hint: str = ""  # populated by the fingerprinter


@dataclass
class Session:
    """A recon run against a single target. Serialisable to disk."""

    target: str
    started: float = field(default_factory=time.time)
    findings: list[Finding] = field(default_factory=list)
    queries: list[str] = field(default_factory=list)  # feeds queries.txt export
    notes: list[str] = field(default_factory=list)

    def add(self, finding: Finding) -> Finding:
        self.findings.append(finding)
        return finding

    def add_many(self, findings: list[Finding]) -> None:
        self.findings.extend(findings)

    def record_query(self, q: str) -> None:
        if q and q not in self.queries:
            self.queries.append(q)

    def by_category(self, category: str) -> list[Finding]:
        return [f for f in self.findings if f.category == category]

    def categories(self) -> list[str]:
        seen: list[str] = []
        for f in self.findings:
            if f.category not in seen:
                seen.append(f.category)
        return seen

    def highlights(self) -> list[Finding]:
        """Findings worth surfacing first (medium+ severity)."""
        return sorted(
            [f for f in self.findings if f.severity.rank >= Severity.MEDIUM.rank],
            key=lambda f: f.severity.rank,
            reverse=True,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "target": self.target,
            "started": self.started,
            "started_iso": time.strftime(
                "%Y-%m-%dT%H:%M:%SZ", time.gmtime(self.started)
            ),
            "finding_count": len(self.findings),
            "findings": [f.to_dict() for f in self.findings],
            "queries": self.queries,
            "notes": self.notes,
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Session":
        s = cls(target=d.get("target", ""), started=d.get("started", time.time()))
        s.queries = d.get("queries", [])
        s.notes = d.get("notes", [])
        for fd in d.get("findings", []):
            s.findings.append(
                Finding(
                    category=fd["category"],
                    key=fd["key"],
                    value=fd["value"],
                    source=fd.get("source", ""),
                    severity=Severity(fd.get("severity", "info")),
                    meta=fd.get("meta", {}),
                    ts=fd.get("ts", time.time()),
                )
            )
        return s
