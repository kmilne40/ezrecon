"""Configuration and API-key handling.

Precedence when reading a key (first hit wins):
  1. environment variable          (GOOGLE_API_KEY, GOOGLE_CSE_ID, SHODAN_API_KEY)
  2. XDG config file               (~/.config/ezrecon/config.json)
  3. legacy ./api_key.json         (kept for compatibility with the book)

Writes always go to the XDG config file. This mirrors the book's
"prompt once, store, reuse" behaviour but without scattering secrets in cwd.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

# maps a logical key name -> environment variable that can override it
ENV_MAP = {
    "google_api_key": "GOOGLE_API_KEY",
    "google_cse_id": "GOOGLE_CSE_ID",
    "shodan_api_key": "SHODAN_API_KEY",
    "anthropic_api_key": "ANTHROPIC_API_KEY",
}

DEFAULT_SETTINGS: dict[str, Any] = {
    "dns_concurrency": 100,
    "port_concurrency": 200,
    "spider_concurrency": 20,
    "timeout": 5.0,
    "brute_timeout": 2.0,        # per-query timeout for the subdomain brute force
    "dns_nameservers": None,     # None -> fast public resolvers; [] -> system
    "theme": "phosphor",
    "output_dir": "",  # empty -> cwd
    "anthropic_model": "claude-haiku-4-5-20251001",
    "allow_active_fetch": False,   # preview pane reaches third-party pages
}


def config_dir() -> Path:
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(
        os.path.expanduser("~"), ".config"
    )
    d = Path(base) / "ezrecon"
    d.mkdir(parents=True, exist_ok=True)
    return d


def config_path() -> Path:
    return config_dir() / "config.json"


def _legacy_path() -> Path:
    return Path.cwd() / "api_key.json"


def load_config() -> dict[str, Any]:
    cfg: dict[str, Any] = {"keys": {}, "settings": dict(DEFAULT_SETTINGS)}
    p = config_path()
    if p.exists():
        try:
            data = json.loads(p.read_text())
            cfg["keys"].update(data.get("keys", {}))
            cfg["settings"].update(data.get("settings", {}))
        except (json.JSONDecodeError, OSError):
            pass
    # merge legacy api_key.json if present (never overwrites XDG values)
    legacy = _legacy_path()
    if legacy.exists():
        try:
            data = json.loads(legacy.read_text())
            for k, v in data.items():
                cfg["keys"].setdefault(k, v)
        except (json.JSONDecodeError, OSError):
            pass
    return cfg


def save_config(cfg: dict[str, Any]) -> None:
    p = config_path()
    p.write_text(json.dumps(cfg, indent=2))
    try:
        os.chmod(p, 0o600)  # secrets: owner-only
    except OSError:
        pass


def _sanitise_secret(v: str) -> str:
    """Clean a pasted key/ID: trim whitespace and strip accidental wrappers.

    API keys and search-engine IDs never contain spaces or quotes, so this
    catches the common paste mistakes (surrounding quotes, trailing spaces,
    embedded newlines) without touching a valid value.
    """
    v = (v or "").strip()
    if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
        v = v[1:-1].strip()
    # keys/IDs have no internal whitespace
    return "".join(v.split())


def get_key(name: str) -> str:
    env = ENV_MAP.get(name)
    if env and os.environ.get(env):
        return _sanitise_secret(os.environ[env])
    return _sanitise_secret(str(load_config()["keys"].get(name, "")))


def set_key(name: str, value: str) -> None:
    cfg = load_config()
    cfg["keys"][name] = _sanitise_secret(value)
    save_config(cfg)


def get_setting(name: str, default: Any = None) -> Any:
    val = load_config()["settings"].get(name, default)
    return val if val is not None else DEFAULT_SETTINGS.get(name, default)


def set_setting(name: str, value: Any) -> None:
    cfg = load_config()
    cfg["settings"][name] = value
    save_config(cfg)


def output_dir() -> Path:
    d = get_setting("output_dir", "")
    path = Path(d) if d else Path.cwd()
    path.mkdir(parents=True, exist_ok=True)
    return path


def has_google() -> bool:
    return bool(get_key("google_api_key") and get_key("google_cse_id"))


def has_shodan() -> bool:
    return bool(get_key("shodan_api_key"))
