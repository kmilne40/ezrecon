"""Mainframe fingerprinting.

Takes banners and open ports and produces a human-readable hint plus a
0-100 confidence score that the host is a z/OS mainframe. This is what turns
raw port/banner output into the chapter's "Targets" triage.
"""

from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path

_DATA = Path(__file__).parent / "data" / "banner_signatures.json"


@lru_cache(maxsize=1)
def _load() -> dict:
    return json.loads(_DATA.read_text())


def port_profile() -> list[dict]:
    """The list of mainframe-relevant ports the native scanner checks."""
    return _load()["ports"]


def default_ports() -> list[int]:
    return [p["port"] for p in port_profile()]


def service_for_port(port: int) -> str:
    for p in port_profile():
        if p["port"] == port:
            return p["service"]
    return ""


def note_for_port(port: int) -> str:
    for p in port_profile():
        if p["port"] == port:
            return p["note"]
    return ""


def match_banner(banner: str) -> list[tuple[str, str]]:
    """Return [(hint, severity), ...] for signatures found in a banner."""
    hits: list[tuple[str, str]] = []
    if not banner:
        return hits
    for sig in _load()["signatures"]:
        try:
            if re.search(sig["pattern"], banner, re.IGNORECASE):
                hits.append((sig["hint"], sig["severity"]))
        except re.error:
            if sig["pattern"].lower() in banner.lower():
                hits.append((sig["hint"], sig["severity"]))
    return hits


def score(open_ports: list[int], banners: list[str]) -> tuple[int, list[str]]:
    """Confidence (0-100) that this host is a mainframe, plus the reasons.

    Scoring is deliberately simple and explainable:
      * each mainframe-signature port that is open adds weight
      * each matched banner signature adds weight (high > medium)
      * the classic TSO/VTAM banners are near-conclusive
    """
    reasons: list[str] = []
    pts = 0

    mf_ports = {21, 23, 992, 175, 448, 2809, 3270, 50000}
    strong_ports = {23, 992, 175, 3270, 50000}
    for p in open_ports:
        if p in strong_ports:
            pts += 20
            reasons.append(f"port {p} open ({service_for_port(p) or 'mainframe service'})")
        elif p in mf_ports:
            pts += 8
            reasons.append(f"port {p} open ({service_for_port(p) or 'service'})")

    for b in banners:
        for hint, sev in match_banner(b):
            pts += 30 if sev == "high" else 15
            reasons.append(f"banner: {hint}")

    # dedupe reasons, preserve order
    seen: list[str] = []
    for r in reasons:
        if r not in seen:
            seen.append(r)

    return min(pts, 100), seen


def verdict(confidence: int) -> str:
    if confidence >= 70:
        return "LIKELY MAINFRAME"
    if confidence >= 35:
        return "POSSIBLE MAINFRAME"
    if confidence > 0:
        return "MAINFRAME SIGNALS"
    return "NO MAINFRAME SIGNALS"
