"""EZRecon Textual application.

A phosphor-themed TUI: pick a module from the sidebar, type a target, and
results stream into the findings table. Google Dork opens the Listing 6-1
multi-select. Auto-Recon runs the whole passive chain. Reports export to disk.
"""

from __future__ import annotations

import time
from pathlib import Path

from rich.text import Text
from textual import on
from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import (
    Button,
    Checkbox,
    DataTable,
    Footer,
    Header,
    Input,
    Label,
    RichLog,
    Static,
)

from .. import __version__, config
from ..engine import (
    ai_osint,
    crtsh,
    dns_recon,
    email_scraper,
    google_dork,
    pipeline,
    ports,
    shodan_recon,
    subdomains,
    whois_recon,
)
from ..models import Finding, Session
from ..report import reporter

BANNER = r"""
 ______ ___________
 |  ___/___  /  __ \   EZRecon 2.0
 | |__    / /| /  \/   passive recon for the mainframe hunter
 |  __|  / / | |
 | |___./ /__| \__/\   {v}
 \____/\_____/\____/
""".strip("\n")

SEV_COLOUR = {"high": "red", "medium": "#ffb000", "low": "#33ff66", "info": "#1f8a3a"}

MODULES = [
    ("auto", "Auto-Recon"),
    ("dns", "DNS Records"),
    ("whois", "WHOIS"),
    ("subdomains", "Subdomains"),
    ("crtsh", "crt.sh (CT)"),
    ("email", "Email Spider"),
    ("ports", "Banner Grab"),
    ("shodan", "Shodan Sweep"),
    ("dork", "Google Dork"),
    ("prompt", "AI Prompt"),
]


class DorkScreen(ModalScreen):
    """The Listing 6-1 multi-select for Google dorks."""

    def __init__(self, domain: str):
        super().__init__()
        self.domain = domain
        self.dorks = google_dork.load_catalogue()

    def compose(self) -> ComposeResult:
        with Vertical(id="modal"):
            yield Static(f"Google Dork selection — site:{self.domain}",
                         classes="modal-title")
            yield Static("[dim]Toggle the queries to run. The base site: dork is "
                         "always on.[/]")
            with VerticalScroll(id="dork-list"):
                for d in self.dorks:
                    label = f"{d.id}: {d.query}"
                    if d.note:
                        label += f"   — {d.note}"
                    cb = Checkbox(label, value=(d.enabled or d.id == 1),
                                  id=f"dork-{d.id}", disabled=(d.id == 1))
                    yield cb
            with Horizontal(classes="modal-buttons"):
                yield Button("Cancel", id="dork-cancel")
                yield Button("Run dorks", id="dork-run", classes="primary")

    @on(Button.Pressed, "#dork-cancel")
    def _cancel(self):
        self.dismiss(None)

    @on(Button.Pressed, "#dork-run")
    def _run(self):
        for d in self.dorks:
            cb = self.query_one(f"#dork-{d.id}", Checkbox)
            d.enabled = bool(cb.value)
        self.dismiss(self.dorks)


class KeysScreen(ModalScreen):
    """API-key entry."""

    def compose(self) -> ComposeResult:
        with Vertical(id="modal"):
            yield Static("API keys", classes="modal-title")
            yield Label("Google API key")
            yield Input(value=config.get_key("google_api_key"),
                        password=True, id="k-gkey")
            yield Label("Google CSE ID")
            yield Input(value=config.get_key("google_cse_id"), id="k-gcse")
            yield Label("Shodan API key")
            yield Input(value=config.get_key("shodan_api_key"),
                        password=True, id="k-shodan")
            with Horizontal(classes="modal-buttons"):
                yield Button("Cancel", id="keys-cancel")
                yield Button("Save", id="keys-save", classes="primary")

    @on(Button.Pressed, "#keys-cancel")
    def _cancel(self):
        self.dismiss(False)

    @on(Button.Pressed, "#keys-save")
    def _save(self):
        config.set_key("google_api_key", self.query_one("#k-gkey", Input).value)
        config.set_key("google_cse_id", self.query_one("#k-gcse", Input).value)
        config.set_key("shodan_api_key", self.query_one("#k-shodan", Input).value)
        self.dismiss(True)


class TextScreen(ModalScreen):
    """Scrollable read-only text (used for the AI prompt)."""

    def __init__(self, title: str, body: str):
        super().__init__()
        self._title = title
        self._body = body

    def compose(self) -> ComposeResult:
        with Vertical(id="modal"):
            yield Static(self._title, classes="modal-title")
            with VerticalScroll():
                yield Static(self._body)
            with Horizontal(classes="modal-buttons"):
                yield Button("Close", id="text-close", classes="primary")

    @on(Button.Pressed, "#text-close")
    def _close(self):
        self.dismiss()


class EZReconApp(App):
    CSS_PATH = "app.tcss"
    TITLE = "EZRecon"
    SUB_TITLE = "mainframe passive recon"

    BINDINGS = [
        ("q", "quit", "Quit"),
        ("r", "run", "Run module"),
        ("a", "auto", "Auto-recon"),
        ("e", "export", "Export report"),
        ("k", "keys", "API keys"),
        ("c", "clear", "Clear"),
    ]

    def __init__(self, **kw):
        super().__init__(**kw)
        self.active_module = "auto"
        self.session = Session("")
        self._busy = False

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with Horizontal(id="body"):
            with Vertical(id="sidebar"):
                yield Static("MODULES", classes="side-title")
                for mid, label in MODULES:
                    yield Button(label, id=f"mod-{mid}")
                yield Static("", classes="side-title")
                yield Button("API keys", id="mod-keys")
            with Vertical(id="main"):
                yield Static(BANNER.format(v=f"v{__version__}"), classes="banner")
                with Horizontal(id="target-row"):
                    yield Input(placeholder="target domain or URL (e.g. sighberbank.com)",
                                id="target")
                    yield Button("Run", id="run-btn", classes="primary")
                yield RichLog(id="status", markup=True, wrap=True, highlight=False)
                yield DataTable(id="results", zebra_stripes=True)
        yield Footer()

    def on_mount(self):
        table = self.query_one("#results", DataTable)
        table.add_columns("Sev", "Category", "Key", "Value")
        self._set_active("auto")
        self._log(f"[#ffb000]EZRecon {__version__} ready.[/] "
                  "Pick a module, enter a target, press Run.")
        if not config.has_google():
            self._log("[dim]No Google API key set — press 'k' to add one for dorks.[/]")

    # -- helpers -----------------------------------------------------------
    def _log(self, msg: str):
        self.query_one("#status", RichLog).write(msg)

    def _set_active(self, mid: str):
        self.active_module = mid
        for m, _ in MODULES:
            try:
                btn = self.query_one(f"#mod-{m}", Button)
                btn.set_class(m == mid, "-active")
            except Exception:  # noqa: BLE001
                pass

    def _add_findings(self, findings: list[Finding]):
        table = self.query_one("#results", DataTable)
        for f in findings:
            colour = SEV_COLOUR.get(f.severity.value, "#33ff66")
            table.add_row(
                Text(f.severity.value, style=colour),
                Text(f.category, style="#7dffb0"),
                Text(f.key[:40]),
                Text(f.value[:200]),
            )

    def _progress(self, done: int, total: int):
        if total and done % max(1, total // 5) == 0:
            self._log(f"[dim]  … {done}/{total}[/]")

    # -- events ------------------------------------------------------------
    @on(Button.Pressed)
    def _button(self, event: Button.Pressed):
        bid = event.button.id or ""
        if bid.startswith("mod-"):
            mid = bid[4:]
            if mid == "keys":
                self.action_keys()
            else:
                self._set_active(mid)
                self._log(f"[#b6ffce]Module:[/] {mid}")
        elif bid == "run-btn":
            self.action_run()

    @on(Input.Submitted, "#target")
    def _submit(self, event: Input.Submitted):
        self.action_run()

    # -- actions -----------------------------------------------------------
    def _target(self) -> str:
        return self.query_one("#target", Input).value.strip()

    def action_clear(self):
        self.query_one("#results", DataTable).clear()
        self.session = Session(self._target())
        self._log("[dim]cleared.[/]")

    def action_keys(self):
        self.push_screen(KeysScreen(), lambda saved: self._log(
            "[green]keys saved.[/]" if saved else "[dim]keys unchanged.[/]"))

    def action_export(self):
        if not self.session.findings:
            self._log("[#ffb000]nothing to export yet.[/]")
            return
        out = config.output_dir()
        paths = reporter.write_reports(self.session, out)
        self._log(f"[green]report written:[/] {paths['md']}")
        for k, p in paths.items():
            self._log(f"[dim]  {k}: {p}[/]")

    def action_auto(self):
        self._set_active("auto")
        self.action_run()

    def action_run(self):
        if self._busy:
            self._log("[#ffb000]busy — let the current run finish.[/]")
            return
        target = self._target()
        if not target:
            self._log("[#ff5555]enter a target first.[/]")
            return
        self.session = self.session if self.session.target == target else Session(target)
        self.run_worker(self._dispatch(target, self.active_module), exclusive=True)

    async def _dispatch(self, target: str, module: str):
        self._busy = True
        self._log(f"[#ffb000]▶ {module}[/] on [#b6ffce]{target}[/] …")
        t0 = time.time()
        try:
            findings: list[Finding] = []
            if module == "auto":
                self.session = await pipeline.auto_recon(
                    target, do_ports=True,
                    do_shodan=config.has_shodan(),
                    on_stage=lambda m: self._log(f"[dim]  · {m}[/]"),
                )
                self.query_one("#results", DataTable).clear()
                self._add_findings(self.session.findings)
                self._done(t0, len(self.session.findings))
                return
            elif module == "dns":
                findings = await dns_recon.dns_lookup(target, session=self.session)
                findings += await dns_recon.zone_transfer(target, session=self.session)
            elif module == "whois":
                findings = await whois_recon.whois_lookup(target, session=self.session)
            elif module == "subdomains":
                findings = await subdomains.brute_force(
                    target, session=self.session, on_progress=self._progress)
            elif module == "crtsh":
                findings = await crtsh.crtsh_lookup(target, session=self.session)
            elif module == "email":
                findings = await email_scraper.scrape(
                    target, session=self.session, on_progress=self._progress)
            elif module == "ports":
                findings, _ = await ports.scan(
                    target, session=self.session, on_progress=self._progress)
            elif module == "shodan":
                if not config.has_shodan():
                    self._log("[#ff5555]no Shodan key — press 'k'.[/]")
                    self._busy = False
                    return
                findings = await shodan_recon.mainframe_sweep(
                    target, session=self.session)
            elif module == "dork":
                self._busy = False
                self.push_screen(DorkScreen(target), self._run_dorks)
                return
            elif module == "prompt":
                prompt = ai_osint.build_prompt(target, self.session)
                self._busy = False
                self.push_screen(TextScreen("AI deep-research OSINT prompt", prompt))
                self._log("[green]prompt generated (copy from the panel).[/]")
                return
            self._add_findings(findings)
            self._done(t0, len(findings))
        except Exception as e:  # noqa: BLE001
            self._log(f"[#ff5555]error: {e}[/]")
        finally:
            self._busy = False

    def _run_dorks(self, dorks):
        if not dorks:
            self._log("[dim]dork run cancelled.[/]")
            return
        target = self._target()
        self.run_worker(self._dork_worker(target, dorks), exclusive=True)

    async def _dork_worker(self, target, dorks):
        self._busy = True
        self._log(f"[#ffb000]▶ google dork[/] on [#b6ffce]{target}[/] …")
        t0 = time.time()
        try:
            findings = await google_dork.run_dorks(target, dorks=dorks,
                                                   session=self.session)
            self._add_findings(findings)
            self._done(t0, len(findings))
        except Exception as e:  # noqa: BLE001
            self._log(f"[#ff5555]error: {e}[/]")
        finally:
            self._busy = False

    def _done(self, t0: float, n: int):
        self._log(f"[green]✓ {n} findings[/] [dim]({time.time()-t0:.1f}s) — "
                  f"press 'e' to export.[/]")


def run():
    EZReconApp().run()


if __name__ == "__main__":
    run()
