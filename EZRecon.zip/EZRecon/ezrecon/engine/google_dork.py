"""Google dorking via the Custom Search JSON API.

Ships the mainframe dork catalogue (Listing 6-1) as a set of toggleable
queries. The base 'site:{domain}' dork anchors the search; other dorks are
appended to it unless they are flagged unanchored. Every query that runs is
recorded so it can be exported to queries.txt for the lab report.
"""

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Optional

from ..config import get_key
from ..models import Finding, Session, Severity

_CATALOGUE = Path(__file__).parent.parent / "data" / "mainframe_dorks.json"
CSE_URL = "https://www.googleapis.com/customsearch/v1"


@dataclass
class Dork:
    id: int
    query: str
    note: str
    anchored: bool
    default: bool
    enabled: bool = False


@lru_cache(maxsize=1)
def _raw_catalogue() -> list[dict]:
    return json.loads(_CATALOGUE.read_text())["dorks"]


def load_catalogue() -> list[Dork]:
    dorks = []
    for d in _raw_catalogue():
        dorks.append(Dork(id=d["id"], query=d["query"], note=d.get("note", ""),
                          anchored=d.get("anchored", True),
                          default=d.get("default", False),
                          enabled=d.get("default", False)))
    return dorks


def build_query(dork: Dork, domain: str) -> str:
    q = dork.query.replace("{domain}", domain)
    if dork.id == 1:  # the base 'site:' dork is already complete
        return q
    if dork.anchored:
        return f"site:{domain} {q}"
    return q


def _do_cse(query: str, api_key: str, cse_id: str, num: int) -> list[dict]:
    import requests

    resp = requests.get(
        CSE_URL,
        params={"q": query, "key": api_key, "cx": cse_id, "num": min(num, 10)},
        timeout=15,
    )
    resp.raise_for_status()
    data = resp.json()
    return [
        {"title": i.get("title", ""), "link": i.get("link", ""),
         "snippet": i.get("snippet", "")}
        for i in data.get("items", [])
    ]


async def run_dorks(
    domain: str,
    dorks: Optional[list[Dork]] = None,
    num_results: int = 5,
    session: Optional[Session] = None,
) -> list[Finding]:
    api_key = get_key("google_api_key")
    cse_id = get_key("google_cse_id")
    if not (api_key and cse_id):
        return [Finding("dork", "error",
                        "Google API key / CSE ID not configured", "google-dork",
                        Severity.INFO)]

    dorks = dorks if dorks is not None else [d for d in load_catalogue() if d.enabled]
    active = [d for d in dorks if d.enabled or d.id == 1]
    loop = asyncio.get_event_loop()
    findings: list[Finding] = []

    for dork in active:
        query = build_query(dork, domain)
        if session is not None:
            session.record_query(query)
        try:
            items = await loop.run_in_executor(
                None, _do_cse, query, api_key, cse_id, num_results
            )
        except Exception as e:  # noqa: BLE001
            findings.append(Finding("dork", "error", f"{query} -> {e}",
                                    "google-dork"))
            continue
        for it in items:
            sev = Severity.MEDIUM if any(
                k in (it["title"] + it["snippet"]).lower()
                for k in ("password", "jcl", "lpar", "racf", "confidential")
            ) else Severity.LOW
            findings.append(
                Finding("dork", it["link"] or it["title"],
                        f"{it['title']} :: {it['snippet'][:120]}",
                        f"dork:{query}", sev, meta={"query": query, **it})
            )
        if not items:
            findings.append(Finding("dork", "info", f"no hits: {query}",
                                    "google-dork", Severity.INFO))

    if session is not None:
        session.add_many(findings)
    return findings
