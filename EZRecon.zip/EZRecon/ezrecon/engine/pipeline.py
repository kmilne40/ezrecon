"""Auto-recon: the one-shot passive sweep.

Give it a domain and it runs the whole passive chain - whois, DNS, crt.sh,
subdomain brute, email spider, (optional) native banner grab, and (if keyed)
a Shodan mainframe sweep - into a single Session, ready for the reporter.

Each stage reports progress through an optional callback so the TUI/CLI can
show a live status line.
"""

from __future__ import annotations

import asyncio
from typing import Callable, Optional

from ..config import get_key, get_setting
from ..models import Finding, Session, Severity
from . import (
    crtsh,
    dns_recon,
    email_scraper,
    ports,
    shodan_recon,
    subdomains,
    whois_recon,
)
from .base import normalise_target

Stage = Callable[[str], None]


async def auto_recon(
    target: str,
    do_whois: bool = True,
    do_dns: bool = True,
    do_crtsh: bool = True,
    do_subdomains: bool = True,
    do_email: bool = True,
    do_ports: bool = False,
    do_shodan: bool = False,
    timeout: float = 5.0,
    on_stage: Optional[Stage] = None,
) -> Session:
    domain = normalise_target(target)
    sess = Session(domain)

    def stage(msg: str):
        if on_stage:
            on_stage(msg)

    if do_whois:
        stage("whois")
        await whois_recon.whois_lookup(domain, session=sess)

    if do_dns:
        stage("dns")
        await dns_recon.dns_lookup(domain, timeout=timeout, session=sess)
        await dns_recon.zone_transfer(domain, timeout=timeout, session=sess)

    if do_crtsh:
        stage("crt.sh")
        await crtsh.crtsh_lookup(domain, session=sess)

    if do_subdomains:
        stage("subdomain brute")
        await subdomains.brute_force(
            domain,
            concurrency=int(get_setting("dns_concurrency", 100)),
            timeout=timeout,
            session=sess,
        )

    if do_email:
        stage("email spider")
        await email_scraper.scrape(
            domain,
            max_depth=1,
            concurrency=int(get_setting("spider_concurrency", 20)),
            session=sess,
        )

    if do_ports:
        stage("banner grab")
        # scan the primary host and any discovered mainframe-looking subdomains
        targets = {domain}
        for f in sess.by_category("subdomain"):
            if any(k in f.key for k in ("mainframe", "mf", "zos", "tso", "cics")):
                targets.add(f.key)
        for t in list(targets)[:5]:
            await ports.scan(
                t,
                concurrency=int(get_setting("port_concurrency", 200)),
                timeout=min(timeout, 4.0),
                session=sess,
            )

    if do_shodan and get_key("shodan_api_key"):
        stage("shodan sweep")
        await shodan_recon.mainframe_sweep(domain, limit=5, session=sess)

    stage("done")
    return sess
