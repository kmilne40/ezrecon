"""Passive subdomain discovery via certificate transparency (crt.sh).

The chapter calls out CT logs as the way to find "forgotten or shadow
endpoints" that a brute force never will. This queries crt.sh's JSON API,
flattens the name_value fields, and returns unique in-scope hostnames.
"""

from __future__ import annotations

import json
from typing import Optional

from ..models import Finding, Session, Severity
from .base import is_valid_domain

CRTSH_URL = "https://crt.sh/?q=%25.{domain}&output=json"


def parse_crtsh(raw: str, domain: str) -> set[str]:
    """Parse crt.sh JSON text into a set of in-scope hostnames."""
    hosts: set[str] = set()
    if not raw:
        return hosts
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        # crt.sh sometimes returns newline-delimited JSON objects
        try:
            data = [json.loads(line) for line in raw.splitlines() if line.strip()]
        except json.JSONDecodeError:
            return hosts
    suffix = domain.lower().lstrip(".")
    for entry in data:
        for field in (entry.get("name_value", ""), entry.get("common_name", "")):
            for name in str(field).splitlines():
                name = name.strip().lstrip("*.").lower().rstrip(".")
                if name and (name == suffix or name.endswith("." + suffix)):
                    hosts.add(name)
    return hosts


async def crtsh_lookup(
    domain: str,
    timeout: float = 20.0,
    session: Optional[Session] = None,
    http_session=None,
) -> list[Finding]:
    domain = domain.strip().rstrip(".")
    if not is_valid_domain(domain):
        return [Finding("subdomain", "error", f"invalid domain: {domain}", "crt.sh")]

    url = CRTSH_URL.format(domain=domain)
    raw = ""
    owns_session = False
    try:
        import aiohttp

        if http_session is None:
            http_session = aiohttp.ClientSession()
            owns_session = True
        async with http_session.get(
            url, timeout=aiohttp.ClientTimeout(total=timeout),
            headers={"User-Agent": "EZRecon/2.0"},
        ) as resp:
            if resp.status == 200:
                raw = await resp.text(errors="replace")
    except Exception:  # noqa: BLE001
        raw = ""
    finally:
        if owns_session and http_session is not None:
            await http_session.close()

    hosts = parse_crtsh(raw, domain)
    findings = [
        Finding("subdomain", h, "from certificate transparency", "crt.sh",
                Severity.LOW, meta={"passive": True})
        for h in sorted(hosts)
    ]
    if not findings:
        findings.append(
            Finding("subdomain", "crt.sh", "no CT records (or crt.sh unreachable)",
                    "crt.sh", Severity.INFO)
        )
    if session is not None:
        session.add_many(findings)
        session.record_query(f"crt.sh:%.{domain}")
    return findings
