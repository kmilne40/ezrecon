"""Shared helpers for the engine: validators and network primitives."""

from __future__ import annotations

import ipaddress
import re
from typing import Optional

import dns.asyncresolver
import dns.resolver

_DOMAIN_RE = re.compile(r"^(?!-)([A-Za-z0-9-]{1,63}\.)+[A-Za-z]{2,63}$")


def is_valid_domain(domain: str) -> bool:
    return bool(domain and _DOMAIN_RE.match(domain.strip()))


def is_valid_ip(ip: str) -> bool:
    try:
        ipaddress.ip_address(ip.strip())
        return True
    except ValueError:
        return False


def normalise_target(target: str) -> str:
    """Strip scheme/path so 'https://x.com/path' -> 'x.com'."""
    t = target.strip()
    t = re.sub(r"^[a-zA-Z]+://", "", t)
    t = t.split("/")[0].split("?")[0]
    if "@" in t:
        t = t.split("@")[-1]
    return t.strip().rstrip(".")


def async_resolver(timeout: float = 5.0) -> dns.asyncresolver.Resolver:
    r = dns.asyncresolver.Resolver()
    r.timeout = timeout
    r.lifetime = timeout
    return r


async def http_get(
    session, url: str, timeout: float = 10.0
) -> tuple[Optional[int], str]:
    """GET a URL with an aiohttp session. Returns (status, text). Never raises."""
    try:
        import aiohttp

        async with session.get(
            url, timeout=aiohttp.ClientTimeout(total=timeout), ssl=False
        ) as resp:
            text = await resp.text(errors="replace")
            return resp.status, text
    except Exception:  # noqa: BLE001 - recon is best-effort
        return None, ""
