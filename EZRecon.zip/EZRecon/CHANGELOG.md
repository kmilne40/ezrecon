# Changelog

All notable changes to EZRecon are recorded here, newest first.

## [2.0.0] — 2026-08-06

Complete ground-up rebuild. The original tool was a single curses menu that
imported modules that were never shipped, so it wouldn't start; every scan it
did run went one host at a time. We threw that out and built EZRecon around a
proper async engine with two front-ends on top.

Added
- Async recon engine. DNS, subdomain brute force, banner grabs, and the email
  spider all run concurrently now, so a sweep that used to take minutes takes
  seconds.
- Textual TUI with a phosphor-green theme. Sidebar modules, a live findings
  table, keyboard and mouse, and it works fine over SSH.
- Scriptable CLI. Every module is a subcommand (`ezrecon dns`, `ezrecon auto`,
  and so on), and running `ezrecon` with no arguments opens the TUI.
- Google Dork multi-select. The mainframe dork catalogue from Chapter 6 is
  built in; tick the ones you want and fire them at a target.
- DNS module. A/AAAA/MX/NS/SOA/TXT/CNAME plus SPF and DMARC parsing, reverse
  lookups, and a zone-transfer (AXFR) attempt against every name server.
- Subdomain discovery. Concurrent brute force with wildcard-DNS detection so a
  wildcard zone doesn't report the whole wordlist as live.
- crt.sh enrichment. Pulls subdomains straight out of certificate-transparency
  logs to catch the shadow endpoints a wordlist never will.
- Shodan module. Ships the z/OS banner query library (TSO, IBM FTP, CICS,
  Db2/DRDA, NJE) so you can sweep for mainframes without memorising syntax.
- Native banner grab (non-nmap). An opt-in async connect-and-read across the
  mainframe port profile, with a fingerprint scorer that flags "likely
  mainframe" and names the service.
- AI-OSINT prompt generator. Emits the deep-research prompt from Chapter 6,
  pre-filled with the target and anything the tool already found.
- Auto-recon. One command runs the whole passive chain into a single session.
- Report export. Markdown, HTML (phosphor-themed), JSON, and a `queries.txt`
  for the lab deliverable.
- API-key vault. Keys live in `~/.config/ezrecon/config.json` (with env-var and
  legacy `api_key.json` fallbacks) instead of being scattered around.

Changed
- Dropped the Nmap component entirely. Active Nmap scanning is its own section
  of the book; EZRecon is the passive-recon workhorse.
- Reworked the engine so it never touches the UI, which means it's unit-tested
  and reusable from the CLI, the TUI, or your own scripts.

Fixed
- Tool no longer crashes on launch from missing imports.
- Run button no longer overflowed off the right edge of the terminal.
