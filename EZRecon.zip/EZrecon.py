#!/usr/bin/env python3
"""Compatibility shim.

The book launches the tool with ``python3 EZrecon.py``. This keeps that exact
command working: with no arguments it opens the Textual TUI; with arguments it
behaves as the ``ezrecon`` CLI (e.g. ``python3 EZrecon.py dns example.com``).
"""

import sys
from pathlib import Path

# make sure the local package is importable when run from the extracted folder
sys.path.insert(0, str(Path(__file__).resolve().parent))

from ezrecon.cli import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main())
